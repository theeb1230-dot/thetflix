import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class Season {
  final int n;
  final int eps;

  Season(this.n, this.eps);

  Map<String, dynamic> toJson() {
    return {'n': n, 'eps': eps};
  }

  factory Season.fromJson(Map<String, dynamic> json) {
    return Season(
      _toInt(json['n'], fallback: 1),
      _toInt(json['eps'], fallback: 10),
    );
  }
}

class Show {
  final String title;
  final String slug;
  final String type;
  final bool isBuiltIn;
  final List<Season>? seasons;

  Show({
    required this.title,
    required this.slug,
    required this.type,
    required this.isBuiltIn,
    this.seasons,
  });

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'slug': slug,
      'type': type,
      'isBuiltIn': isBuiltIn,
      'seasons': seasons?.map((season) => season.toJson()).toList(),
    };
  }

  factory Show.fromJson(Map<String, dynamic> json) {
    final rawSeasons = json['seasons'];

    List<Season>? parsedSeasons;

    if (rawSeasons is List) {
      parsedSeasons = rawSeasons
          .whereType<Map>()
          .map((item) => Season.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    }

    return Show(
      title: (json['title'] ?? '').toString(),
      slug: (json['slug'] ?? '').toString(),
      type: (json['type'] ?? 'tv').toString(),
      isBuiltIn: json['isBuiltIn'] == true,
      seasons: parsedSeasons,
    );
  }
}

// ============================================================
// URL BUILDER
// ============================================================

/// خوارزمية بناء رابط المشغل الأصلية.
String buildUrl(String slug, String type, int season, int episode, int server) {
  const baseUrl = 'https://w.anaplayer.online/albaplayer/';

  final episodePath = type == 'tv'
      ? '-s${season.toString().padLeft(2, '0')}'
            'e${episode.toString().padLeft(2, '0')}'
      : '';

  return '$baseUrl$slug$episodePath/?serv=$server';
}

// ============================================================
// DEFAULT DATABASE
// ============================================================

/// قاعدة البيانات المدمجة الأساسية.
///
/// تم تغيير الاسم من DEFAULT_DB إلى defaultDb
/// حتى يتوافق مع Dart lint: lowerCamelCase.
final List<Show> defaultDb = [
  Show(
    title: '📺 مسلسل وادي الذئاب (Kurtlar Vadisi Pusu)',
    slug: 'kurtlar-vadisi-pusu',
    type: 'tv',
    isBuiltIn: true,
    seasons: [Season(1, 9), Season(2, 32), Season(3, 22)],
  ),
  Show(
    title: '📺 مسلسل المنظمة (Teskilat)',
    slug: 'teskilat',
    type: 'tv',
    isBuiltIn: true,
    seasons: [Season(1, 184)],
  ),
  Show(
    title: '📺 مسلسل ثلاث قروش (Uc Kurus)',
    slug: 'uc-kurus',
    type: 'tv',
    isBuiltIn: true,
    seasons: [Season(1, 28)],
  ),
  Show(
    title: '📺 مسلسل رامو (Ramo)',
    slug: 'ramo',
    type: 'tv',
    isBuiltIn: true,
    seasons: [Season(1, 40)],
  ),
  Show(
    title: '📺 مسلسل قطاع طرق لن يحكموا العالم',
    slug: 'eskiya-dunyaya-hukumdar-olmaz',
    type: 'tv',
    isBuiltIn: true,
    seasons: [
      Season(1, 40),
      Season(2, 31),
      Season(3, 36),
      Season(4, 32),
      Season(5, 26),
      Season(6, 34),
    ],
  ),
  Show(
    title: '📺 مسلسل قيامة أرطغرل (Dirilis Ertugrul)',
    slug: 'dirilis-ertugrul',
    type: 'tv',
    isBuiltIn: true,
    seasons: [Season(1, 150)],
  ),
  Show(
    title: '📺 مسلسل المؤسس عثمان (Kurulus Osman)',
    slug: 'kurulus-osman',
    type: 'tv',
    isBuiltIn: true,
    seasons: [Season(1, 194)],
  ),
  Show(
    title: '📺 مسلسل الحفرة (Cukur)',
    slug: 'cukur',
    type: 'tv',
    isBuiltIn: true,
    seasons: [Season(1, 33), Season(2, 34), Season(3, 26), Season(4, 39)],
  ),
  Show(
    title: '📺 مسلسل الذئب الوحيد (Yalniz Kurt)',
    slug: 'yalniz-kurt',
    type: 'tv',
    isBuiltIn: true,
    seasons: [Season(1, 32)],
  ),
  Show(
    title: '🎬 فيلم وادي الذئاب غلاديو (2009)',
    slug: 'kurtlar-vadisi-gladstatus',
    type: 'movie',
    isBuiltIn: true,
  ),
  Show(
    title: '🎬 فيلم وادي الذئاب الوطن (2017)',
    slug: 'kurtlar-vadisi-vatan',
    type: 'movie',
    isBuiltIn: true,
  ),
  Show(
    title: '🎬 فيلم وادي الذئاب فلسطين (2011)',
    slug: 'kurtlar-vadisi-filistin',
    type: 'movie',
    isBuiltIn: true,
  ),
  Show(
    title: '🎬 فيلم وادي الذئاب العراق (2006)',
    slug: 'kurtlar-vadisi-irak',
    type: 'movie',
    isBuiltIn: true,
  ),
];

// ============================================================
// STORAGE SERVICE
// ============================================================

class StorageService {
  static const String _customCatalogKey = 'THEEB_CUSTOM_CATALOG';
  static const String _historyKey = 'THEEB_HISTORY';
  static const String _favoritesKey = 'THEEB_FAVS';

  // ============================================================
  // CUSTOM CATALOG
  // ============================================================

  static Future<List<Show>> getCustomCatalog() async {
    final prefs = await SharedPreferences.getInstance();

    final saved = prefs.getString(_customCatalogKey);

    if (saved == null || saved.trim().isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(saved);

      if (decoded is! List) {
        return [];
      }

      final result = <Show>[];

      for (final item in decoded) {
        if (item is Map) {
          result.add(Show.fromJson(Map<String, dynamic>.from(item)));
        }
      }

      return result;
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveCustomCatalog(List<Show> data) async {
    final prefs = await SharedPreferences.getInstance();

    final encoded = jsonEncode(data.map((show) => show.toJson()).toList());

    await prefs.setString(_customCatalogKey, encoded);
  }

  // ============================================================
  // HISTORY
  // ============================================================

  static Future<List<Map<String, dynamic>>> getHistory() async {
    final prefs = await SharedPreferences.getInstance();

    final saved = prefs.getString(_historyKey);

    if (saved == null || saved.trim().isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(saved);

      if (decoded is! List) {
        return [];
      }

      final result = <Map<String, dynamic>>[];

      for (final item in decoded) {
        if (item is Map) {
          result.add(Map<String, dynamic>.from(item));
        }
      }

      return result;
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveHistory(List<Map<String, dynamic>> history) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setString(_historyKey, jsonEncode(history));
  }

  // ============================================================
  // FAVORITES
  // ============================================================

  static Future<List<Show>> getFavs() async {
    final prefs = await SharedPreferences.getInstance();

    final saved = prefs.getString(_favoritesKey);

    if (saved == null || saved.trim().isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(saved);

      if (decoded is! List) {
        return [];
      }

      final result = <Show>[];

      for (final item in decoded) {
        if (item is Map) {
          result.add(Show.fromJson(Map<String, dynamic>.from(item)));
        }
      }

      return result;
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveFavs(List<Show> favorites) async {
    final prefs = await SharedPreferences.getInstance();

    final encoded = jsonEncode(favorites.map((show) => show.toJson()).toList());

    await prefs.setString(_favoritesKey, encoded);
  }
}

// ============================================================
// HELPERS
// ============================================================

int _toInt(dynamic value, {required int fallback}) {
  if (value is int) {
    return value;
  }

  if (value is num) {
    return value.toInt();
  }

  return int.tryParse(value?.toString() ?? '') ?? fallback;
}
