import 'package:flutter/material.dart';

class AppTheme {
  AppTheme._();

  // ============================================================
  // FONT
  // ============================================================

  static const String fontFamily = 'ThmanyahSans';

  // ============================================================
  // THEEB COLORS
  // ============================================================

  static const Color background = Color(0xFF05071A);
  static const Color surface = Color(0xFF0C1030);
  static const Color surface2 = Color(0xFF151A46);
  static const Color surface3 = Color(0xFF20265D);

  static const Color primary = Color(0xFF4F46E5);
  static const Color primaryDark = Color(0xFF3730A3);
  static const Color accent = Color(0xFF9333EA);

  static const Color textPrimary = Color(0xFFF4F7FF);
  static const Color textSecondary = Color(0xFFB9C3E8);
  static const Color textMuted = Color(0xFF7F8AB8);

  static const Color border = Color(0xFF29336C);
  static const Color borderLight = Color(0xFF4755A0);

  static const Color success = Color(0xFF39D98A);
  static const Color danger = Color(0xFFFF5252);
  static const Color info = Color(0xFF22D3EE);

  // ============================================================
  // TEXT THEME - THMANYAH SANS
  // ============================================================

  static const TextTheme textTheme = TextTheme(
    displayLarge: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w900,
      color: textPrimary,
    ),
    displayMedium: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w900,
      color: textPrimary,
    ),
    displaySmall: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w900,
      color: textPrimary,
    ),
    headlineLarge: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w900,
      color: textPrimary,
    ),
    headlineMedium: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w700,
      color: textPrimary,
    ),
    headlineSmall: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w700,
      color: textPrimary,
    ),
    titleLarge: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w700,
      color: textPrimary,
    ),
    titleMedium: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w700,
      color: textPrimary,
    ),
    titleSmall: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w500,
      color: textPrimary,
    ),
    bodyLarge: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w400,
      color: textPrimary,
    ),
    bodyMedium: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w400,
      color: textPrimary,
    ),
    bodySmall: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w300,
      color: textSecondary,
    ),
    labelLarge: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w700,
      color: textPrimary,
    ),
    labelMedium: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w500,
      color: textSecondary,
    ),
    labelSmall: TextStyle(
      fontFamily: fontFamily,
      fontWeight: FontWeight.w500,
      color: textMuted,
    ),
  );

  // ============================================================
  // DARK THEME
  // ============================================================

  static ThemeData get dark {
    final base = ThemeData.dark(useMaterial3: true);

    return base.copyWith(
      // خط ثمانية يطبق من خلال TextTheme
      textTheme: textTheme,
      primaryTextTheme: textTheme,

      scaffoldBackgroundColor: background,

      colorScheme: const ColorScheme.dark(
        primary: primary,
        secondary: accent,
        surface: surface,
        error: danger,
        onPrimary: Colors.black,
        onSecondary: Colors.black,
        onSurface: textPrimary,
        onError: Colors.white,
      ),

      // ========================================================
      // APP BAR
      // ========================================================
      appBarTheme: const AppBarTheme(
        backgroundColor: background,
        foregroundColor: textPrimary,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          fontFamily: fontFamily,
          fontSize: 20,
          fontWeight: FontWeight.w900,
          color: textPrimary,
        ),
        toolbarTextStyle: TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w500,
          color: textPrimary,
        ),
      ),

      // ========================================================
      // CARDS
      // ========================================================
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: border, width: 1),
        ),
      ),

      // ========================================================
      // DIVIDERS
      // ========================================================
      dividerTheme: const DividerThemeData(
        color: border,
        thickness: 1,
        space: 1,
      ),

      // ========================================================
      // INPUTS
      // ========================================================
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface2,

        hintStyle: const TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w400,
          color: textMuted,
        ),

        labelStyle: const TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w500,
          color: textSecondary,
        ),

        helperStyle: const TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w400,
          color: textSecondary,
        ),

        errorStyle: const TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w500,
          color: danger,
        ),

        prefixIconColor: textSecondary,
        suffixIconColor: textSecondary,

        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: border),
        ),

        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: border),
        ),

        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: primary, width: 1.5),
        ),

        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: danger),
        ),

        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: danger, width: 1.5),
        ),

        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
      ),

      // ========================================================
      // SNACK BAR
      // ========================================================
      snackBarTheme: SnackBarThemeData(
        backgroundColor: surface3,
        contentTextStyle: const TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w500,
          color: textPrimary,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        behavior: SnackBarBehavior.floating,
      ),

      // ========================================================
      // DIALOG
      // ========================================================
      dialogTheme: DialogThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,

        titleTextStyle: const TextStyle(
          fontFamily: fontFamily,
          fontSize: 18,
          fontWeight: FontWeight.w900,
          color: textPrimary,
        ),

        contentTextStyle: const TextStyle(
          fontFamily: fontFamily,
          fontSize: 14,
          fontWeight: FontWeight.w400,
          color: textSecondary,
        ),

        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: border),
        ),
      ),

      // ========================================================
      // POPUP MENU
      // ========================================================
      popupMenuTheme: PopupMenuThemeData(
        color: surface,
        elevation: 8,

        textStyle: const TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w500,
          color: textPrimary,
        ),

        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: border),
        ),
      ),

      // ========================================================
      // DROPDOWN
      // ========================================================
      dropdownMenuTheme: const DropdownMenuThemeData(
        textStyle: TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w500,
          color: textPrimary,
        ),
      ),

      // ========================================================
      // CHIPS / SERVERS
      // ========================================================
      chipTheme: ChipThemeData(
        backgroundColor: surface2,
        selectedColor: primary,
        disabledColor: surface3,

        labelStyle: const TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w700,
          color: textPrimary,
        ),

        secondaryLabelStyle: const TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w700,
          color: Colors.black,
        ),

        side: const BorderSide(color: border),

        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),

      // ========================================================
      // ELEVATED BUTTON
      // ========================================================
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.black,
          elevation: 0,

          minimumSize: const Size(48, 46),

          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),

          textStyle: const TextStyle(
            fontFamily: fontFamily,
            fontWeight: FontWeight.w700,
          ),

          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),

      // ========================================================
      // OUTLINED BUTTON
      // ========================================================
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: textPrimary,

          side: const BorderSide(color: borderLight),

          minimumSize: const Size(48, 46),

          textStyle: const TextStyle(
            fontFamily: fontFamily,
            fontWeight: FontWeight.w700,
          ),

          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),

      // ========================================================
      // TEXT BUTTON
      // ========================================================
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: primary,

          minimumSize: const Size(48, 44),

          textStyle: const TextStyle(
            fontFamily: fontFamily,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      // ========================================================
      // ICON BUTTON
      // ========================================================
      iconButtonTheme: IconButtonThemeData(
        style: IconButton.styleFrom(foregroundColor: textPrimary),
      ),

      // ========================================================
      // LIST TILE
      // ========================================================
      listTileTheme: const ListTileThemeData(
        textColor: textPrimary,
        iconColor: textSecondary,

        titleTextStyle: TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w700,
          color: textPrimary,
        ),

        subtitleTextStyle: TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w400,
          color: textSecondary,
        ),
      ),

      // ========================================================
      // TOOLTIP
      // ========================================================
      tooltipTheme: TooltipThemeData(
        textStyle: const TextStyle(
          fontFamily: fontFamily,
          fontWeight: FontWeight.w500,
          color: textPrimary,
        ),

        decoration: BoxDecoration(
          color: surface3,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: borderLight),
        ),
      ),

      // ========================================================
      // PROGRESS
      // ========================================================
      progressIndicatorTheme: const ProgressIndicatorThemeData(color: primary),

      // ========================================================
      // SCROLLBAR
      // ========================================================
      scrollbarTheme: ScrollbarThemeData(
        thumbColor: WidgetStateProperty.all(borderLight),
        trackColor: WidgetStateProperty.all(surface2),
        radius: const Radius.circular(10),
      ),
    );
  }

  // ============================================================
  // LIGHT THEME - WARM IVORY + THEEB GOLD
  // ============================================================

  static ThemeData get light {
    const lightBackground = Color(0xFFF5F0E4);
    const lightSurface = Color(0xFFFFFCF5);
    const lightSurface2 = Color(0xFFEDE5D3);
    const lightText = Color(0xFF211B10);
    const lightMuted = Color(0xFF6E624D);
    const lightBorder = Color(0xFFD8CBAF);

    final base = ThemeData.light(useMaterial3: true);
    final lightTextTheme = base.textTheme.apply(
      fontFamily: fontFamily,
      bodyColor: lightText,
      displayColor: lightText,
    );
    final scheme = ColorScheme.fromSeed(
      seedColor: primary,
      brightness: Brightness.light,
      primary: primaryDark,
      surface: lightSurface,
      onSurface: lightText,
      outline: const Color(0xFF8B7956),
      outlineVariant: lightBorder,
      error: const Color(0xFFB3261E),
    );

    return base.copyWith(
      colorScheme: scheme,
      scaffoldBackgroundColor: lightBackground,
      textTheme: lightTextTheme,
      primaryTextTheme: lightTextTheme,
      appBarTheme: AppBarTheme(
        backgroundColor: lightBackground,
        foregroundColor: lightText,
        elevation: 0,
        titleTextStyle: lightTextTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w900,
        ),
      ),
      cardTheme: CardThemeData(
        color: lightSurface,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: lightBorder),
        ),
      ),
      dividerTheme: const DividerThemeData(color: lightBorder),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: lightSurface,
        hintStyle: const TextStyle(fontFamily: fontFamily, color: lightMuted),
        labelStyle: const TextStyle(fontFamily: fontFamily, color: lightMuted),
        prefixIconColor: lightMuted,
        suffixIconColor: lightMuted,
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: lightBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: primaryDark, width: 1.7),
        ),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: lightSurface,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: lightTextTheme.titleLarge?.copyWith(
          fontWeight: FontWeight.w900,
        ),
        contentTextStyle: lightTextTheme.bodyMedium?.copyWith(
          color: lightMuted,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: const BorderSide(color: lightBorder),
        ),
      ),
      popupMenuTheme: PopupMenuThemeData(
        color: lightSurface,
        textStyle: lightTextTheme.bodyMedium,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: lightBorder),
        ),
      ),
      dropdownMenuTheme: DropdownMenuThemeData(
        textStyle: lightTextTheme.bodyMedium?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryDark,
          foregroundColor: Colors.white,
          textStyle: const TextStyle(
            fontFamily: fontFamily,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: lightText,
          side: const BorderSide(color: lightBorder),
        ),
      ),
      iconButtonTheme: IconButtonThemeData(
        style: IconButton.styleFrom(foregroundColor: lightText),
      ),
      listTileTheme: const ListTileThemeData(
        textColor: lightText,
        iconColor: lightMuted,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: lightText,
        contentTextStyle: const TextStyle(
          fontFamily: fontFamily,
          color: Colors.white,
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      scrollbarTheme: ScrollbarThemeData(
        thumbColor: WidgetStateProperty.all(const Color(0xFFA9905C)),
        trackColor: WidgetStateProperty.all(lightSurface2),
        radius: const Radius.circular(10),
      ),
    );
  }
}
