import 'package:flutter/material.dart';

class Responsive {
  Responsive._();

  static bool isMobile(BuildContext context) {
    return MediaQuery.sizeOf(context).width < 600;
  }

  static bool isTablet(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;

    return width >= 600 && width < 1000;
  }

  static bool isDesktop(BuildContext context) {
    return MediaQuery.sizeOf(context).width >= 1000;
  }

  static bool isTv(BuildContext context) {
    final size = MediaQuery.sizeOf(context);

    final landscape = size.width > size.height;

    return landscape && size.width >= 1000;
  }

  static double horizontalPadding(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;

    if (width < 600) {
      return 12;
    }

    if (width < 1000) {
      return 24;
    }

    return 36;
  }

  static int gridColumns(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;

    if (width < 500) {
      return 2;
    }

    if (width < 800) {
      return 3;
    }

    if (width < 1200) {
      return 4;
    }

    return 5;
  }
}
