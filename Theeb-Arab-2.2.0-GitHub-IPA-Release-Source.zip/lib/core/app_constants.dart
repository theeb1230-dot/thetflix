class AppConstants {
  AppConstants._();

  static const String appName = 'ذيب العرب';

  /// يمرر أثناء البناء بدون تخزين أسرار داخل التطبيق:
  /// --dart-define=THEEB_UPDATE_MANIFEST_URL=https://.../update.json
  static const String updateManifestUrl = String.fromEnvironment(
    'THEEB_UPDATE_MANIFEST_URL',
  );

  static const String baseUrl = 'https://w.anaplayer.online/albaplayer/';

  static const int maxServers = 9;

  static const int maxHistoryItems = 20;

  static const String customCatalogKey = 'THEEB_CUSTOM_CATALOG';

  static const String favoritesKey = 'THEEB_FAVS';

  static const String historyKey = 'THEEB_HISTORY';
}
