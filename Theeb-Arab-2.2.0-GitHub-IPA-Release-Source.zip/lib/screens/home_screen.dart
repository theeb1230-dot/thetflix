import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pointer_interceptor/pointer_interceptor.dart';
import 'package:url_launcher/url_launcher.dart';

import '../controllers/theeb_controller.dart';
import '../core/app_theme.dart';
import '../data/default_catalog.dart';
import '../models/theeb_models.dart';
import '../services/fullscreen_service.dart';
import '../services/hybrid_update_service.dart';
import '../services/player_remote_actions.dart';
import '../services/theeb_storage.dart';
import '../tv/tv_focus_manager.dart';
import '../widgets/advanced_panel.dart';
import '../widgets/app_header.dart';
import '../widgets/focusable_chip.dart';
import '../features/turkish/turkish_player.dart';
import '../widgets/tv_focusable.dart';
import '../widgets/update_center_dialog.dart';

class TheebHomeScreen extends StatefulWidget {
  final bool embedded;
  final bool active;

  const TheebHomeScreen({
    super.key,
    this.embedded = false,
    this.active = true,
  });

  @override
  State<TheebHomeScreen> createState() => _TheebHomeScreenState();
}

class _TheebHomeScreenState extends State<TheebHomeScreen>
    with WidgetsBindingObserver {
  late final TheebController controller;
  late final HybridUpdateService updateService;

  final TheebTvFocusManager _focusManager = TheebTvFocusManager.instance;

  /// نفس المشغل يبقى محفوظًا أثناء الانتقال
  /// بين الوضع العادي وملء الشاشة.
  final GlobalKey _playerKey = GlobalKey(debugLabel: 'theeb-persistent-player');
  final ScrollController _pageScrollController = ScrollController();

  TheebFullscreenSubscription? _fullscreenSubscription;

  bool initialized = false;
  bool fullscreen = false;
  bool _fullscreenTransition = false;
  Timer? _scrollSaveTimer;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addObserver(this);

    controller = TheebController(defaultCatalog: theebDefaultCatalog);
    updateService = HybridUpdateService();

    controller.addListener(_onControllerChanged);

    _fullscreenSubscription = listenTheebFullscreenChanges(
      _handleSystemFullscreenChanged,
    );

    _bindRemoteActions();
    _pageScrollController.addListener(_scheduleScrollSave);
    unawaited(updateService.initialize());

    _initialize();
  }

  Future<void> _initialize() async {
    await controller.initialize();

    if (!mounted) {
      return;
    }

    setState(() {
      initialized = true;
    });

    final savedOffset = TheebStorage.getPageScrollOffset();

    /// ننتظر اكتمال بناء عناصر الشاشة وتسجيل
    /// FocusNodes الخاصة بها قبل اختيار Focus مبدئي.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || fullscreen) {
          return;
        }

        _focusManager.cleanup();

        _focusManager.requestInitialFocus();

        if (_pageScrollController.hasClients && savedOffset > 0) {
          final position = _pageScrollController.position;
          _pageScrollController.jumpTo(
            savedOffset.clamp(
              position.minScrollExtent,
              position.maxScrollExtent,
            ),
          );
        }
      });
    });
  }

  void _scheduleScrollSave() {
    _scrollSaveTimer?.cancel();
    _scrollSaveTimer = Timer(const Duration(milliseconds: 350), () {
      if (!_pageScrollController.hasClients) return;
      unawaited(
        TheebStorage.savePageScrollOffset(
          _pageScrollController.offset,
        ).catchError(
          (Object error) =>
              debugPrint('[THEEB] Failed to save UI state: $error'),
        ),
      );
    });
  }

  Future<void> _persistCurrentState() async {
    try {
      if (_pageScrollController.hasClients) {
        await TheebStorage.savePageScrollOffset(_pageScrollController.offset);
      }
      await controller.persistSession();
    } catch (error) {
      debugPrint('[THEEB] Failed to persist current state: $error');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached ||
        state == AppLifecycleState.hidden) {
      unawaited(_persistCurrentState());
    }
  }

  void _onControllerChanged() {
    if (!mounted) {
      return;
    }

    setState(() {});
  }

  void _bindRemoteActions() {
    if (!widget.active) {
      return;
    }
    TheebPlayerRemoteActions.bind(
      toggleFullscreen: _toggleFullscreen,
      next: controller.nextEpisode,
      previous: controller.previousEpisode,
      scroll: _scrollPage,
    );
  }

  @override
  void didUpdateWidget(covariant TheebHomeScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.active != widget.active && widget.active) {
      _bindRemoteActions();
    }
  }

  Future<void> _scrollPage(double direction) async {
    if (fullscreen || direction == 0 || !_pageScrollController.hasClients) {
      return;
    }
    final position = _pageScrollController.position;
    final target = (_pageScrollController.offset + direction.sign * 190)
        .clamp(position.minScrollExtent, position.maxScrollExtent)
        .toDouble();
    if (target == _pageScrollController.offset) return;
    await _pageScrollController.animateTo(
      target,
      duration: const Duration(milliseconds: 180),
      curve: Curves.easeOutCubic,
    );
  }

  /// يتم استدعاؤه عندما تتغير حالة Fullscreen
  /// من خارج زر ذيب، مثل:
  ///
  /// - Esc
  /// - زر المتصفح
  /// - Fullscreen API
  void _handleSystemFullscreenChanged(bool active) {
    if (!mounted) {
      return;
    }

    if (fullscreen == active && !_fullscreenTransition) {
      return;
    }

    setState(() {
      fullscreen = active;
      _fullscreenTransition = false;
    });

    if (!active) {
      /// عند الخروج من Fullscreen نعيد Focus
      /// إلى آخر منطقة كان المستخدم يعمل فيها.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) {
          return;
        }

        _restoreFocusAfterFullscreen();
      });
    }
  }

  void _restoreFocusAfterFullscreen() {
    _focusManager.cleanup();

    final previousZone = _focusManager.currentZone;

    if (previousZone != null && _focusManager.restoreZone(previousZone)) {
      return;
    }

    if (_focusManager.goToServers()) {
      return;
    }

    _focusManager.requestInitialFocus();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _scrollSaveTimer?.cancel();
    _pageScrollController.removeListener(_scheduleScrollSave);
    unawaited(_persistCurrentState());
    _fullscreenSubscription?.call();
    _fullscreenSubscription = null;

    controller.removeListener(_onControllerChanged);
    controller.dispose();
    updateService.dispose();
    _pageScrollController.dispose();

    super.dispose();
  }

  Future<void> _toggleFullscreen() async {
    if (_fullscreenTransition) {
      return;
    }

    final entering = !fullscreen;

    setState(() {
      _fullscreenTransition = true;
    });

    try {
      if (entering) {
        await enterTheebFullscreen();
      } else {
        await exitTheebFullscreen();
      }
    } catch (_) {
      // إذا رفض النظام أو المتصفح Fullscreen API
      // نستطيع الاستمرار بوضع Fullscreen الداخلي.
    }

    if (!mounted) {
      return;
    }

    /// على الويب قد يكون fullscreenchange قد وصل بالفعل.
    ///
    /// إذا لم يصل، نطبق الحالة يدويًا حتى يظل
    /// Native وFallback يعملان بشكل صحيح.
    if (_fullscreenTransition) {
      setState(() {
        fullscreen = entering;
        _fullscreenTransition = false;
      });

      if (!entering) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) {
            return;
          }

          _restoreFocusAfterFullscreen();
        });
      }
    }
  }

  Widget _buildPersistentPlayer() {
    return TurkishPlayer(
      key: _playerKey,
      url: controller.currentUrl,
      externalLoading: controller.loading,
      active: widget.active,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!initialized) {
      return const Scaffold(
        backgroundColor: AppTheme.background,
        body: Center(child: CircularProgressIndicator(color: AppTheme.info)),
      );
    }

    if (fullscreen) {
      return _buildFullscreenPlayer();
    }

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Stack(
            children: [
              const Positioned.fill(child: _GridBackground()),
              Column(
                children: [
                  if (!widget.embedded)
                    TheebAppHeader(
                      mobileMode: controller.mobileMode,
                      fullscreenActive: fullscreen,
                      onFavorites: _showFavorites,
                      onMobileMode: controller.toggleMobileMode,
                      onHistory: _showHistory,
                      onUpdates: _showUpdates,
                      onFullscreen: _toggleFullscreen,
                    ),
                  Expanded(
                    child: _MainLayout(
                      controller: controller,
                      player: _buildPersistentPlayer(),
                      scrollController: _pageScrollController,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFullscreenPlayer() {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: Stack(
          fit: StackFit.expand,
          children: [
            ColoredBox(color: Colors.black, child: _buildPersistentPlayer()),
            PositionedDirectional(
              top: 14,
              start: 14,
              child: SafeArea(
                child: PointerInterceptor(
                  child: TheebTvFocusable(
                    enabled: !_fullscreenTransition,
                    autofocus: true,
                    focusScale: 1.10,
                    pressedScale: 0.94,
                    borderRadius: BorderRadius.circular(10),
                    onBack: _toggleFullscreen,
                    onPressed: _toggleFullscreen,
                    child: Material(
                      color: Colors.black.withValues(alpha: 0.78),
                      elevation: 8,
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: 50,
                        height: 50,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.24),
                          ),
                        ),
                        child: _fullscreenTransition
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(
                                Icons.fullscreen_exit,
                                color: Colors.white,
                                size: 28,
                              ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            PositionedDirectional(
              top: 14,
              end: 14,
              child: SafeArea(
                child: PointerInterceptor(
                  child: IgnorePointer(
                    child: Container(
                      constraints: const BoxConstraints(maxWidth: 500),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.60),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _fullscreenTitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontFamily: AppTheme.fontFamily,
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String get _fullscreenTitle {
    if (controller.isMovie) {
      return controller.currentShow.displayTitle;
    }

    return '${controller.currentShow.displayTitle} • '
        'الموسم ${controller.season} • '
        'الحلقة ${controller.episode}';
  }

  Future<void> _showUpdates() async {
    final returnZone = _focusManager.currentZone;
    await showDialog<void>(
      context: context,
      builder: (context) => UpdateCenterDialog(service: updateService),
    );
    if (!mounted) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _focusManager.restoreAfterDialog(returnZone);
    });
  }

  Future<void> _showFavorites() async {
    final returnZone = _focusManager.currentZone;

    await showDialog<void>(
      context: context,
      builder: (context) {
        return _TvDialog(
          title: const Text('قائمة المفضلة'),
          child: SizedBox(
            width: 480,
            child: controller.favorites.isEmpty
                ? const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(
                      child: Text('لا توجد عناصر بالمفضلة حتى الآن'),
                    ),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    itemCount: controller.favorites.length,
                    itemBuilder: (context, index) {
                      final item = controller.favorites[index];

                      return _TvDialogItem(
                        autofocus: index == 0,
                        icon: Icons.favorite,
                        iconColor: AppTheme.danger,
                        title: item.title,
                        subtitle: item.type == TheebContentType.tv
                            ? 'مسلسل'
                            : 'فيلم',
                        onDelete: () async {
                          await controller.removeFavoriteAt(index);

                          if (context.mounted) {
                            Navigator.of(context).pop();
                          }
                        },
                        onPressed: () async {
                          Navigator.of(context).pop();
                          await controller.playFavorite(item);
                        },
                      );
                    },
                  ),
          ),
        );
      },
    );

    if (mounted) {
      _focusManager.restoreAfterDialog(returnZone);
    }
  }

  Future<void> _showHistory() async {
    final returnZone = _focusManager.currentZone;

    await showDialog<void>(
      context: context,
      builder: (context) {
        return _TvDialog(
          title: const Text('سجل المشاهدة'),
          child: SizedBox(
            width: 500,
            child: controller.history.isEmpty
                ? const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(child: Text('سجل المشاهدة فارغ')),
                  )
                : ListView.builder(
                    shrinkWrap: true,
                    itemCount: controller.history.length,
                    itemBuilder: (context, index) {
                      final item = controller.history[index];

                      final subtitle = item.type == TheebContentType.tv
                          ? 'الموسم ${item.season} - '
                                'الحلقة ${item.episode} | '
                                'سيرفر ${item.server}'
                          : 'فيلم | سيرفر ${item.server}';

                      return _TvDialogItem(
                        autofocus: index == 0,
                        icon: Icons.history,
                        iconColor: AppTheme.info,
                        title: item.title,
                        subtitle: subtitle,
                        onDelete: () async {
                          await controller.removeHistoryAt(index);

                          if (context.mounted) {
                            Navigator.of(context).pop();
                          }
                        },
                        onPressed: () async {
                          Navigator.of(context).pop();
                          await controller.playHistory(item);
                        },
                      );
                    },
                  ),
          ),
        );
      },
    );

    if (mounted) {
      _focusManager.restoreAfterDialog(returnZone);
    }
  }
}

class _MainLayout extends StatelessWidget {
  final TheebController controller;
  final Widget player;
  final ScrollController scrollController;

  const _MainLayout({
    required this.controller,
    required this.player,
    required this.scrollController,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 900 || controller.mobileMode;

        if (compact) {
          return SingleChildScrollView(
            controller: scrollController,
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: Column(
              children: [
                _PlayerSection(controller: controller, player: player),
                const SizedBox(height: 12),
                _Sidebar(controller: controller),
              ],
            ),
          );
        }

        return SingleChildScrollView(
          controller: scrollController,
          padding: const EdgeInsets.only(bottom: 24),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1400),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      // تقليل عمود التحكم بنحو 13% على الواجهات الواسعة/TV
                      // يمنح المشغل مساحة أكبر من دون تغيير تخطيط الجوال.
                      width: 260,
                      child: _Sidebar(controller: controller),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _PlayerSection(
                        controller: controller,
                        player: player,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _Sidebar extends StatelessWidget {
  final TheebController controller;

  const _Sidebar({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _ControlPanel(controller: controller),
        const SizedBox(height: 9),
        TheebAdvancedPanel(controller: controller),
      ],
    );
  }
}

class _ControlPanel extends StatelessWidget {
  final TheebController controller;

  const _ControlPanel({required this.controller});

  Future<void> _copyUrl(BuildContext context) async {
    await Clipboard.setData(ClipboardData(text: controller.currentUrl));

    if (!context.mounted) {
      return;
    }

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('تم نسخ الرابط')));
  }

  Future<void> _openUrl(BuildContext context) async {
    final uri = Uri.tryParse(controller.currentUrl);

    if (uri == null) {
      if (!context.mounted) {
        return;
      }

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('الرابط غير صالح')));

      return;
    }

    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);

      if (!opened && context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('تعذر فتح الرابط')));
      }
    } catch (_) {
      if (!context.mounted) {
        return;
      }

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('تعذر فتح الرابط')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return _Panel(
      title: 'لوحة التحكم',
      icon: Icons.tune,
      child: FocusTraversalGroup(
        child: Column(
          children: [
            if (controller.isTv) ...[
              const _Label(text: 'الموسم'),
              _TvDropdown<int>(
                value: controller.season,
                focusZone: TheebFocusZone.sidebar,
                registerAsDefault: true,
                items: controller.availableSeasons
                    .map((season) => season.number)
                    .toList(),
                labelBuilder: (value) => 'الموسم $value',
                onChanged: (value) {
                  controller.setSeason(value);
                },
              ),
              const SizedBox(height: 8),
              const _Label(text: 'الحلقة'),
              _TvDropdown<int>(
                value: controller.episode,
                focusZone: TheebFocusZone.sidebar,
                items: controller.availableEpisodes,
                labelBuilder: (value) => 'الحلقة $value',
                onChanged: (value) {
                  controller.setEpisode(value);
                },
              ),
              const SizedBox(height: 8),
            ],
            const _Label(text: 'السيرفر'),
            _TvDropdown<int>(
              value: controller.server,
              focusZone: TheebFocusZone.sidebar,
              registerAsDefault: !controller.isTv,
              items: controller.servers,
              labelBuilder: (value) => 'سيرفر $value',
              onChanged: (value) {
                controller.setServer(value);
              },
            ),
            const SizedBox(height: 8),
            _TvActionButton(
              text: 'تحديث',
              icon: Icons.refresh,
              primary: true,
              focusZone: TheebFocusZone.sidebar,
              registerAsDefault: false,
              onPressed: () {
                controller.refreshPlayer();
              },
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.25),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: AppTheme.info.withValues(alpha: 0.25),
                ),
              ),
              child: Column(
                children: [
                  SelectableText(
                    controller.currentUrl,
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: AppTheme.info,
                      fontSize: 10,
                      fontFamily: 'monospace',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: _TvActionButton(
                          text: 'نسخ',
                          icon: Icons.copy,
                          compact: true,
                          focusZone: TheebFocusZone.sidebar,
                          onPressed: () {
                            _copyUrl(context);
                          },
                        ),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: _TvActionButton(
                          text: 'إرسال',
                          icon: Icons.open_in_new,
                          compact: true,
                          focusZone: TheebFocusZone.sidebar,
                          onPressed: () {
                            _openUrl(context);
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlayerSection extends StatelessWidget {
  final TheebController controller;
  final Widget player;

  const _PlayerSection({required this.controller, required this.player});

  Future<void> _toggleFavorite(BuildContext context) async {
    final added = await controller.toggleFavorite();

    if (!context.mounted) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          added ? 'تمت الإضافة إلى المفضلة' : 'تم الإزالة من المفضلة',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _ServerBar(controller: controller),
        const SizedBox(height: 8),
        AspectRatio(
          aspectRatio: 16 / 9,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Colors.black,
                border: Border.all(color: AppTheme.border),
                borderRadius: BorderRadius.circular(12),
              ),
              child: player,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.border),
          ),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final compactControls = constraints.maxWidth < 720;

              if (compactControls) {
                return Column(
                  children: [
                    _CatalogDropdown(controller: controller),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        if (controller.isTv)
                          Expanded(
                            child: _TvActionButton(
                              text: 'السابق',
                              icon: Icons.skip_next,
                              enabled: controller.canGoPrevious,
                              compact: true,
                              focusZone: TheebFocusZone.playerControls,
                              registerAsDefault: controller.canGoPrevious,
                              onPressed: () {
                                controller.previousEpisode();
                              },
                            ),
                          ),
                        if (controller.isTv) const SizedBox(width: 6),
                        Expanded(
                          child: _TvActionButton(
                            text: 'المفضلة',
                            icon: controller.isCurrentFavorite
                                ? Icons.favorite
                                : Icons.favorite_border,
                            active: controller.isCurrentFavorite,
                            compact: true,
                            focusZone: TheebFocusZone.playerControls,
                            registerAsDefault:
                                !controller.isTv || !controller.canGoPrevious,
                            onPressed: () {
                              _toggleFavorite(context);
                            },
                          ),
                        ),
                        if (controller.isTv) const SizedBox(width: 6),
                        if (controller.isTv)
                          Expanded(
                            child: _TvActionButton(
                              text: 'التالي',
                              icon: Icons.skip_previous,
                              enabled: controller.canGoNext,
                              compact: true,
                              focusZone: TheebFocusZone.playerControls,
                              onPressed: () {
                                controller.nextEpisode();
                              },
                            ),
                          ),
                      ],
                    ),
                  ],
                );
              }

              return Row(
                children: [
                  Expanded(child: _CatalogDropdown(controller: controller)),
                  if (controller.isTv) ...[
                    const SizedBox(width: 8),
                    _TvActionButton(
                      text: 'السابق',
                      icon: Icons.skip_next,
                      enabled: controller.canGoPrevious,
                      focusZone: TheebFocusZone.playerControls,
                      registerAsDefault: controller.canGoPrevious,
                      onPressed: () {
                        controller.previousEpisode();
                      },
                    ),
                  ],
                  const SizedBox(width: 8),
                  _TvActionButton(
                    text: 'المفضلة',
                    icon: controller.isCurrentFavorite
                        ? Icons.favorite
                        : Icons.favorite_border,
                    active: controller.isCurrentFavorite,
                    focusZone: TheebFocusZone.playerControls,
                    registerAsDefault:
                        !controller.isTv || !controller.canGoPrevious,
                    onPressed: () {
                      _toggleFavorite(context);
                    },
                  ),
                  if (controller.isTv) ...[
                    const SizedBox(width: 8),
                    _TvActionButton(
                      text: 'التالي',
                      icon: Icons.skip_previous,
                      enabled: controller.canGoNext,
                      focusZone: TheebFocusZone.playerControls,
                      onPressed: () {
                        controller.nextEpisode();
                      },
                    ),
                  ],
                ],
              );
            },
          ),
        ),
      ],
    );
  }
}

class _CatalogDropdown extends StatelessWidget {
  final TheebController controller;

  const _CatalogDropdown({required this.controller});

  @override
  Widget build(BuildContext context) {
    final labels = <String, String>{
      for (final item in controller.catalog) item.slug: item.displayTitle,
    };

    return _TvDropdown<String>(
      value: controller.currentShow.slug,
      focusZone: TheebFocusZone.playerControls,
      registerAsDefault: true,
      items: controller.catalog.map((item) => item.slug).toList(),
      labelBuilder: (slug) => labels[slug] ?? slug,
      onChanged: (slug) {
        controller.selectShowBySlug(slug);
      },
    );
  }
}

class _TvDropdown<T> extends StatelessWidget {
  final T value;
  final List<T> items;
  final String Function(T value) labelBuilder;
  final ValueChanged<T> onChanged;
  final TheebFocusZone focusZone;
  final bool registerAsDefault;

  const _TvDropdown({
    required this.value,
    required this.items,
    required this.labelBuilder,
    required this.onChanged,
    required this.focusZone,
    this.registerAsDefault = false,
  });

  Future<void> _open(BuildContext context) async {
    final manager = TheebTvFocusManager.instance;
    final returnZone = manager.currentZone ?? focusZone;

    final selected = await showDialog<T>(
      context: context,
      builder: (dialogContext) {
        return _TvDialog(
          title: const Text('اختر من القائمة'),
          child: SizedBox(
            width: 520,
            height: 440,
            child: ListView.separated(
              itemCount: items.length,
              separatorBuilder: (_, _) => const SizedBox(height: 6),
              itemBuilder: (context, index) {
                final item = items[index];

                return _TvDialogItem(
                  autofocus: item == value,
                  selected: item == value,
                  icon: item == value
                      ? Icons.check_circle
                      : Icons.circle_outlined,
                  iconColor: item == value
                      ? AppTheme.info
                      : AppTheme.textSecondary,
                  title: labelBuilder(item),
                  onPressed: () => Navigator.of(dialogContext).pop(item),
                );
              },
            ),
          ),
        );
      },
    );

    if (context.mounted) {
      manager.restoreAfterDialog(returnZone);
    }

    if (selected != null && selected != value) {
      onChanged(selected);
    }
  }

  @override
  Widget build(BuildContext context) {
    return TheebTvFocusable(
      focusZone: focusZone,
      registerAsDefault: registerAsDefault,
      borderRadius: BorderRadius.circular(8),
      focusScale: 1.02,
      onPressed: () => _open(context),
      child: Container(
        height: 48,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: AppTheme.surface3,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: AppTheme.borderLight),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                labelBuilder(value),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(width: 8),
            const Icon(Icons.arrow_drop_down, color: AppTheme.textSecondary),
          ],
        ),
      ),
    );
  }
}

class _TvDialog extends StatelessWidget {
  final Widget title;
  final Widget child;

  const _TvDialog({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return PointerInterceptor(
      child: PopScope(
        canPop: true,
        child: AlertDialog(
          backgroundColor: AppTheme.surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
            side: const BorderSide(color: AppTheme.border),
          ),
          title: Row(
            children: [
              Expanded(child: title),
              TheebTvFocusable(
                focusZone: TheebFocusZone.dialog,
                onBack: () => Navigator.of(context).pop(),
                onPressed: () => Navigator.of(context).pop(),
                borderRadius: BorderRadius.circular(8),
                child: const SizedBox(
                  width: 40,
                  height: 40,
                  child: Icon(Icons.close),
                ),
              ),
            ],
          ),
          content: FocusTraversalGroup(
            policy: ReadingOrderTraversalPolicy(),
            child: child,
          ),
        ),
      ),
    );
  }
}

class _TvDialogItem extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData icon;
  final Color iconColor;
  final VoidCallback onPressed;
  final VoidCallback? onDelete;
  final bool autofocus;
  final bool selected;

  const _TvDialogItem({
    required this.title,
    required this.icon,
    required this.iconColor,
    required this.onPressed,
    this.subtitle,
    this.onDelete,
    this.autofocus = false,
    this.selected = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: TheebTvFocusable(
            autofocus: autofocus,
            focusZone: TheebFocusZone.dialog,
            registerAsDefault: autofocus,
            onBack: () => Navigator.of(context).pop(),
            onPressed: onPressed,
            borderRadius: BorderRadius.circular(10),
            child: Container(
              constraints: const BoxConstraints(minHeight: 58),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: selected
                    ? AppTheme.info.withValues(alpha: 0.12)
                    : AppTheme.surface3,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: selected ? AppTheme.info : AppTheme.borderLight,
                ),
              ),
              child: Row(
                children: [
                  Icon(icon, color: iconColor),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (subtitle != null)
                          Text(
                            subtitle!,
                            style: const TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 12,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        if (onDelete != null) ...[
          const SizedBox(width: 6),
          TheebTvFocusable(
            focusZone: TheebFocusZone.dialog,
            onBack: () => Navigator.of(context).pop(),
            onPressed: onDelete,
            borderRadius: BorderRadius.circular(8),
            child: const SizedBox(
              width: 44,
              height: 44,
              child: Icon(Icons.delete_outline, color: AppTheme.danger),
            ),
          ),
        ],
      ],
    );
  }
}

class _ServerBar extends StatelessWidget {
  final TheebController controller;

  const _ServerBar({required this.controller});

  @override
  Widget build(BuildContext context) {
    return FocusTraversalGroup(
      child: SizedBox(
        height: 52,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 2),
          itemCount: controller.servers.length,
          separatorBuilder: (_, _) {
            return const SizedBox(width: 8);
          },
          itemBuilder: (context, index) {
            final server = controller.servers[index];

            final selected = server == controller.server;

            return FocusableTvChip(
              text: 'سيرفر $server',
              isSelected: selected,

              /// أول سيرفر هو نقطة الدخول الافتراضية
              /// لمنطقة السيرفرات.
              registerAsDefault: index == 0,

              /// لم نعد نعتمد على autofocus هنا.
              /// مدير Focus المركزي هو المسؤول.
              autofocus: false,

              onClick: () {
                if (server == controller.server) {
                  controller.refreshPlayer();

                  return;
                }

                controller.setServer(server);
              },
            );
          },
        ),
      ),
    );
  }
}

class _TvActionButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final VoidCallback onPressed;

  final bool enabled;
  final bool active;
  final bool primary;
  final bool compact;

  /// منطقة الـFocus التي ينتمي لها الزر.
  final TheebFocusZone? focusZone;

  /// هل هو العنصر الافتراضي داخل المنطقة؟
  final bool registerAsDefault;

  const _TvActionButton({
    required this.text,
    required this.icon,
    required this.onPressed,
    this.enabled = true,
    this.active = false,
    this.primary = false,
    this.compact = false,
    this.focusZone,
    this.registerAsDefault = false,
  });

  @override
  Widget build(BuildContext context) {
    Color backgroundColor;
    Color foregroundColor;
    Color borderColor;

    if (primary) {
      backgroundColor = AppTheme.primary;
      foregroundColor = Colors.black;
      borderColor = AppTheme.primary;
    } else if (active) {
      backgroundColor = AppTheme.danger.withValues(alpha: 0.12);

      foregroundColor = AppTheme.danger;

      borderColor = AppTheme.danger.withValues(alpha: 0.65);
    } else {
      backgroundColor = AppTheme.surface3;
      foregroundColor = AppTheme.textPrimary;
      borderColor = AppTheme.borderLight;
    }

    return TheebTvFocusable(
      enabled: enabled,
      onPressed: onPressed,
      focusZone: focusZone,
      registerAsDefault: registerAsDefault,
      focusScale: 1.06,
      pressedScale: 0.96,
      borderRadius: BorderRadius.circular(10),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        height: compact ? 36 : 40,
        padding: EdgeInsets.symmetric(horizontal: compact ? 6 : 11),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: borderColor),
        ),
        alignment: Alignment.center,
        child: Row(
          mainAxisSize: compact ? MainAxisSize.max : MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: compact ? 15 : 17, color: foregroundColor),
            const SizedBox(width: 5),
            Flexible(
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  color: foregroundColor,
                  fontSize: compact ? 10.5 : 11.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Panel extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;

  const _Panel({required this.title, required this.icon, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(9),
      decoration: BoxDecoration(
        color: AppTheme.surface.withValues(alpha: 0.92),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: AppTheme.info),
              const SizedBox(width: 7),
              Text(
                title,
                style: const TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  fontWeight: FontWeight.w800,
                  fontSize: 12.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          const Divider(),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }
}

class _Label extends StatelessWidget {
  final String text;

  const _Label({required this.text});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 4),
        child: Text(
          text,
          style: const TextStyle(
            fontFamily: AppTheme.fontFamily,
            color: AppTheme.textSecondary,
            fontWeight: FontWeight.w600,
            fontSize: 11,
          ),
        ),
      ),
    );
  }
}

class _GridBackground extends StatelessWidget {
  const _GridBackground();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _GridPainter());
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.info.withValues(alpha: 0.03)
      ..strokeWidth = 1;

    const grid = 60.0;

    for (double x = 0; x <= size.width; x += grid) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    for (double y = 0; y <= size.height; y += grid) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return false;
  }
}
