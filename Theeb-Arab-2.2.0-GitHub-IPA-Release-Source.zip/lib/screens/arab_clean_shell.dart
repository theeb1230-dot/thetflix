import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/app_theme.dart';
import '../features/live/live_channels_screen.dart';
import '../features/search/cinema_search_screen.dart';
import '../services/hybrid_update_service.dart';
import '../services/player_remote_actions.dart';
import '../widgets/tv_focusable.dart';
import '../widgets/update_center_dialog.dart';
import 'home_screen.dart';

enum CleanSection { turkish, search, live, settings }

class ArabCleanShell extends StatefulWidget {
  const ArabCleanShell({super.key});
  @override
  State<ArabCleanShell> createState() => _ArabCleanShellState();
}

class _ArabCleanShellState extends State<ArabCleanShell> {
  static const MethodChannel _remoteChannel = MethodChannel('com.theebturk.app/remote');
  static const _target = String.fromEnvironment(
    'THEEB_TARGET',
    defaultValue: String.fromEnvironment(
      'THEEB_PLATFORM',
      defaultValue: 'adaptive',
    ),
  );
  final _updates = HybridUpdateService();
  CleanSection _section = CleanSection.turkish;
  static const _items = <(CleanSection, IconData, String)>[
    (CleanSection.turkish, Icons.star_rounded, 'تركي'),
    (CleanSection.search, Icons.search_rounded, 'البحث'),
    (CleanSection.live, Icons.cell_tower_rounded, 'مباشر'),
    (CleanSection.settings, Icons.settings_rounded, 'الإعدادات'),
  ];

  @override
  void initState() {
    super.initState();
    _remoteChannel.setMethodCallHandler(_handleRemoteAction);
    _updates.initialize();
  }

  Future<void> _handleRemoteAction(MethodCall call) async {
    switch (call.method) {
      case 'toggleFullscreen':
        await TheebPlayerRemoteActions.toggleFullscreen();
        break;
      case 'next':
        await TheebPlayerRemoteActions.next();
        break;
      case 'previous':
        await TheebPlayerRemoteActions.previous();
        break;
      case 'cursorScroll':
        await TheebPlayerRemoteActions.scroll(
          (call.arguments as num?)?.toDouble() ?? 0,
        );
        break;
      case 'navigationMode':
        // الحالة البصرية للمؤشر تدار Native. لا نحتاج إعادة بناء Flutter.
        break;
    }
  }

  @override
  void dispose() {
    _remoteChannel.setMethodCallHandler(null);
    TheebPlayerRemoteActions.clear();
    _updates.dispose();
    super.dispose();
  }

  int get _sectionIndex => _items.indexWhere((item) => item.$1 == _section);

  Widget _content() => IndexedStack(
    index: _sectionIndex,
    children: [
      TheebHomeScreen(
        embedded: true,
        active: _section == CleanSection.turkish,
      ),
      CinemaSearchScreen(active: _section == CleanSection.search),
      LiveChannelsScreen(active: _section == CleanSection.live),
      _CleanSettings(updates: _updates),
    ],
  );

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final compact =
          _target == 'mobile' ||
          (_target == 'adaptive' && constraints.maxWidth < 720);
      return Scaffold(
        bottomNavigationBar: compact
            ? _NavBar(
                items: _items,
                selected: _section,
                onSelected: (value) => setState(() => _section = value),
              )
            : null,
        body: DecoratedBox(
          decoration: const BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.topRight,
              radius: 1.4,
              colors: [Color(0xFF171B55), AppTheme.background],
            ),
          ),
          child: SafeArea(
            bottom: !compact,
            child: compact
                ? _content()
                : Row(
                    children: [
                      Container(
                        width: 122,
                        color: AppTheme.surface.withValues(alpha: .9),
                        padding: const EdgeInsets.all(10),
                        child: Column(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(14),
                              child: Image.asset(
                                'assets/images/theeb_arab_banner.webp',
                                height: 64,
                                width: 102,
                                fit: BoxFit.cover,
                              ),
                            ),
                            const SizedBox(height: 16),
                            Expanded(
                              child: ListView.separated(
                                itemCount: _items.length,
                                separatorBuilder: (_, _) =>
                                    const SizedBox(height: 8),
                                itemBuilder: (_, index) => _NavButton(
                                  item: _items[index],
                                  active: _section == _items[index].$1,
                                  onPressed: () => setState(
                                    () => _section = _items[index].$1,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const VerticalDivider(width: 1, color: AppTheme.border),
                      Expanded(child: _content()),
                    ],
                  ),
          ),
        ),
      );
    },
  );
}

class _NavBar extends StatelessWidget {
  final List<(CleanSection, IconData, String)> items;
  final CleanSection selected;
  final ValueChanged<CleanSection> onSelected;
  const _NavBar({
    required this.items,
    required this.selected,
    required this.onSelected,
  });
  @override
  Widget build(BuildContext context) => SafeArea(
    top: false,
    child: Container(
      height: 72,
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(top: BorderSide(color: AppTheme.border)),
      ),
      child: Row(
        children: items
            .map(
              (item) => Expanded(
                child: _NavButton(
                  item: item,
                  active: selected == item.$1,
                  onPressed: () => onSelected(item.$1),
                ),
              ),
            )
            .toList(),
      ),
    ),
  );
}

class _NavButton extends StatelessWidget {
  final (CleanSection, IconData, String) item;
  final bool active;
  final VoidCallback onPressed;
  const _NavButton({
    required this.item,
    required this.active,
    required this.onPressed,
  });
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(5),
    child: TheebTvFocusable(
      onPressed: onPressed,
      borderRadius: BorderRadius.circular(12),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        decoration: BoxDecoration(
          gradient: active
              ? const LinearGradient(
                  colors: [AppTheme.primary, AppTheme.accent],
                )
              : null,
          color: active ? null : AppTheme.surface2,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: active ? AppTheme.info : AppTheme.border),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(item.$2),
            const SizedBox(height: 3),
            Text(item.$3, style: const TextStyle(fontSize: 11)),
          ],
        ),
      ),
    ),
  );
}

class _CleanSettings extends StatelessWidget {
  final HybridUpdateService updates;

  const _CleanSettings({required this.updates});

  @override
  Widget build(BuildContext context) => ListView(
    key: const PageStorageKey('clean-settings-scroll'),
    padding: const EdgeInsets.all(24),
    children: [
      const Text(
        'الإعدادات',
        style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
      ),
      const SizedBox(height: 18),
      ListTile(
        leading: const Icon(Icons.system_update),
        title: const Text('التحديث والمشاركة داخل الشبكة'),
        subtitle: const Text('فحص الإصدار ومشاركة حزم التحديث بين أجهزة ذيب العرب'),
        onTap: () => showDialog<void>(
          context: context,
          builder: (_) => UpdateCenterDialog(service: updates),
        ),
      ),
      const ListTile(
        leading: Icon(Icons.info_outline),
        title: Text('ذيب العرب'),
        subtitle: Text('تركي • بحث ومشاهدة • قنوات مباشرة'),
      ),
    ],
  );
}
