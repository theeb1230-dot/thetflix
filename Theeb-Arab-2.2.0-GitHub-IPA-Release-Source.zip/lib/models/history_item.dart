class HistoryItem {
  final String title;
  final String slug;
  final String type;

  final int? season;
  final int? episode;

  final int server;

  const HistoryItem({
    required this.title,
    required this.slug,
    required this.type,
    this.season,
    this.episode,
    required this.server,
  });

  bool get isTv => type == 'tv';

  bool get isMovie => type == 'movie';

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'slug': slug,
      'type': type,
      'season': season,
      'episode': episode,
      'server': server,
    };
  }

  factory HistoryItem.fromJson(Map<String, dynamic> json) {
    return HistoryItem(
      title: json['title']?.toString() ?? '',
      slug: json['slug']?.toString() ?? '',
      type: json['type']?.toString() ?? 'tv',
      season: (json['season'] as num?)?.toInt(),
      episode: (json['episode'] as num?)?.toInt(),
      server: (json['server'] as num?)?.toInt() ?? 1,
    );
  }

  @override
  String toString() {
    return 'HistoryItem('
        'title: $title, '
        'slug: $slug, '
        'type: $type, '
        'season: $season, '
        'episode: $episode, '
        'server: $server'
        ')';
  }
}
