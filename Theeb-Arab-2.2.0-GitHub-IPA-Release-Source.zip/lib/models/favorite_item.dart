class FavoriteItem {
  final String title;
  final String slug;
  final String type;

  const FavoriteItem({
    required this.title,
    required this.slug,
    required this.type,
  });

  bool get isTv => type == 'tv';

  bool get isMovie => type == 'movie';

  Map<String, dynamic> toJson() {
    return {'title': title, 'slug': slug, 'type': type};
  }

  factory FavoriteItem.fromJson(Map<String, dynamic> json) {
    return FavoriteItem(
      title: json['title']?.toString() ?? '',
      slug: json['slug']?.toString() ?? '',
      type: json['type']?.toString() ?? 'tv',
    );
  }

  @override
  String toString() {
    return 'FavoriteItem('
        'title: $title, '
        'slug: $slug, '
        'type: $type'
        ')';
  }
}
