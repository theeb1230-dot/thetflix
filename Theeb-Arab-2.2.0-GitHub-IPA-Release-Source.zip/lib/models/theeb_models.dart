import 'dart:convert';

/// نوع المحتوى في تطبيق ذيب.
enum TheebContentType { tv, movie }

extension TheebContentTypeExtension on TheebContentType {
  String get value {
    switch (this) {
      case TheebContentType.tv:
        return 'tv';
      case TheebContentType.movie:
        return 'movie';
    }
  }

  String get arabicName {
    switch (this) {
      case TheebContentType.tv:
        return 'مسلسل';
      case TheebContentType.movie:
        return 'فيلم';
    }
  }

  String get emoji {
    switch (this) {
      case TheebContentType.tv:
        return '📺';
      case TheebContentType.movie:
        return '🎬';
    }
  }

  static TheebContentType fromValue(String? value) {
    return value == 'movie' ? TheebContentType.movie : TheebContentType.tv;
  }
}

/// تعريف موسم.
class TheebSeason {
  final int number;
  final int episodes;

  const TheebSeason({required this.number, required this.episodes});

  Map<String, dynamic> toJson() {
    return {'n': number, 'eps': episodes};
  }

  factory TheebSeason.fromJson(Map<String, dynamic> json) {
    return TheebSeason(
      number: _toInt(json['n'], fallback: 1),
      episodes: _toInt(json['eps'], fallback: 10),
    );
  }

  TheebSeason copyWith({int? number, int? episodes}) {
    return TheebSeason(
      number: number ?? this.number,
      episodes: episodes ?? this.episodes,
    );
  }
}

/// العنصر الأساسي في مكتبة ذيب.
///
/// يدعم الآن:
/// - الاسم الظاهر القديم title
/// - الاسم العربي arabicTitle
/// - اسم العمل workTitle
/// - slug المستخدم لبناء رابط المشغل
/// - النوع
/// - المواسم
/// - معرفة هل العنصر مدمج أم مضاف
///
/// البيانات القديمة المحفوظة قبل إضافة arabicTitle/workTitle
/// ستستمر بالعمل بدون مشاكل.
class TheebCatalogItem {
  /// الاسم النهائي/القديم المخزن للعنصر.
  ///
  /// للعناصر الافتراضية نتركه كما هو.
  ///
  /// للعناصر المضافة سيكون بالشكل:
  ///
  /// 📺 ⭐️ مرعشلي (Marasli)
  ///
  /// أو:
  ///
  /// 🎬 ⭐️ وادي الذئاب العراق (Kurtlar Vadisi Irak)
  final String title;

  /// الاسم العربي الذي يدخله المستخدم.
  ///
  /// مثال:
  /// مرعشلي
  final String arabicTitle;

  /// اسم العمل.
  ///
  /// مثال:
  /// Marasli
  ///
  /// يمكن أن يكون مختلفًا قليلًا عن slug مستقبلاً.
  final String workTitle;

  /// الاسم المستخدم فعليًا داخل رابط المشغل.
  ///
  /// مثال:
  /// marasli
  final String slug;

  final TheebContentType type;

  final bool isBuiltIn;

  final List<TheebSeason> seasons;

  const TheebCatalogItem({
    required this.title,
    required this.slug,
    required this.type,
    required this.isBuiltIn,
    this.arabicTitle = '',
    this.workTitle = '',
    this.seasons = const [],
  });

  bool get isTv => type == TheebContentType.tv;

  bool get isMovie => type == TheebContentType.movie;

  bool get isCustom => !isBuiltIn;

  String get typeArabic => type.arabicName;

  String get typeEmoji => type.emoji;

  /// الاسم العربي بعد إزالة المسافات الزائدة.
  String get cleanArabicTitle => arabicTitle.trim();

  /// اسم العمل بعد إزالة المسافات الزائدة.
  String get cleanWorkTitle {
    final value = workTitle.trim();

    if (value.isNotEmpty) {
      return value;
    }

    return slug.trim();
  }

  /// Slug منظم للمقارنة.
  String get normalizedSlug {
    return normalizeCatalogIdentity(slug);
  }

  /// اسم العمل منظم للمقارنة.
  String get normalizedWorkTitle {
    return normalizeCatalogIdentity(cleanWorkTitle);
  }

  /// المفتاح الذي نعتمد عليه لمنع التكرار.
  ///
  /// الأولوية للـ slug لأنه الذي يحدد العمل فعليًا
  /// داخل روابط المشغل.
  String get identityKey {
    final normalized = normalizedSlug;

    if (normalized.isNotEmpty) {
      return normalized;
    }

    return normalizedWorkTitle;
  }

  /// الاسم الذي يجب عرضه داخل المكتبة.
  ///
  /// العناصر الافتراضية:
  /// تبقى بنفس title الحالي حتى لا نغير المكتبة الأصلية.
  ///
  /// العناصر المضافة:
  ///
  /// 📺 ⭐️ مرعشلي (Marasli)
  String get displayTitle {
    if (isBuiltIn) {
      return title;
    }

    return buildCustomDisplayTitle(
      type: type,
      arabicTitle: cleanArabicTitle,
      workTitle: cleanWorkTitle,
      fallbackSlug: slug,
    );
  }

  /// الاسم بدون Emoji.
  ///
  /// مفيد في بعض النوافذ لاحقًا.
  String get plainDisplayTitle {
    final arabic = cleanArabicTitle;
    final work = cleanWorkTitle;

    if (arabic.isNotEmpty && work.isNotEmpty) {
      return '$arabic ($work)';
    }

    if (arabic.isNotEmpty) {
      return arabic;
    }

    if (work.isNotEmpty) {
      return work;
    }

    return slug;
  }

  /// هل يمثل نفس العمل؟
  ///
  /// يستخدم لاحقًا لمنع:
  ///
  /// marasli
  /// MARASLI
  /// Marasli
  /// " marasli "
  ///
  /// من إنشاء مكتبات مكررة.
  bool hasSameIdentity({String? otherSlug, String? otherWorkTitle}) {
    final candidateSlug = normalizeCatalogIdentity(otherSlug ?? '');

    if (candidateSlug.isNotEmpty &&
        normalizedSlug.isNotEmpty &&
        candidateSlug == normalizedSlug) {
      return true;
    }

    final candidateWork = normalizeCatalogIdentity(otherWorkTitle ?? '');

    if (candidateWork.isNotEmpty &&
        normalizedWorkTitle.isNotEmpty &&
        candidateWork == normalizedWorkTitle) {
      return true;
    }

    return false;
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'arabicTitle': arabicTitle,
      'workTitle': workTitle,
      'slug': slug,
      'type': type.value,
      'isBuiltIn': isBuiltIn,
      'seasons': seasons.map((season) => season.toJson()).toList(),
    };
  }

  factory TheebCatalogItem.fromJson(Map<String, dynamic> json) {
    final rawSeasons = json['seasons'];

    final seasons = <TheebSeason>[];

    if (rawSeasons is List) {
      for (final item in rawSeasons) {
        if (item is Map) {
          seasons.add(TheebSeason.fromJson(Map<String, dynamic>.from(item)));
        }
      }
    }

    final title = (json['title'] ?? '').toString().trim();
    final slug = (json['slug'] ?? '').toString().trim();

    final arabicTitle = (json['arabicTitle'] ?? '').toString().trim();

    var workTitle = (json['workTitle'] ?? '').toString().trim();

    /// دعم البيانات القديمة:
    ///
    /// قبل هذه النسخة لم يكن لدينا workTitle.
    /// لذلك نعتبر slug هو اسم العمل مؤقتًا.
    if (workTitle.isEmpty) {
      workTitle = slug;
    }

    return TheebCatalogItem(
      title: title,
      arabicTitle: arabicTitle,
      workTitle: workTitle,
      slug: slug,
      type: TheebContentTypeExtension.fromValue(json['type']?.toString()),
      isBuiltIn: json['isBuiltIn'] == true,
      seasons: seasons,
    );
  }

  TheebCatalogItem copyWith({
    String? title,
    String? arabicTitle,
    String? workTitle,
    String? slug,
    TheebContentType? type,
    bool? isBuiltIn,
    List<TheebSeason>? seasons,
  }) {
    return TheebCatalogItem(
      title: title ?? this.title,
      arabicTitle: arabicTitle ?? this.arabicTitle,
      workTitle: workTitle ?? this.workTitle,
      slug: slug ?? this.slug,
      type: type ?? this.type,
      isBuiltIn: isBuiltIn ?? this.isBuiltIn,
      seasons: seasons ?? this.seasons,
    );
  }

  String encode() => jsonEncode(toJson());

  factory TheebCatalogItem.decode(String value) {
    return TheebCatalogItem.fromJson(
      Map<String, dynamic>.from(jsonDecode(value) as Map),
    );
  }
}

/// العنصر المحفوظ في المفضلة.
class TheebFavorite {
  final String title;
  final String slug;
  final TheebContentType type;

  const TheebFavorite({
    required this.title,
    required this.slug,
    required this.type,
  });

  Map<String, dynamic> toJson() {
    return {'title': title, 'slug': slug, 'type': type.value};
  }

  factory TheebFavorite.fromJson(Map<String, dynamic> json) {
    return TheebFavorite(
      title: (json['title'] ?? '').toString(),
      slug: (json['slug'] ?? '').toString(),
      type: TheebContentTypeExtension.fromValue(json['type']?.toString()),
    );
  }

  TheebFavorite copyWith({
    String? title,
    String? slug,
    TheebContentType? type,
  }) {
    return TheebFavorite(
      title: title ?? this.title,
      slug: slug ?? this.slug,
      type: type ?? this.type,
    );
  }
}

/// سجل مشاهدة.
class TheebHistoryItem {
  final String title;
  final String slug;
  final TheebContentType type;
  final int season;
  final int episode;
  final int server;

  const TheebHistoryItem({
    required this.title,
    required this.slug,
    required this.type,
    required this.season,
    required this.episode,
    required this.server,
  });

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'slug': slug,
      'type': type.value,
      'season': season,
      'episode': episode,
      'server': server,
    };
  }

  factory TheebHistoryItem.fromJson(Map<String, dynamic> json) {
    return TheebHistoryItem(
      title: (json['title'] ?? '').toString(),
      slug: (json['slug'] ?? '').toString(),
      type: TheebContentTypeExtension.fromValue(json['type']?.toString()),
      season: _toInt(json['season'], fallback: 1),
      episode: _toInt(json['episode'], fallback: 1),
      server: _toInt(json['server'], fallback: 1),
    );
  }

  TheebHistoryItem copyWith({
    String? title,
    String? slug,
    TheebContentType? type,
    int? season,
    int? episode,
    int? server,
  }) {
    return TheebHistoryItem(
      title: title ?? this.title,
      slug: slug ?? this.slug,
      type: type ?? this.type,
      season: season ?? this.season,
      episode: episode ?? this.episode,
      server: server ?? this.server,
    );
  }
}

/// الحالة الحالية للمشغل.
class TheebPlayerState {
  final TheebContentType type;
  final String slug;
  final int season;
  final int episode;
  final int server;
  final TheebCatalogItem currentShow;

  const TheebPlayerState({
    required this.type,
    required this.slug,
    required this.season,
    required this.episode,
    required this.server,
    required this.currentShow,
  });

  factory TheebPlayerState.initial(TheebCatalogItem firstShow) {
    var initialSeason = 1;

    if (firstShow.isTv && firstShow.seasons.isNotEmpty) {
      initialSeason = firstShow.seasons.first.number;
    }

    return TheebPlayerState(
      type: firstShow.type,
      slug: firstShow.slug,
      season: initialSeason,
      episode: 1,
      server: 1,
      currentShow: firstShow,
    );
  }

  TheebPlayerState copyWith({
    TheebContentType? type,
    String? slug,
    int? season,
    int? episode,
    int? server,
    TheebCatalogItem? currentShow,
  }) {
    return TheebPlayerState(
      type: type ?? this.type,
      slug: slug ?? this.slug,
      season: season ?? this.season,
      episode: episode ?? this.episode,
      server: server ?? this.server,
      currentShow: currentShow ?? this.currentShow,
    );
  }

  bool get isMovie => type == TheebContentType.movie;

  bool get isTv => type == TheebContentType.tv;
}

/// آخر جلسة تشغيل محفوظة. لا نخزن كائن المكتبة نفسه حتى تظل البيانات قابلة
/// للاستعادة بأمان بعد تعديل المكتبات أو حذف عنصر منها.
class TheebSessionState {
  final String slug;
  final int season;
  final int episode;
  final int server;
  final bool mobileMode;

  const TheebSessionState({
    required this.slug,
    required this.season,
    required this.episode,
    required this.server,
    required this.mobileMode,
  });

  Map<String, dynamic> toJson() => {
    'slug': slug,
    'season': season,
    'episode': episode,
    'server': server,
    'mobileMode': mobileMode,
  };

  factory TheebSessionState.fromJson(Map<String, dynamic> json) {
    return TheebSessionState(
      slug: (json['slug'] ?? '').toString().trim(),
      season: _toInt(json['season'], fallback: 1),
      episode: _toInt(json['episode'], fallback: 1),
      server: _toInt(json['server'], fallback: 1),
      mobileMode: json['mobileMode'] == true,
    );
  }
}

/// بيانات إنشاء أو تعديل مكتبة مضافة.
///
/// الحقول الجديدة:
///
/// arabicTitle
/// workTitle
/// slug
/// type
/// seasons
class TheebCustomItemInput {
  final TheebContentType type;

  /// الاسم العربي.
  ///
  /// مثال:
  /// مرعشلي
  final String arabicTitle;

  /// اسم العمل.
  ///
  /// مثال:
  /// Marasli
  final String workTitle;

  /// الجزء المستخدم فعليًا في رابط المشغل.
  ///
  /// مثال:
  /// marasli
  final String slug;

  final List<TheebSeason> seasons;

  const TheebCustomItemInput({
    required this.type,
    required this.arabicTitle,
    required this.workTitle,
    required this.slug,
    required this.seasons,
  });

  String get cleanArabicTitle {
    return arabicTitle.trim();
  }

  String get cleanWorkTitle {
    final value = workTitle.trim();

    if (value.isNotEmpty) {
      return value;
    }

    return slug.trim();
  }

  String get cleanSlug {
    return slug.trim();
  }

  String get normalizedSlug {
    return normalizeCatalogIdentity(cleanSlug);
  }

  String get normalizedWorkTitle {
    return normalizeCatalogIdentity(cleanWorkTitle);
  }

  String get identityKey {
    if (normalizedSlug.isNotEmpty) {
      return normalizedSlug;
    }

    return normalizedWorkTitle;
  }

  String get title {
    return buildCustomDisplayTitle(
      type: type,
      arabicTitle: cleanArabicTitle,
      workTitle: cleanWorkTitle,
      fallbackSlug: cleanSlug,
    );
  }

  TheebCatalogItem toCatalogItem() {
    return TheebCatalogItem(
      title: title,
      arabicTitle: cleanArabicTitle,
      workTitle: cleanWorkTitle,
      slug: cleanSlug,
      type: type,
      isBuiltIn: false,
      seasons: seasons,
    );
  }
}

/// نتيجة بناء رابط المشغل.
class TheebPlayerUrl {
  final String url;
  final String baseUrl;
  final String slug;
  final TheebContentType type;
  final int season;
  final int episode;
  final int server;

  const TheebPlayerUrl({
    required this.url,
    required this.baseUrl,
    required this.slug,
    required this.type,
    required this.season,
    required this.episode,
    required this.server,
  });

  @override
  String toString() => url;
}

/// إعدادات ذيب.
class TheebConfig {
  static const String baseUrl = 'https://w.anaplayer.online/albaplayer/';

  static const int maxServers = 9;

  static const int maxCustomSeasons = 9;

  static const int maxHistoryItems = 20;

  static const String customCatalogStorageKey = 'THEEB_CUSTOM_CATALOG';

  static const String favoritesStorageKey = 'THEEB_FAVS';

  static const String historyStorageKey = 'THEEB_HISTORY';

  static const String sessionStorageKey = 'THEEB_SESSION';

  static const String pageScrollOffsetStorageKey = 'THEEB_PAGE_SCROLL_OFFSET';

  const TheebConfig._();
}

/// يبني الاسم الظاهر للمكتبات المضافة.
///
/// مثال مسلسل:
///
/// 📺 ⭐️ مرعشلي (Marasli)
///
/// مثال فيلم:
///
/// 🎬 ⭐️ وادي الذئاب العراق (Kurtlar Vadisi Irak)
String buildCustomDisplayTitle({
  required TheebContentType type,
  required String arabicTitle,
  required String workTitle,
  String fallbackSlug = '',
}) {
  final arabic = arabicTitle.trim();

  var work = workTitle.trim();

  if (work.isEmpty) {
    work = fallbackSlug.trim();
  }

  final buffer = StringBuffer();

  buffer.write(type.emoji);
  buffer.write(' ⭐️');

  if (arabic.isNotEmpty) {
    buffer.write(' ');
    buffer.write(arabic);
  }

  if (work.isNotEmpty) {
    if (arabic.isNotEmpty) {
      buffer.write(' ($work)');
    } else {
      buffer.write(' ');
      buffer.write(work);
    }
  }

  return buffer.toString().trim();
}

/// يوحد الاسم حتى نستطيع اكتشاف التكرار.
///
/// أمثلة كلها تصبح متطابقة:
///
/// Marasli
/// marasli
/// MARASLI
/// " marasli "
///
/// كذلك:
///
/// marasli-
/// marasli
///
/// يتم فقط توحيد الأشياء الآمنة للمقارنة،
/// بدون تغيير قيمة slug الفعلية التي يستخدمها المشغل.
String normalizeCatalogIdentity(String value) {
  var normalized = value.trim().toLowerCase();

  normalized = normalized.replaceAll(RegExp(r'\s+'), '-');

  normalized = normalized.replaceAll(RegExp(r'-+'), '-');

  normalized = normalized.replaceAll(RegExp(r'^-+|-+$'), '');

  return normalized;
}

int _toInt(dynamic value, {required int fallback}) {
  if (value is int) {
    return value;
  }

  if (value is num) {
    return value.toInt();
  }

  return int.tryParse(value?.toString() ?? '') ?? fallback;
}
