class Season {
  final int number;
  final int episodes;

  const Season({required this.number, required this.episodes});

  Map<String, dynamic> toJson() {
    return {'n': number, 'eps': episodes};
  }

  factory Season.fromJson(Map<String, dynamic> json) {
    return Season(
      number: (json['n'] as num?)?.toInt() ?? 1,
      episodes: (json['eps'] as num?)?.toInt() ?? 0,
    );
  }

  @override
  String toString() {
    return 'Season(number: $number, episodes: $episodes)';
  }
}
