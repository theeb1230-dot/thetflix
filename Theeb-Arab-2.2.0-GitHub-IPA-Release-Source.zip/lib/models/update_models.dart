class UpdateArtifact {
  final String platform;
  final String version;
  final int build;
  final String url;
  final String sha256;
  final int size;
  final String fileName;
  final String? storeUrl;

  const UpdateArtifact({
    required this.platform,
    required this.version,
    required this.build,
    required this.url,
    required this.sha256,
    required this.size,
    required this.fileName,
    this.storeUrl,
  });

  factory UpdateArtifact.fromJson(
    String platform,
    Map<String, dynamic> json, {
    String? fallbackVersion,
    int? fallbackBuild,
  }) {
    final url = (json['url'] ?? '').toString();
    final pathSegments = Uri.tryParse(url)?.pathSegments ?? const <String>[];
    final inferredFileName = pathSegments.isEmpty
        ? 'theeb-turk-$platform.bin'
        : pathSegments.last;
    return UpdateArtifact(
      platform: platform,
      version: (json['version'] ?? fallbackVersion ?? '').toString(),
      build: _asInt(json['build']) ?? fallbackBuild ?? 0,
      url: url,
      sha256: (json['sha256'] ?? '').toString().toLowerCase(),
      size: _asInt(json['size']) ?? 0,
      fileName: (json['fileName'] ?? inferredFileName).toString(),
      storeUrl: json['storeUrl']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
    'platform': platform,
    'version': version,
    'build': build,
    'url': url,
    'sha256': sha256,
    'size': size,
    'fileName': fileName,
    if (storeUrl != null) 'storeUrl': storeUrl,
  };

  static int? _asInt(dynamic value) => switch (value) {
    int number => number,
    String text => int.tryParse(text),
    _ => null,
  };
}

class UpdateManifest {
  final String version;
  final int build;
  final String notes;
  final bool mandatory;
  final Map<String, UpdateArtifact> artifacts;

  const UpdateManifest({
    required this.version,
    required this.build,
    required this.notes,
    required this.mandatory,
    required this.artifacts,
  });

  factory UpdateManifest.fromJson(Map<String, dynamic> json) {
    final version = (json['version'] ?? '').toString();
    final build = UpdateArtifact._asInt(json['build']) ?? 0;
    final rawArtifacts = Map<String, dynamic>.from(
      json['artifacts'] as Map? ?? const {},
    );
    return UpdateManifest(
      version: version,
      build: build,
      notes: (json['notes'] ?? '').toString(),
      mandatory: json['mandatory'] == true,
      artifacts: rawArtifacts.map(
        (platform, value) => MapEntry(
          platform,
          UpdateArtifact.fromJson(
            platform,
            Map<String, dynamic>.from(value as Map),
            fallbackVersion: version,
            fallbackBuild: build,
          ),
        ),
      ),
    );
  }
}

class CachedUpdateArtifact {
  final UpdateArtifact artifact;
  final String path;

  const CachedUpdateArtifact({required this.artifact, required this.path});

  Map<String, dynamic> toJson() => {
    'artifact': artifact.toJson(),
    'path': path,
  };

  factory CachedUpdateArtifact.fromJson(Map<String, dynamic> json) {
    final artifactJson = Map<String, dynamic>.from(json['artifact'] as Map);
    return CachedUpdateArtifact(
      artifact: UpdateArtifact.fromJson(
        artifactJson['platform'].toString(),
        artifactJson,
      ),
      path: json['path'].toString(),
    );
  }
}

class UpdatePeer {
  final String id;
  final String name;
  final String version;
  final int build;
  final Uri baseUri;
  final String token;
  final Map<String, UpdateArtifact> artifacts;

  const UpdatePeer({
    required this.id,
    required this.name,
    required this.version,
    required this.build,
    required this.baseUri,
    required this.token,
    required this.artifacts,
  });
}
