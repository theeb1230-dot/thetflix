import 'season.dart';

enum ShowType { tv, movie }

extension ShowTypeExtension on ShowType {
  String get value {
    switch (this) {
      case ShowType.tv:
        return 'tv';

      case ShowType.movie:
        return 'movie';
    }
  }

  static ShowType fromString(String? value) {
    return value == 'movie' ? ShowType.movie : ShowType.tv;
  }
}

class Show {
  final String title;
  final String slug;
  final ShowType type;
  final bool isBuiltIn;
  final List<Season> seasons;

  const Show({
    required this.title,
    required this.slug,
    required this.type,
    this.isBuiltIn = false,
    this.seasons = const [],
  });

  bool get isTv => type == ShowType.tv;

  bool get isMovie => type == ShowType.movie;

  Show copyWith({
    String? title,
    String? slug,
    ShowType? type,
    bool? isBuiltIn,
    List<Season>? seasons,
  }) {
    return Show(
      title: title ?? this.title,
      slug: slug ?? this.slug,
      type: type ?? this.type,
      isBuiltIn: isBuiltIn ?? this.isBuiltIn,
      seasons: seasons ?? this.seasons,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'slug': slug,
      'type': type.value,
      'isBuiltIn': isBuiltIn,
      'seasons': seasons.map((season) => season.toJson()).toList(),
    };
  }

  factory Show.fromJson(Map<String, dynamic> json) {
    final rawSeasons = json['seasons'];

    final seasons = <Season>[];

    if (rawSeasons is List) {
      for (final item in rawSeasons) {
        if (item is Map) {
          seasons.add(Season.fromJson(Map<String, dynamic>.from(item)));
        }
      }
    }

    return Show(
      title: json['title']?.toString() ?? '',
      slug: json['slug']?.toString() ?? '',
      type: ShowTypeExtension.fromString(json['type']?.toString()),
      isBuiltIn: json['isBuiltIn'] == true,
      seasons: seasons,
    );
  }

  @override
  String toString() {
    return 'Show('
        'title: $title, '
        'slug: $slug, '
        'type: ${type.value}, '
        'isBuiltIn: $isBuiltIn, '
        'seasons: $seasons'
        ')';
  }
}
