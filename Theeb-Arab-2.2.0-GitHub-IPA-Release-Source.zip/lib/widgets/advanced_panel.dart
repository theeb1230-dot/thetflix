import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../controllers/theeb_controller.dart';
import '../core/app_theme.dart';
import '../models/theeb_models.dart';
import '../tv/tv_focus_manager.dart';
import 'tv_focusable.dart';

class TheebAdvancedPanel extends StatefulWidget {
  final TheebController controller;

  const TheebAdvancedPanel({super.key, required this.controller});

  @override
  State<TheebAdvancedPanel> createState() => _TheebAdvancedPanelState();
}

class _TheebAdvancedPanelState extends State<TheebAdvancedPanel> {
  final TheebTvFocusManager _focusManager = TheebTvFocusManager.instance;

  TheebContentType _type = TheebContentType.tv;

  final TextEditingController _arabicTitleController = TextEditingController();
  final TextEditingController _slugController = TextEditingController();

  int _seasonCount = 1;

  final List<TextEditingController> _episodeControllers = [];

  /// null = إضافة مكتبة جديدة.
  ///
  /// رقم = تعديل العنصر الموجود بهذا الـ index.
  int? _editingIndex;

  bool _saving = false;

  bool get _isEditing => _editingIndex != null;

  @override
  void initState() {
    super.initState();

    _rebuildEpisodeControllers(count: 1, values: const [10]);
  }

  @override
  void dispose() {
    _arabicTitleController.dispose();
    _slugController.dispose();

    for (final controller in _episodeControllers) {
      controller.dispose();
    }

    super.dispose();
  }

  // ============================================================
  // EPISODE CONTROLLERS
  // ============================================================

  void _rebuildEpisodeControllers({required int count, List<int>? values}) {
    final oldValues = _episodeControllers
        .map((controller) => int.tryParse(controller.text.trim()) ?? 10)
        .toList();

    for (final controller in _episodeControllers) {
      controller.dispose();
    }

    _episodeControllers.clear();

    for (int i = 0; i < count; i++) {
      int value = 10;

      if (values != null && i < values.length) {
        value = values[i];
      } else if (i < oldValues.length) {
        value = oldValues[i];
      }

      _episodeControllers.add(TextEditingController(text: value.toString()));
    }
  }

  // ============================================================
  // FORM
  // ============================================================

  void _clearForm({bool showMessage = false}) {
    if (!mounted) {
      return;
    }

    setState(() {
      _editingIndex = null;

      _type = TheebContentType.tv;

      _arabicTitleController.clear();
      _slugController.clear();

      _seasonCount = 1;

      _rebuildEpisodeControllers(count: 1, values: const [10]);
    });

    if (showMessage) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('تم مسح خانات الإدخال')));
    }
  }

  void _startEditing({required int index, required TheebCatalogItem item}) {
    final episodeValues = item.seasons
        .map((season) => season.episodes)
        .toList();

    setState(() {
      _editingIndex = index;

      _type = item.type;

      _arabicTitleController.text = item.arabicTitle;
      _slugController.text = item.slug;

      if (item.isTv) {
        _seasonCount = item.seasons.isEmpty ? 1 : item.seasons.length;

        _rebuildEpisodeControllers(
          count: _seasonCount,
          values: episodeValues.isEmpty ? const [10] : episodeValues,
        );
      } else {
        _seasonCount = 1;

        _rebuildEpisodeControllers(count: 1, values: const [10]);
      }
    });

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }

      _focusManager.goToAdvanced();
    });
  }

  List<int> _collectEpisodeCounts() {
    if (_type == TheebContentType.movie) {
      return const [];
    }

    final result = <int>[];

    for (int i = 0; i < _seasonCount; i++) {
      if (i >= _episodeControllers.length) {
        result.add(10);
        continue;
      }

      final raw = _episodeControllers[i].text.trim();
      final parsed = int.tryParse(raw);

      result.add(parsed != null && parsed > 0 ? parsed : 10);
    }

    return result;
  }

  String? _validateForm() {
    final arabicTitle = _arabicTitleController.text.trim();
    final slug = _slugController.text.trim();

    if (arabicTitle.isEmpty) {
      return 'اكتب الاسم العربي للعمل';
    }

    if (slug.isEmpty) {
      return 'اكتب اسم العمل المستخدم في الرابط';
    }

    final duplicateError = widget.controller.validateCustomItemIdentity(
      slug: slug,
      workTitle: slug,
      ignoreIndex: _editingIndex,
    );

    if (duplicateError != null) {
      return duplicateError;
    }

    return null;
  }

  Future<void> _saveItem() async {
    if (_saving) {
      return;
    }

    final validationError = _validateForm();

    if (validationError != null) {
      _showError(validationError);
      return;
    }

    final arabicTitle = _arabicTitleController.text.trim();
    final slug = _slugController.text.trim();

    final episodeCounts = _collectEpisodeCounts();

    setState(() {
      _saving = true;
    });

    try {
      if (_editingIndex != null) {
        final index = _editingIndex!;

        final item = await widget.controller.updateCustomItemAt(
          index: index,
          type: _type,
          arabicTitle: arabicTitle,
          workTitle: slug,
          slug: slug,
          episodeCounts: episodeCounts,
        );

        if (!mounted) {
          return;
        }

        _clearForm();

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تم حفظ تعديلات ${item.displayTitle}')),
        );

        return;
      }

      final item = await widget.controller.addCustomItem(
        type: _type,
        arabicTitle: arabicTitle,
        workTitle: slug,
        slug: slug,
        episodeCounts: episodeCounts,
      );

      if (!mounted) {
        return;
      }

      _clearForm();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'تمت إضافة ${item.displayTitle} للمكتبة وتشغيله تلقائياً',
          ),
        ),
      );
    } on ArgumentError catch (error) {
      if (!mounted) {
        return;
      }

      _showError(error.message?.toString() ?? 'بيانات العنصر غير صحيحة');
    } on StateError catch (error) {
      if (!mounted) {
        return;
      }

      _showError(error.message);
    } catch (error) {
      if (!mounted) {
        return;
      }

      _showError('تعذر حفظ المكتبة: $error');
    } finally {
      if (mounted) {
        setState(() {
          _saving = false;
        });
      }
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: AppTheme.danger),
    );
  }

  // ============================================================
  // CONFIRM
  // ============================================================

  Future<bool> _confirm({
    required String title,
    required String message,
    String action = 'تأكيد',
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [
            TheebTvFocusable(
              focusZone: TheebFocusZone.dialog,
              registerAsDefault: true,
              onPressed: () {
                Navigator.pop(dialogContext, false);
              },
              onBack: () {
                Navigator.pop(dialogContext, false);
              },
              borderRadius: BorderRadius.circular(10),
              child: _DialogButton(
                text: 'إلغاء',
                icon: Icons.close,
                foreground: AppTheme.textSecondary,
              ),
            ),
            const SizedBox(width: 6),
            TheebTvFocusable(
              focusZone: TheebFocusZone.dialog,
              onPressed: () {
                Navigator.pop(dialogContext, true);
              },
              onBack: () {
                Navigator.pop(dialogContext, false);
              },
              borderRadius: BorderRadius.circular(10),
              child: _DialogButton(
                text: action,
                icon: Icons.check,
                foreground: AppTheme.info,
              ),
            ),
          ],
        );
      },
    );

    return result == true;
  }

  // ============================================================
  // CLEAR ACTIVITY
  // ============================================================

  Future<void> _clearActivity() async {
    final confirmed = await _confirm(
      title: 'مسح السجل',
      message: 'سيتم مسح سجل المشاهدة والمفضلة المحفوظة. هل تريد المتابعة؟',
      action: 'مسح',
    );

    if (!confirmed) {
      return;
    }

    await widget.controller.clearSavedActivity();

    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم مسح سجل المشاهدة والمفضلة')),
    );
  }

  // ============================================================
  // RESET FORM
  // ============================================================

  void _resetForm() {
    _clearForm(showMessage: true);
  }

  // ============================================================
  // CUSTOM CATALOG MANAGER
  // ============================================================

  Future<void> _openManager() async {
    String query = '';
    final returnZone = _focusManager.currentZone;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            final items = widget.controller.searchCustomCatalog(query);

            return AlertDialog(
              title: Row(
                children: [
                  const Icon(Icons.library_books_rounded, color: AppTheme.info),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'تحرير المكتبات المضافة '
                      '(${widget.controller.customCatalog.length})',
                    ),
                  ),
                ],
              ),
              content: SizedBox(
                width: 620,
                height: 520,
                child: FocusTraversalGroup(
                  child: Column(
                    children: [
                      _TvEditableTextField(
                        focusZone: TheebFocusZone.dialog,
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search),
                          hintText:
                              'ابحث بالاسم العربي أو اسم العمل أو Slug...',
                        ),
                        onChanged: (value) {
                          setDialogState(() {
                            query = value;
                          });
                        },
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: items.isEmpty
                            ? Center(
                                child: Text(
                                  widget.controller.customCatalog.isEmpty
                                      ? 'لا توجد مكتبات مضافة'
                                      : 'لا توجد نتائج مطابقة',
                                  style: const TextStyle(
                                    color: AppTheme.textMuted,
                                  ),
                                ),
                              )
                            : ListView.separated(
                                itemCount: items.length,
                                separatorBuilder: (_, _) {
                                  return const SizedBox(height: 7);
                                },
                                itemBuilder: (context, index) {
                                  final item = items[index];

                                  final realIndex = widget
                                      .controller
                                      .customCatalog
                                      .indexWhere(
                                        (entry) =>
                                            identical(entry, item) ||
                                            entry.slug == item.slug,
                                      );

                                  return _ManagerItem(
                                    item: item,
                                    enabled: realIndex >= 0,
                                    onEdit: realIndex < 0
                                        ? null
                                        : () {
                                            Navigator.pop(dialogContext);

                                            _startEditing(
                                              index: realIndex,
                                              item: item,
                                            );
                                          },
                                    onDelete: realIndex < 0
                                        ? null
                                        : () async {
                                            final confirmed = await _confirm(
                                              title: 'حذف المكتبة',
                                              message:
                                                  'هل تريد حذف ${item.displayTitle}؟',
                                              action: 'حذف',
                                            );

                                            if (!confirmed) {
                                              return;
                                            }

                                            await widget.controller
                                                .deleteCustomItemAt(realIndex);

                                            if (!mounted) {
                                              return;
                                            }

                                            setDialogState(() {});
                                          },
                                  );
                                },
                              ),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                if (widget.controller.customCatalog.isNotEmpty) ...[
                  TheebTvFocusable(
                    focusZone: TheebFocusZone.dialog,
                    onPressed: () async {
                      final confirmed = await _confirm(
                        title: 'حذف جميع المكتبات المضافة',
                        message:
                            'سيتم حذف جميع المكتبات المضافة فقط. المكتبة الأساسية لن تتأثر.',
                        action: 'حذف الكل',
                      );

                      if (!confirmed) {
                        return;
                      }

                      await widget.controller.clearAllCustomItems();

                      if (!dialogContext.mounted) {
                        return;
                      }

                      Navigator.pop(dialogContext);
                    },
                    onBack: () {
                      Navigator.pop(dialogContext);
                    },
                    borderRadius: BorderRadius.circular(10),
                    child: const _DialogButton(
                      text: 'حذف الكل',
                      icon: Icons.delete_sweep_outlined,
                      foreground: AppTheme.danger,
                    ),
                  ),
                  const SizedBox(width: 6),
                ],
                TheebTvFocusable(
                  focusZone: TheebFocusZone.dialog,
                  registerAsDefault: true,
                  onPressed: () {
                    Navigator.pop(dialogContext);
                  },
                  onBack: () {
                    Navigator.pop(dialogContext);
                  },
                  borderRadius: BorderRadius.circular(10),
                  child: const _DialogButton(
                    text: 'إغلاق',
                    icon: Icons.close,
                    foreground: AppTheme.textPrimary,
                  ),
                ),
              ],
            );
          },
        );
      },
    );

    if (mounted) {
      _focusManager.restoreAfterDialog(returnZone);
    }
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    final isMovie = _type == TheebContentType.movie;

    return FocusTraversalGroup(
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: AppTheme.surface.withValues(alpha: 0.92),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: _isEditing
                ? AppTheme.info.withValues(alpha: 0.60)
                : AppTheme.border,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(
                  _isEditing ? Icons.edit_note : Icons.settings,
                  size: 16,
                  color: AppTheme.info,
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: Text(
                    _isEditing
                        ? 'تعديل المكتبة المضافة'
                        : 'الإعدادات المتقدمة والسحب',
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 12.5,
                    ),
                  ),
                ),
                if (_isEditing)
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 7,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: AppTheme.info.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: const Text(
                      'وضع التعديل',
                      style: TextStyle(
                        color: AppTheme.info,
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
              ],
            ),

            const SizedBox(height: 6),
            const Divider(),
            const SizedBox(height: 8),

            // ==================================================
            // TYPE
            // ==================================================
            const _AdvancedLabel(text: '1- النوع'),

            _TvDirectionalRegion(
              child: DropdownButtonFormField<TheebContentType>(
                key: ValueKey('type-${_type.name}'),
                initialValue: _type,
                isExpanded: true,
                items: const [
                  DropdownMenuItem(
                    value: TheebContentType.tv,
                    child: Text('📺 مسلسل'),
                  ),
                  DropdownMenuItem(
                    value: TheebContentType.movie,
                    child: Text('🎬 فيلم'),
                  ),
                ],
                onChanged: _saving
                    ? null
                    : (value) {
                        if (value == null) {
                          return;
                        }

                        setState(() {
                          _type = value;

                          if (_type == TheebContentType.tv &&
                              _episodeControllers.isEmpty) {
                            _seasonCount = 1;

                            _rebuildEpisodeControllers(
                              count: 1,
                              values: const [10],
                            );
                          }
                        });
                      },
              ),
            ),

            const SizedBox(height: 8),

            // ==================================================
            // ARABIC TITLE
            // ==================================================
            const _AdvancedLabel(text: '2- الاسم العربي'),

            _TvEditableTextField(
              controller: _arabicTitleController,
              enabled: !_saving,
              textDirection: TextDirection.rtl,
              decoration: const InputDecoration(
                hintText: 'مثال: مرعشلي',
                prefixIcon: Icon(Icons.translate),
              ),
            ),

            const SizedBox(height: 8),

            // ==================================================
            // اسم العمل هو نفسه slug المستخدم في الرابط.
            // ==================================================
            const _AdvancedLabel(text: '3- اسم العمل'),

            _TvEditableTextField(
              controller: _slugController,
              enabled: !_saving,
              textDirection: TextDirection.ltr,
              autocorrect: false,
              enableSuggestions: false,
              decoration: const InputDecoration(
                hintText: 'مثال: Marasli (يُستخدم في الرابط)',
                prefixIcon: Icon(Icons.link),
              ),
            ),

            if (!isMovie) ...[
              const SizedBox(height: 8),

              // ================================================
              // SEASONS
              // ================================================
              const _AdvancedLabel(text: '4- عدد المواسم (حد أقصى 9)'),

              _TvDirectionalRegion(
                child: DropdownButtonFormField<int>(
                  key: ValueKey('season-count-$_seasonCount'),
                  initialValue: _seasonCount,
                  isExpanded: true,
                  items: List.generate(TheebConfig.maxCustomSeasons, (index) {
                    final value = index + 1;

                    return DropdownMenuItem<int>(
                      value: value,
                      child: Text(value == 1 ? 'موسم واحد' : '$value مواسم'),
                    );
                  }),
                  onChanged: _saving
                      ? null
                      : (value) {
                          if (value == null) {
                            return;
                          }

                          setState(() {
                            _seasonCount = value;

                            _rebuildEpisodeControllers(count: value);
                          });
                        },
                ),
              ),

              const SizedBox(height: 8),

              // ================================================
              // EPISODES
              // ================================================
              const _AdvancedLabel(text: '6- عدد الحلقات لكل موسم'),

              Container(
                constraints: const BoxConstraints(maxHeight: 220),
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppTheme.border),
                ),
                child: SingleChildScrollView(
                  child: Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: List.generate(_seasonCount, (index) {
                      return SizedBox(
                        width: 118,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              'الموسم ${index + 1}',
                              style: const TextStyle(
                                color: AppTheme.textSecondary,
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 3),
                            _TvEditableTextField(
                              controller: _episodeControllers[index],
                              enabled: !_saving,
                              keyboardType: TextInputType.number,
                              textDirection: TextDirection.ltr,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly,
                              ],
                              decoration: const InputDecoration(
                                hintText: '10',
                                isDense: true,
                              ),
                            ),
                          ],
                        ),
                      );
                    }),
                  ),
                ),
              ),
            ],

            const SizedBox(height: 12),

            // ==================================================
            // ACTIONS
            // ==================================================
            Row(
              children: [
                Expanded(
                  child: _ActionButton(
                    label: _isEditing ? 'حفظ' : 'سحب',
                    icon: _isEditing ? Icons.save : Icons.download,
                    foreground: AppTheme.success,
                    background: AppTheme.success.withValues(alpha: 0.12),
                    enabled: !_saving,
                    registerAsDefault: true,
                    onPressed: _saveItem,
                  ),
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: _ActionButton(
                    label: 'مسح السجل',
                    icon: Icons.delete_outline,
                    foreground: AppTheme.danger,
                    background: AppTheme.danger.withValues(alpha: 0.12),
                    enabled: !_saving,
                    onPressed: _clearActivity,
                  ),
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: _ActionButton(
                    label: 'مسح الخانات',
                    icon: Icons.restart_alt,
                    foreground: AppTheme.primary,
                    background: AppTheme.primary.withValues(alpha: 0.12),
                    enabled: !_saving,
                    onPressed: () async {
                      _resetForm();
                    },
                  ),
                ),
              ],
            ),

            if (_isEditing) ...[
              const SizedBox(height: 7),
              TheebTvFocusable(
                focusZone: TheebFocusZone.advanced,
                enabled: !_saving,
                onPressed: _resetForm,
                borderRadius: BorderRadius.circular(9),
                child: Container(
                  width: double.infinity,
                  height: 42,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppTheme.surface3,
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(color: AppTheme.borderLight),
                  ),
                  child: const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.close,
                        size: 17,
                        color: AppTheme.textSecondary,
                      ),
                      SizedBox(width: 6),
                      Text(
                        'إلغاء التعديل',
                        style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontWeight: FontWeight.w700,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],

            const SizedBox(height: 12),

            // ==================================================
            // LIBRARY MANAGER
            // ==================================================
            const _AdvancedLabel(text: '⚙️ إدارة المكتبات المضافة'),

            TheebTvFocusable(
              focusZone: TheebFocusZone.advanced,
              onPressed: _openManager,
              borderRadius: BorderRadius.circular(10),
              child: Container(
                width: double.infinity,
                constraints: const BoxConstraints(minHeight: 46),
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.surface3,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppTheme.borderLight),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.library_books_outlined,
                      size: 18,
                      color: AppTheme.info,
                    ),
                    const SizedBox(width: 7),
                    Flexible(
                      child: Text(
                        'تحرير المكتبات المضافة '
                        '(${widget.controller.customCatalog.length})',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================================
// MANAGER ITEM
// ============================================================================

class _ManagerItem extends StatelessWidget {
  final TheebCatalogItem item;
  final bool enabled;

  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  const _ManagerItem({
    required this.item,
    required this.enabled,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppTheme.surface2,
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: AppTheme.border),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: AppTheme.info.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              item.isTv ? Icons.live_tv : Icons.movie,
              color: AppTheme.info,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.displayTitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  'Slug: ${item.slug}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(
                    fontSize: 10,
                    color: AppTheme.textSecondary,
                  ),
                ),
                if (item.isTv) ...[
                  const SizedBox(height: 3),
                  Text(
                    '${item.seasons.length} موسم',
                    style: const TextStyle(
                      fontSize: 10,
                      color: AppTheme.textMuted,
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 8),

          // ====================================================
          // EDIT
          // ====================================================
          TheebTvFocusable(
            focusZone: TheebFocusZone.dialog,
            enabled: enabled,
            onPressed: onEdit,
            borderRadius: BorderRadius.circular(8),
            focusScale: 1.08,
            child: Container(
              width: 42,
              height: 42,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppTheme.info.withValues(alpha: 0.10),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: AppTheme.info.withValues(alpha: 0.30),
                ),
              ),
              child: const Icon(
                Icons.edit_outlined,
                color: AppTheme.info,
                size: 20,
              ),
            ),
          ),

          const SizedBox(width: 6),

          // ====================================================
          // DELETE
          // ====================================================
          TheebTvFocusable(
            focusZone: TheebFocusZone.dialog,
            enabled: enabled,
            onPressed: onDelete,
            borderRadius: BorderRadius.circular(8),
            focusScale: 1.08,
            child: Container(
              width: 42,
              height: 42,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: AppTheme.danger.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: AppTheme.danger.withValues(alpha: 0.25),
                ),
              ),
              child: const Icon(
                Icons.delete_outline,
                color: AppTheme.danger,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================================
// ACTION BUTTON
// ============================================================================

class _ActionButton extends StatelessWidget {
  final String label;
  final IconData icon;

  final Color foreground;
  final Color background;

  final Future<void> Function() onPressed;

  final bool enabled;
  final bool registerAsDefault;

  const _ActionButton({
    required this.label,
    required this.icon,
    required this.foreground,
    required this.background,
    required this.onPressed,
    this.enabled = true,
    this.registerAsDefault = false,
  });

  @override
  Widget build(BuildContext context) {
    return TheebTvFocusable(
      focusZone: TheebFocusZone.advanced,
      registerAsDefault: registerAsDefault,
      enabled: enabled,
      onPressed: () {
        onPressed();
      },
      borderRadius: BorderRadius.circular(10),
      focusScale: 1.06,
      pressedScale: 0.95,
      child: Container(
        constraints: const BoxConstraints(minHeight: 52),
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
        decoration: BoxDecoration(
          color: background,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: foreground.withValues(alpha: 0.45)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: foreground),
            const SizedBox(height: 3),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w700,
                color: foreground,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================================
// DIALOG BUTTON
// ============================================================================

class _DialogButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final Color foreground;

  const _DialogButton({
    required this.text,
    required this.icon,
    required this.foreground,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 42, minWidth: 90),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppTheme.surface3,
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: AppTheme.borderLight),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 17, color: foreground),
          const SizedBox(width: 6),
          Text(
            text,
            style: TextStyle(fontWeight: FontWeight.w700, color: foreground),
          ),
        ],
      ),
    );
  }
}

// ============================================================================
// ADVANCED LABEL
// ============================================================================

class _AdvancedLabel extends StatelessWidget {
  final String text;

  const _AdvancedLabel({required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(
        text,
        style: const TextStyle(
          color: AppTheme.textSecondary,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

// ============================================================================
// TV DIRECTIONAL REGION
// ============================================================================

/// يمنع سهم ↑ و ↓ داخل TextField / Dropdown
/// من التحول إلى تمرير الصفحة.
///
/// بدلاً من ذلك يتم استخدامهما للتنقل بين عناصر Flutter.
///
/// تركنا ← و → بدون اعتراض حتى يظل:
/// - تحريك مؤشر الكتابة داخل TextField
/// - والتنقل الطبيعي داخل العناصر
/// يعملان بصورة سليمة.
class _TvDirectionalRegion extends StatelessWidget {
  final Widget child;

  const _TvDirectionalRegion({required this.child});

  @override
  Widget build(BuildContext context) {
    return child;
  }
}

// ============================================================================
// TV EDITABLE TEXT FIELD
// ============================================================================

/// يجعل حقل النص محطة مستقلة في تنقل التلفزيون.
///
/// التركيز الخارجي يتنقل بالـ D-pad، وOK يدخل وضع التحرير. أثناء التحرير
/// يذهب الإدخال إلى EditableText مباشرة، ثم يعيد Back/Escape التركيز إلى
/// المحطة الخارجية من دون إغلاق الصفحة أو تمريرها.
class _TvEditableTextField extends StatefulWidget {
  final TextEditingController? controller;
  final bool enabled;
  final TextDirection? textDirection;
  final TextInputType? keyboardType;
  final List<TextInputFormatter>? inputFormatters;
  final InputDecoration decoration;
  final bool autocorrect;
  final bool enableSuggestions;
  final ValueChanged<String>? onChanged;
  final TheebFocusZone focusZone;

  const _TvEditableTextField({
    this.controller,
    this.enabled = true,
    this.textDirection,
    this.keyboardType,
    this.inputFormatters,
    required this.decoration,
    this.autocorrect = true,
    this.enableSuggestions = true,
    this.onChanged,
    this.focusZone = TheebFocusZone.advanced,
  });

  @override
  State<_TvEditableTextField> createState() => _TvEditableTextFieldState();
}

class _TvEditableTextFieldState extends State<_TvEditableTextField> {
  late final FocusNode _navigationNode;
  late final FocusNode _editorNode;
  bool _editing = false;
  bool _leavingWithBack = false;

  @override
  void initState() {
    super.initState();
    _navigationNode = FocusNode(debugLabel: 'AdvancedTextNavigation');
    _editorNode = FocusNode(
      debugLabel: 'AdvancedTextEditor',
      canRequestFocus: false,
      skipTraversal: true,
    );
  }

  @override
  void didUpdateWidget(covariant _TvEditableTextField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.enabled && !widget.enabled && _editing) {
      _finishEditing();
    }
  }

  @override
  void dispose() {
    _navigationNode.dispose();
    _editorNode.dispose();
    super.dispose();
  }

  void _startEditing() {
    if (!widget.enabled || _editing) return;
    setState(() => _editing = true);
    _editorNode.canRequestFocus = true;
    _editorNode.requestFocus();
  }

  void _finishEditing() {
    if (!_editing && !_leavingWithBack) return;
    _leavingWithBack = false;
    if (mounted && _editing) setState(() => _editing = false);
    _editorNode.canRequestFocus = false;
    _navigationNode.requestFocus();
  }

  bool _isBackKey(LogicalKeyboardKey key) {
    return key == LogicalKeyboardKey.escape || key == LogicalKeyboardKey.goBack;
  }

  KeyEventResult _handleEditorKey(FocusNode node, KeyEvent event) {
    if (_isBackKey(event.logicalKey)) {
      if (event is KeyDownEvent) {
        _leavingWithBack = true;
        if (_editing) setState(() => _editing = false);
      } else if (event is KeyUpEvent && _leavingWithBack) {
        _finishEditing();
      }
      return KeyEventResult.handled;
    }

    // EditableText يأخذ الأسهم أولًا. إن لم يستخدم ↑/↓ في الحقل أحادي السطر
    // نستهلكهما هنا كي لا يتحولا إلى تمرير للصفحة.
    if (event.logicalKey == LogicalKeyboardKey.arrowUp ||
        event.logicalKey == LogicalKeyboardKey.arrowDown ||
        event.logicalKey == LogicalKeyboardKey.channelUp ||
        event.logicalKey == LogicalKeyboardKey.channelDown) {
      return KeyEventResult.handled;
    }

    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    return TheebTvFocusable(
      focusNode: _navigationNode,
      focusZone: widget.focusZone,
      enabled: widget.enabled,
      onPressed: _startEditing,
      showFocusBorder: true,
      scaleOnFocus: false,
      borderRadius: BorderRadius.circular(8),
      child: Focus(
        onKeyEvent: _handleEditorKey,
        child: TextField(
          controller: widget.controller,
          focusNode: _editorNode,
          enabled: widget.enabled,
          readOnly: !_editing,
          showCursor: _editing,
          textDirection: widget.textDirection,
          keyboardType: widget.keyboardType,
          inputFormatters: widget.inputFormatters,
          decoration: widget.decoration,
          autocorrect: widget.autocorrect,
          enableSuggestions: widget.enableSuggestions,
          onChanged: widget.onChanged,
          onTap: _startEditing,
        ),
      ),
    );
  }
}
