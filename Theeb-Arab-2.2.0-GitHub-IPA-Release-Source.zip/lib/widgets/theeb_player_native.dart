import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../core/app_theme.dart';
import 'tv_focusable.dart';

class TheebPlayer extends StatefulWidget {
  final String url;
  final bool externalLoading;
  final bool active;

  const TheebPlayer({
    super.key,
    required this.url,
    this.externalLoading = false,
    this.active = true,
  });

  @override
  State<TheebPlayer> createState() => _TheebPlayerState();
}

class _TheebPlayerState extends State<TheebPlayer> {
  WebViewController? _controller;

  bool _loading = true;
  bool _hasError = false;

  String? _error;

  String? _currentMainFrameUrl;
  Timer? _loadingFallbackTimer;

  bool get _supported {
    return defaultTargetPlatform == TargetPlatform.android ||
        defaultTargetPlatform == TargetPlatform.iOS;
  }

  @override
  void initState() {
    super.initState();

    if (_supported) {
      _initialize();
    } else {
      _loading = false;
    }
  }

  @override
  void didUpdateWidget(covariant TheebPlayer oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (!_supported) {
      return;
    }

    if (oldWidget.url != widget.url) {
      _cancelLoadingFallback();
      _loadUrl();
    }

    if (oldWidget.active != widget.active) {
      unawaited(_setPlaybackActive(widget.active));
    }
  }

  Future<void> _initialize() async {
    try {
      final controller = WebViewController();

      await controller.setJavaScriptMode(JavaScriptMode.unrestricted);

      await controller.setBackgroundColor(Colors.black);

      await controller.setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: _handleNavigationRequest,

          onPageStarted: (url) {
            _currentMainFrameUrl = url;

            if (!mounted) {
              return;
            }

            setState(() {
              _loading = true;
              _hasError = false;
              _error = null;
            });

            _ensureLoadingFallback();
          },

          onPageFinished: (url) async {
            _currentMainFrameUrl = url;

            _cancelLoadingFallback();

            if (!mounted) {
              return;
            }

            setState(() {
              _loading = false;
              _hasError = false;
              _error = null;
            });

            await _installPlayerGuards();
            await _setPlaybackActive(widget.active);
          },

          onWebResourceError: (error) {
            if (!mounted) {
              return;
            }

            /*
             * موارد المشغل الفرعية قد تفشل أحياناً
             * بدون أن يعني ذلك أن الصفحة الرئيسية فشلت.
             */
            if (error.isForMainFrame == false) {
              return;
            }

            _cancelLoadingFallback();

            setState(() {
              _loading = false;
              _hasError = true;
              _error = error.description;
            });
          },
        ),
      );

      _controller = controller;

      await _loadUrl();
    } catch (error) {
      if (!mounted) {
        return;
      }

      setState(() {
        _loading = false;
        _hasError = true;
        _error = error.toString();
      });
    }
  }

  void _ensureLoadingFallback() {
    if (_loadingFallbackTimer?.isActive == true) {
      return;
    }

    /*
     * AnaPlayer وبعض مشغلات Android TV تبقي اتصال الصفحة مفتوحاً،
     * لذلك قد لا يصل onPageFinished رغم ظهور واجهة المشغل فعلياً.
     * انتهاء هذه المهلة يخفي الغطاء فقط، ولا يعتبر الرابط فاشلاً.
     */
    _loadingFallbackTimer = Timer(const Duration(seconds: 4), () {
      if (!mounted || !_loading || _hasError) {
        return;
      }

      setState(() {
        _loading = false;
      });
    });
  }

  void _cancelLoadingFallback() {
    _loadingFallbackTimer?.cancel();
    _loadingFallbackTimer = null;
  }

  @override
  void dispose() {
    _cancelLoadingFallback();
    super.dispose();
  }

  NavigationDecision _handleNavigationRequest(NavigationRequest request) {
    /*
     * الموارد الداخلية مثل HLS والصور والسكريبتات
     * لا نمنعها من هنا.
     *
     * الفلترة مخصصة لتنقل الصفحة الرئيسية فقط.
     */
    if (!request.isMainFrame) {
      return NavigationDecision.navigate;
    }

    final uri = Uri.tryParse(request.url);

    if (uri == null) {
      debugPrint('[THEEB] Blocked malformed navigation: ${request.url}');

      return NavigationDecision.prevent;
    }

    if (!_isHttpUrl(uri)) {
      debugPrint('[THEEB] Blocked non-http navigation: ${request.url}');

      return NavigationDecision.prevent;
    }

    if (!_isAllowedPlayerHost(uri.host)) {
      debugPrint('[THEEB] Blocked external navigation: ${request.url}');

      return NavigationDecision.prevent;
    }

    return NavigationDecision.navigate;
  }

  bool _isHttpUrl(Uri uri) {
    return uri.scheme == 'https' || uri.scheme == 'http';
  }

  bool _isAllowedPlayerHost(String host) {
    final normalized = host.trim().toLowerCase();

    if (normalized.isEmpty) {
      return false;
    }

    /*
     * النطاق الأساسي للمشغل.
     */
    if (normalized == 'anaplayer.online') {
      return true;
    }

    /*
     * جميع Subdomains الخاصة بنفس المشغل:
     *
     * w.anaplayer.online
     * xxx.anaplayer.online
     */
    if (normalized.endsWith('.anaplayer.online')) {
      return true;
    }

    /*
     * ندعم أيضاً نفس Host الموجود في الرابط الحالي
     * لو تم مستقبلاً تغيير مزود المشغل.
     */
    final sourceUri = Uri.tryParse(widget.url.trim());

    if (sourceUri != null) {
      final sourceHost = sourceUri.host.trim().toLowerCase();

      if (sourceHost.isNotEmpty && normalized == sourceHost) {
        return true;
      }
    }

    return false;
  }

  Future<void> _setPlaybackActive(bool active) async {
    final controller = _controller;
    if (controller == null) return;
    try {
      await controller.runJavaScript(
        active
            ? "document.querySelectorAll('video').forEach(v=>{if(v.autoplay||v.dataset.theebWasPlaying==='1'){v.play().catch(()=>{});}});"
            : "document.querySelectorAll('video,audio').forEach(v=>{try{v.dataset.theebWasPlaying=v.paused?'0':'1';v.pause();}catch(_){}});",
      );
    } catch (_) {}
  }

  Future<void> _loadUrl() async {
    final controller = _controller;

    if (controller == null) {
      return;
    }

    final rawUrl = widget.url.trim();

    final uri = Uri.tryParse(rawUrl);

    if (uri == null || !uri.hasScheme || !_isHttpUrl(uri)) {
      if (!mounted) {
        return;
      }

      setState(() {
        _loading = false;
        _hasError = true;
        _error = 'الرابط غير صالح';
      });

      return;
    }

    if (!mounted) {
      return;
    }

    setState(() {
      _loading = true;
      _hasError = false;
      _error = null;
    });

    _cancelLoadingFallback();
    _ensureLoadingFallback();

    try {
      _currentMainFrameUrl = rawUrl;
      final directStream =
          uri.path.toLowerCase().contains('.m3u8') ||
          uri.path.toLowerCase().contains('.mp4');
      if (directStream) {
        final safeUrl = rawUrl
            .replaceAll('&', '&amp;')
            .replaceAll('"', '&quot;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;');
        await controller.loadHtmlString('''
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#000}video{width:100%;height:100%;object-fit:contain;background:#000}</style>
</head><body><video src="$safeUrl" controls autoplay playsinline></video></body></html>
''', baseUrl: '${uri.scheme}://${uri.host}/');
      } else {
        await controller.loadRequest(uri);
      }
    } catch (error) {
      if (!mounted) {
        return;
      }

      setState(() {
        _loading = false;
        _hasError = true;
        _error = error.toString();
      });
    }
  }

  Future<void> _installPlayerGuards() async {
    final controller = _controller;

    if (controller == null) {
      return;
    }

    try {
      await controller.runJavaScript('''
(() => {
  try {
    /*
     * ------------------------------------------------------------
     * THEEB NATIVE PLAYER GUARD
     * ------------------------------------------------------------
     */

    const THEEB_ALLOWED_DOMAIN = 'anaplayer.online';

    const isAllowedUrl = (value) => {
      try {
        const url = new URL(
          value,
          window.location.href
        );

        const protocol = url.protocol.toLowerCase();

        if (
          protocol !== 'http:' &&
          protocol !== 'https:'
        ) {
          return false;
        }

        const host = url.hostname.toLowerCase();

        return (
          host === THEEB_ALLOWED_DOMAIN ||
          host.endsWith('.' + THEEB_ALLOWED_DOMAIN)
        );
      } catch (_) {
        return false;
      }
    };

    /*
     * إزالة طبقات إعلانية معرّفة بوضوح فقط. نتجنب المحددات العامة مثل
     * iframe أو position:fixed، ولا نحذف أي عنصر يحتوي الفيديو أو تحكماته.
     */
    const removeKnownAdOverlays = (root) => {
      const selectors = [
        '[id*="popunder" i]', '[class*="popunder" i]',
        '[id*="interstitial" i]', '[class*="interstitial-ad" i]',
        '[id*="ad-overlay" i]', '[class*="ad-overlay" i]',
        '[id*="anti-adblock" i]', '[class*="anti-adblock" i]',
        '[data-ad-overlay]', '[aria-label="Advertisement"]'
      ];

      for (const selector of selectors) {
        try {
          (root || document).querySelectorAll(selector).forEach((element) => {
            if (!element.querySelector('video, .video-js, .jwplayer, .plyr')) {
              element.remove();
            }
          });
        } catch (_) {}
      }

      try {
        (root || document).querySelectorAll('img').forEach((image) => {
          const text = (
            (image.alt || '') + ' ' +
            (image.title || '') + ' ' +
            (image.getAttribute('aria-label') || '')
          ).toLowerCase();
          const source = (image.currentSrc || image.src || '').toLowerCase();
          if (!text.includes('qr') && !source.includes('qr-code') &&
              !source.includes('qrcode')) return;
          const overlay = image.closest(
            '[role="dialog"], [class*="overlay" i], [class*="modal" i]'
          );
          if (overlay && !overlay.querySelector('video')) overlay.remove();
        });
      } catch (_) {}

      /*
       * طبقات QR/التحقق التي تُحقن بلا أسماء ثابتة. نخفي أقرب طبقة فقط
       * ونترك علامة قابلة للتراجع بدل حذف DOM نهائيًا. لا نلمس أي حاوية
       * تحتوي video أو جذور المشغلات المعروفة.
       */
      try {
        const phrases = [
          'confirm you are not a robot',
          "confirm you're not a robot",
          'scan the qr code',
          'scan qr code'
        ];
        (root || document).querySelectorAll(
          '[role="dialog"], [class*="overlay" i], [class*="modal" i]'
        ).forEach((element) => {
          const text = (element.innerText || '').trim().toLowerCase();
          if (!phrases.some((phrase) => text.includes(phrase))) return;
          if (element.querySelector('video, .video-js, .jwplayer, .plyr')) return;
          if (!element.hasAttribute('data-theeb-original-display')) {
            element.setAttribute(
              'data-theeb-original-display',
              element.style.display || ''
            );
          }
          element.setAttribute('data-theeb-hidden-overlay', 'true');
          element.style.setProperty('display', 'none', 'important');
        });
      } catch (_) {}

      try {
        (root || document).querySelectorAll('iframe').forEach((frame) => {
          const signature = (
            (frame.src || '') + ' ' + (frame.title || '') + ' ' +
            (frame.name || '') + ' ' + (frame.id || '') + ' ' +
            (frame.className || '')
          ).toLowerCase();
          if (!/(qrcode|qr-code|captcha|not.?a.?robot|verify.?human)/.test(signature)) {
            return;
          }
          frame.setAttribute('data-theeb-hidden-overlay', 'true');
          frame.style.setProperty('display', 'none', 'important');
        });
      } catch (_) {}
    };

    window.__theebRestoreHiddenOverlays = function() {
      try {
        document.querySelectorAll('[data-theeb-hidden-overlay="true"]')
          .forEach((element) => {
            const original = element.getAttribute('data-theeb-original-display') || '';
            element.style.removeProperty('display');
            if (original) element.style.display = original;
            element.removeAttribute('data-theeb-hidden-overlay');
            element.removeAttribute('data-theeb-original-display');
          });
      } catch (_) {}
    };

    removeKnownAdOverlays(document);

    /* تحويل D-pad داخل صفحة المشغل إلى نفس مسار Tab الناجح على TCL. */
    const installRemoteNavigation = (doc) => {
      try {
        if (!doc || doc.__theebRemoteNavigationInstalled) return;
        doc.__theebRemoteNavigationInstalled = true;
        doc.addEventListener('keydown', (event) => {
          const key = event.key;
          const keyCode = event.keyCode || event.which;
          const active = doc.activeElement;
          const interactiveValue = active && (
            active.matches('input, select, textarea, video, [role="slider"]') ||
            active.hasAttribute('aria-valuenow')
          );
          if (interactiveValue && (key === 'ArrowLeft' || key === 'ArrowRight')) {
            return;
          }
          if (key === 'Enter' || key === 'Select') {
            if (active && typeof active.click === 'function') active.click();
            return;
          }
          if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(key)) {
            return;
          }
          const candidates = Array.from(doc.querySelectorAll(
            'button, a[href], input, select, [tabindex]:not([tabindex="-1"]), ' +
            '[role="button"], [role="slider"], video'
          )).filter((element) => {
            const style = doc.defaultView.getComputedStyle(element);
            const rect = element.getBoundingClientRect();
            return style.display !== 'none' && style.visibility !== 'hidden' &&
              rect.width > 0 && rect.height > 0 && !element.disabled;
          });
          if (!candidates.length) return;
          const current = candidates.indexOf(active);
          const backwards = key === 'ArrowLeft' || key === 'ArrowUp';
          const next = current < 0
            ? (backwards ? candidates.length - 1 : 0)
            : (current + (backwards ? -1 : 1) + candidates.length) % candidates.length;
          candidates[next].focus({preventScroll: true});
          event.preventDefault();
          event.stopPropagation();
        }, true);
        doc.querySelectorAll('iframe').forEach((frame) => {
          try { installRemoteNavigation(frame.contentDocument); } catch (_) {}
        });
      } catch (_) {}
    };
    installRemoteNavigation(document);

    /*
     * ------------------------------------------------------------
     * Popup guard
     * ------------------------------------------------------------
     *
     * هذه طبقة مؤقتة فقط وليست الحل الجذري للإعلانات.
     */
    try {
      window.open = function(url) {
        if (
          typeof url === 'string' &&
          isAllowedUrl(url)
        ) {
          return null;
        }

        return null;
      };
    } catch (_) {}

    /*
     * ------------------------------------------------------------
     * Links guard
     * ------------------------------------------------------------
     */
    if (!window.__theebLinkGuardInstalled) {
      window.__theebLinkGuardInstalled = true;

      document.addEventListener(
        'click',
        function(event) {
          try {
            const target = event.target;

            if (!target) {
              return;
            }

            const anchor =
              target.closest &&
              target.closest('a[href]');

            if (!anchor) {
              return;
            }

            const href =
              anchor.getAttribute('href');

            if (!href) {
              return;
            }

            if (!isAllowedUrl(href)) {
              event.preventDefault();
              event.stopPropagation();

              if (event.stopImmediatePropagation) {
                event.stopImmediatePropagation();
              }

              return false;
            }

            /*
             * لا نسمح target="_blank".
             */
            try {
              anchor.removeAttribute('target');
            } catch (_) {}
          } catch (_) {}
        },
        true
      );
    }

    /*
     * ------------------------------------------------------------
     * إزالة target=_blank من الروابط الحالية
     * ------------------------------------------------------------
     */
    try {
      document
        .querySelectorAll('a[target="_blank"]')
        .forEach((anchor) => {
          try {
            anchor.removeAttribute('target');
          } catch (_) {}
        });
    } catch (_) {}

    /*
     * ------------------------------------------------------------
     * مراقبة الروابط التي يتم إنشاؤها لاحقاً بالـ JavaScript
     * ------------------------------------------------------------
     */
    if (!window.__theebMutationGuardInstalled) {
      window.__theebMutationGuardInstalled = true;

      try {
        const observer = new MutationObserver(
          function(mutations) {
            for (const mutation of mutations) {
              for (const node of mutation.addedNodes) {
                if (!node) {
                  continue;
                }

                try {
                  if (node.nodeType === 1) {
                    removeKnownAdOverlays(node);
                    if (node.matches && node.matches('iframe')) {
                      try { installRemoteNavigation(node.contentDocument); } catch (_) {}
                    }
                  }
                  if (
                    node.matches &&
                    node.matches('a[target="_blank"]')
                  ) {
                    node.removeAttribute('target');
                  }

                  if (node.querySelectorAll) {
                    node
                      .querySelectorAll('a[target="_blank"]')
                      .forEach((anchor) => {
                        try {
                          anchor.removeAttribute(
                            'target'
                          );
                        } catch (_) {}
                      });
                  }
                } catch (_) {}
              }
            }
          }
        );

        observer.observe(
          document.documentElement || document.body,
          {
            childList: true,
            subtree: true
          }
        );
      } catch (_) {}
    }

    /*
     * ------------------------------------------------------------
     * إعداد الفيديو للجوال وTV
     * ------------------------------------------------------------
     */
    try {
      document
        .querySelectorAll('video')
        .forEach((video) => {
          try {
            video.setAttribute(
              'playsinline',
              ''
            );

            video.setAttribute(
              'webkit-playsinline',
              ''
            );

            video.setAttribute(
              'x-webkit-airplay',
              'allow'
            );

            /*
             * لا نجبر mute.
             */
            const playResult = video.play();

            if (
              playResult &&
              typeof playResult.catch === 'function'
            ) {
              playResult.catch(() => {});
            }
          } catch (_) {}
        });
    } catch (_) {}

    /*
     * ------------------------------------------------------------
     * محاولة تشغيل أشهر أنواع المشغلات
     * ------------------------------------------------------------
     */
    const selectors = [
      '.vjs-big-play-button',
      '.jw-icon-playback',
      '.plyr__control--overlaid',
      '.video-js .vjs-big-play-button'
    ];

    for (const selector of selectors) {
      try {
        const button =
          document.querySelector(selector);

        if (button) {
          button.click();
          break;
        }
      } catch (_) {}
    }
  } catch (_) {}
})();
''');
    } catch (_) {
      /*
       * عدم نجاح JavaScript Injection لا يعني
       * أن WebView نفسه فشل.
       */
    }
  }

  Future<void> _reload() async {
    final controller = _controller;

    if (controller == null) {
      await _initialize();
      return;
    }

    if (mounted) {
      setState(() {
        _loading = true;
        _hasError = false;
        _error = null;
      });
    }

    _cancelLoadingFallback();
    _ensureLoadingFallback();

    try {
      await controller.reload();
    } catch (_) {
      await _loadUrl();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_supported) {
      return const ColoredBox(
        color: Colors.black,
        child: Center(
          child: Icon(
            Icons.play_circle_outline,
            size: 62,
            color: AppTheme.info,
          ),
        ),
      );
    }

    final controller = _controller;

    if (controller == null) {
      if (_hasError) {
        return _ErrorView(
          message: _error ?? 'تعذر تشغيل المشغل',
          retry: _initialize,
        );
      }

      return const ColoredBox(
        color: Colors.black,
        child: Center(child: CircularProgressIndicator(color: AppTheme.info)),
      );
    }

    return ColoredBox(
      color: Colors.black,
      child: Stack(
        fit: StackFit.expand,
        children: [
          WebViewWidget(controller: controller),

          if (_hasError)
            _ErrorView(message: _error ?? 'تعذر تحميل المشغل', retry: _reload),

          if (!_hasError && (_loading || widget.externalLoading))
            const _LoadingView(),

          if (kDebugMode &&
              !_loading &&
              !_hasError &&
              _currentMainFrameUrl != null)
            const PositionedDirectional(
              bottom: 6,
              end: 6,
              child: IgnorePointer(child: _DebugNativeBadge()),
            ),
        ],
      ),
    );
  }
}

class _LoadingView extends StatelessWidget {
  const _LoadingView();

  @override
  Widget build(BuildContext context) {
    return const IgnorePointer(
      child: ColoredBox(
        color: Color(0xEE0A0A0F),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(color: AppTheme.info),
              SizedBox(height: 14),
              Text(
                'جاري تحميل المشغل...',
                style: TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  color: AppTheme.textSecondary,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;

  final Future<void> Function() retry;

  const _ErrorView({required this.message, required this.retry});

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: const Color(0xF20A0A0F),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, color: AppTheme.danger, size: 45),

              const SizedBox(height: 10),

              const Text(
                'تعذر تحميل المشغل',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                message,
                textAlign: TextAlign.center,
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  color: AppTheme.textSecondary,
                  fontSize: 11,
                ),
              ),

              const SizedBox(height: 14),

              TheebTvFocusable(
                autofocus: true,
                onPressed: () {
                  retry();
                },
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  constraints: const BoxConstraints(
                    minHeight: 46,
                    minWidth: 170,
                  ),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 10,
                  ),
                  decoration: BoxDecoration(
                    color: AppTheme.surface3,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppTheme.borderLight),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.refresh, color: AppTheme.info, size: 19),
                      SizedBox(width: 7),
                      Text(
                        'إعادة المحاولة',
                        style: TextStyle(
                          fontFamily: AppTheme.fontFamily,
                          color: AppTheme.textPrimary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DebugNativeBadge extends StatelessWidget {
  const _DebugNativeBadge();

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: Colors.black54,
        borderRadius: BorderRadius.circular(5),
      ),
      child: const Padding(
        padding: EdgeInsets.symmetric(horizontal: 6, vertical: 3),
        child: Text(
          'NATIVE',
          style: TextStyle(
            color: AppTheme.textMuted,
            fontSize: 8,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}
