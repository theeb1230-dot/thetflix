import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/app_theme.dart';
import '../tv/tv_focus_manager.dart';

/// عنصر Focus موحد لتطبيق ذيب.
///
/// يدعم:
/// - Android TV / Google TV / TCL Remote
/// - D-pad
/// - Enter / OK / Select
/// - Space
/// - Gamepad A
/// - Escape / Back
/// - Keyboard
/// - Mouse
/// - Touch
///
/// هذا العنصر مربوط بمدير Focus المركزي الخاص بذيب.
///
/// أهم نقطة:
/// الأسهم لا تُترك للـ ScrollView بصورة عشوائية.
/// يتم توجيهها أولاً عبر TheebTvFocusManager.
class TheebTvFocusable extends StatefulWidget {
  final Widget child;

  /// الإجراء الأساسي عند OK / Enter / Click / Touch.
  final VoidCallback? onPressed;

  /// إجراء اختياري عند زر الرجوع.
  final VoidCallback? onBack;

  /// FocusNode خارجي إذا أردنا التحكم يدويًا بالتركيز.
  final FocusNode? focusNode;

  /// التركيز التلقائي عند ظهور العنصر.
  final bool autofocus;

  /// هل العنصر قابل للاستخدام والتركيز؟
  final bool enabled;

  /// المنطقة التي ينتمي لها العنصر.
  final TheebFocusZone? focusZone;

  /// هل هذا العنصر هو نقطة الدخول الافتراضية للمنطقة؟
  final bool registerAsDefault;

  /// شكل حواف العنصر.
  final BorderRadius borderRadius;

  /// Padding إضافي حول العنصر.
  final EdgeInsetsGeometry padding;

  /// إظهار إطار وإضاءة عند التركيز.
  final bool showFocusBorder;

  /// تكبير العنصر عند التركيز.
  final bool scaleOnFocus;

  /// نسبة التكبير عند التركيز.
  final double focusScale;

  /// نسبة التصغير أثناء الضغط.
  final double pressedScale;

  /// ينفذ عند دخول Focus.
  final VoidCallback? onFocusReceived;

  /// ينفذ عند خروج Focus.
  final VoidCallback? onFocusLost;

  /// هل الماوس ينقل Focus للعنصر؟
  final bool focusOnHover;

  /// هل النقر/اللمس ينقل Focus للعنصر؟
  final bool focusOnTap;

  const TheebTvFocusable({
    super.key,
    required this.child,
    this.onPressed,
    this.onBack,
    this.focusNode,
    this.autofocus = false,
    this.enabled = true,
    this.focusZone,
    this.registerAsDefault = false,
    this.borderRadius = const BorderRadius.all(Radius.circular(8)),
    this.padding = EdgeInsets.zero,
    this.showFocusBorder = true,
    this.scaleOnFocus = true,
    this.focusScale = 1.06,
    this.pressedScale = 0.97,
    this.onFocusReceived,
    this.onFocusLost,
    this.focusOnHover = false,
    this.focusOnTap = true,
  });

  @override
  State<TheebTvFocusable> createState() => _TheebTvFocusableState();
}

class _TheebTvFocusableState extends State<TheebTvFocusable> {
  final TheebTvFocusManager _focusManager = TheebTvFocusManager.instance;

  FocusNode? _internalFocusNode;

  bool _focused = false;
  bool _hovered = false;

  bool _pointerPressed = false;
  bool _keyboardPressed = false;

  bool get _pressed => _pointerPressed || _keyboardPressed;

  FocusNode get _effectiveFocusNode {
    return widget.focusNode ??
        (_internalFocusNode ??= FocusNode(debugLabel: 'TheebTvFocusable'));
  }

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }

      _registerWithFocusManager();
    });
  }

  @override
  void didUpdateWidget(covariant TheebTvFocusable oldWidget) {
    super.didUpdateWidget(oldWidget);

    final nodeChanged = oldWidget.focusNode != widget.focusNode;
    final zoneChanged = oldWidget.focusZone != widget.focusZone;
    final defaultChanged =
        oldWidget.registerAsDefault != widget.registerAsDefault;

    if (nodeChanged || zoneChanged || defaultChanged) {
      final oldNode = oldWidget.focusNode ?? _internalFocusNode;

      if (oldNode != null) {
        _focusManager.unregisterNode(oldNode);
      }

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) {
          return;
        }

        _registerWithFocusManager();
      });
    }

    if (oldWidget.enabled && !widget.enabled) {
      if (_effectiveFocusNode.hasFocus) {
        _effectiveFocusNode.unfocus();
      }

      if (_pointerPressed || _keyboardPressed || _hovered) {
        setState(() {
          _pointerPressed = false;
          _keyboardPressed = false;
          _hovered = false;
        });
      }
    }

    if (!oldWidget.enabled && widget.enabled) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) {
          return;
        }

        _registerWithFocusManager();
      });
    }
  }

  @override
  void dispose() {
    final node = widget.focusNode ?? _internalFocusNode;

    if (node != null) {
      _focusManager.unregisterNode(node);
    }

    _internalFocusNode?.dispose();

    super.dispose();
  }

  // ============================================================
  // FOCUS MANAGER REGISTRATION
  // ============================================================

  void _registerWithFocusManager() {
    if (!widget.enabled) {
      return;
    }

    final zone = widget.focusZone;

    if (zone == null) {
      return;
    }

    final node = _effectiveFocusNode;

    _focusManager.registerNode(zone: zone, node: node);

    if (widget.registerAsDefault) {
      _focusManager.registerDefault(zone: zone, node: node);
    }

    if (node.hasFocus) {
      _focusManager.rememberFocus(zone: zone, node: node);
    }
  }

  // ============================================================
  // KEY TYPES
  // ============================================================

  bool _isActivationKey(LogicalKeyboardKey key) {
    return key == LogicalKeyboardKey.enter ||
        key == LogicalKeyboardKey.select ||
        key == LogicalKeyboardKey.space ||
        key == LogicalKeyboardKey.gameButtonA;
  }

  bool _isBackKey(LogicalKeyboardKey key) {
    return key == LogicalKeyboardKey.escape || key == LogicalKeyboardKey.goBack;
  }

  bool _isDirectionalKey(LogicalKeyboardKey key) {
    return key == LogicalKeyboardKey.arrowLeft ||
        key == LogicalKeyboardKey.arrowRight ||
        key == LogicalKeyboardKey.arrowUp ||
        key == LogicalKeyboardKey.arrowDown ||
        key == LogicalKeyboardKey.channelUp ||
        key == LogicalKeyboardKey.channelDown;
  }

  // ============================================================
  // ACTIONS
  // ============================================================

  void _activate() {
    if (!widget.enabled) {
      return;
    }

    widget.onPressed?.call();
  }

  void _handleBack() {
    if (!widget.enabled) {
      return;
    }

    widget.onBack?.call();
  }

  // ============================================================
  // FOCUS CHANGE
  // ============================================================

  void _handleFocusChange(bool focused) {
    if (_focused == focused) {
      return;
    }

    setState(() {
      _focused = focused;

      if (!focused) {
        _keyboardPressed = false;
      }
    });

    final zone = widget.focusZone;

    if (focused) {
      if (zone != null) {
        _focusManager.rememberFocus(zone: zone, node: _effectiveFocusNode);
      }

      _ensureVisible();

      widget.onFocusReceived?.call();
    } else {
      _focusManager.notifyFocusLost(_effectiveFocusNode);

      widget.onFocusLost?.call();
    }
  }

  Future<void> _ensureVisible() async {
    if (!mounted || !_focused) {
      return;
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_focused) {
        return;
      }

      try {
        Scrollable.ensureVisible(
          context,
          alignment: 0.5,
          alignmentPolicy: ScrollPositionAlignmentPolicy.keepVisibleAtEnd,
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOutCubic,
        );
      } catch (_) {
        // العنصر قد لا يكون داخل Scrollable.
      }
    });
  }

  // ============================================================
  // D-PAD
  // ============================================================

  // ============================================================
  // KEYBOARD / REMOTE
  // ============================================================

  KeyEventResult _handleKeyEvent(FocusNode node, KeyEvent event) {
    if (!widget.enabled) {
      return KeyEventResult.ignored;
    }

    // عندما يكون التركيز الحقيقي داخل عنصر ابن (مثل EditableText)، يجب أن
    // يحصل الابن على لوحة المفاتيح كاملة. اعتراض الحدث هنا كان يجعل مدير
    // تنقل التلفزيون يسرق الأسهم وEnter من TextField أثناء التحرير.
    if (node.hasFocus && !node.hasPrimaryFocus) {
      return KeyEventResult.ignored;
    }

    final key = event.logicalKey;

    // ============================================================
    // OK / ENTER / SELECT / SPACE / GAMEPAD A
    // ============================================================

    if (_isActivationKey(key)) {
      if (event is KeyDownEvent) {
        if (!_keyboardPressed) {
          setState(() {
            _keyboardPressed = true;
          });
        }

        return KeyEventResult.handled;
      }

      if (event is KeyUpEvent) {
        final shouldActivate = _keyboardPressed;

        if (_keyboardPressed) {
          setState(() {
            _keyboardPressed = false;
          });
        }

        if (shouldActivate) {
          _activate();
        }

        return KeyEventResult.handled;
      }

      // KeyRepeatEvent.
      //
      // نستهلكه حتى لا يتكرر الضغط عدة مرات
      // عند إبقاء OK مضغوطًا.
      return KeyEventResult.handled;
    }

    // ============================================================
    // BACK / ESCAPE
    // ============================================================

    if (_isBackKey(key)) {
      if (widget.onBack == null) {
        return KeyEventResult.ignored;
      }

      if (event is KeyDownEvent) {
        _handleBack();
      }

      return KeyEventResult.handled;
    }

    // ============================================================
    // D-PAD
    // ============================================================

    if (_isDirectionalKey(key)) return KeyEventResult.ignored;

    return KeyEventResult.ignored;
  }

  // ============================================================
  // POINTER FOCUS
  // ============================================================

  void _requestOwnFocus() {
    if (!widget.enabled) {
      return;
    }

    if (_effectiveFocusNode.hasFocus) {
      return;
    }

    final zone = widget.focusZone;

    if (zone != null) {
      final requested = _focusManager.requestFocus(
        zone: zone,
        node: _effectiveFocusNode,
      );

      if (requested) {
        return;
      }
    }

    _effectiveFocusNode.requestFocus();
  }

  void _handlePointerDown() {
    if (!widget.enabled) {
      return;
    }

    if (widget.focusOnTap) {
      _requestOwnFocus();
    }

    if (!_pointerPressed) {
      setState(() {
        _pointerPressed = true;
      });
    }
  }

  void _handlePointerCancel() {
    if (!_pointerPressed) {
      return;
    }

    setState(() {
      _pointerPressed = false;
    });
  }

  void _handlePointerUp() {
    if (!widget.enabled) {
      return;
    }

    if (_pointerPressed) {
      setState(() {
        _pointerPressed = false;
      });
    }

    if (widget.focusOnTap) {
      _requestOwnFocus();
    }

    _activate();
  }

  // ============================================================
  // MOUSE
  // ============================================================

  void _handleHoverEnter() {
    if (!widget.enabled) {
      return;
    }

    if (!_hovered) {
      setState(() {
        _hovered = true;
      });
    }

    if (widget.focusOnHover) {
      _requestOwnFocus();
    }
  }

  void _handleHoverExit() {
    if (!_hovered && !_pointerPressed) {
      return;
    }

    setState(() {
      _hovered = false;
      _pointerPressed = false;
    });
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    final highlighted = widget.enabled && (_focused || _hovered);

    final scale = _pressed
        ? widget.pressedScale
        : widget.scaleOnFocus && _focused && widget.enabled
        ? widget.focusScale
        : 1.0;

    final borderColor = _focused
        ? AppTheme.info
        : _hovered
        ? AppTheme.info.withValues(alpha: 0.45)
        : Colors.transparent;

    final borderWidth = _focused ? 2.0 : 1.0;

    return Focus(
      focusNode: _effectiveFocusNode,
      autofocus: widget.autofocus,
      canRequestFocus: widget.enabled,
      skipTraversal: !widget.enabled,
      descendantsAreFocusable: widget.enabled,
      onFocusChange: _handleFocusChange,
      onKeyEvent: _handleKeyEvent,
      child: MouseRegion(
        cursor: widget.enabled
            ? SystemMouseCursors.click
            : SystemMouseCursors.basic,
        onEnter: (_) {
          _handleHoverEnter();
        },
        onExit: (_) {
          _handleHoverExit();
        },
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: widget.enabled
              ? (_) {
                  _handlePointerDown();
                }
              : null,
          onTapCancel: widget.enabled
              ? () {
                  _handlePointerCancel();
                }
              : null,
          onTapUp: widget.enabled
              ? (_) {
                  _handlePointerUp();
                }
              : null,
          child: AnimatedScale(
            scale: scale,
            duration: Duration(milliseconds: _pressed ? 80 : 130),
            curve: Curves.easeOutCubic,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              curve: Curves.easeOutCubic,
              padding: widget.padding,
              decoration: BoxDecoration(
                borderRadius: widget.borderRadius,
                border: widget.showFocusBorder
                    ? Border.all(color: borderColor, width: borderWidth)
                    : null,
                boxShadow: highlighted && widget.showFocusBorder
                    ? [
                        BoxShadow(
                          color: AppTheme.info.withValues(
                            alpha: _focused ? 0.30 : 0.15,
                          ),
                          blurRadius: _focused ? 18 : 10,
                          spreadRadius: _focused ? 1 : 0,
                        ),
                      ]
                    : null,
              ),
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 140),
                opacity: widget.enabled ? 1.0 : 0.42,
                child: widget.child,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
