export 'theeb_player_native.dart'
    if (dart.library.js_interop) 'theeb_player_web.dart';
