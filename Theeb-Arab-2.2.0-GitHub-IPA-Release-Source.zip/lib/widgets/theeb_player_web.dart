import 'dart:async';
import 'dart:ui_web' as ui_web;

import 'package:flutter/material.dart';
import 'package:web/web.dart' as web;

import '../core/app_theme.dart';

class TheebPlayer extends StatefulWidget {
  final String url;
  final bool externalLoading;
  final bool active;

  const TheebPlayer({
    super.key,
    required this.url,
    this.externalLoading = false,
    this.active = true,
  });

  @override
  State<TheebPlayer> createState() => _TheebPlayerState();
}

class _TheebPlayerState extends State<TheebPlayer> {
  late String _viewType;

  bool _loading = true;
  bool _hasError = false;

  String? _errorMessage;

  Timer? _fallbackTimer;
  Timer? _hardTimeoutTimer;

  int _generation = 0;

  @override
  void initState() {
    super.initState();

    _createIframe();
  }

  @override
  void didUpdateWidget(covariant TheebPlayer oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.url != widget.url) {
      _createIframe();
    }
  }

  @override
  void dispose() {
    _cancelTimers();

    super.dispose();
  }

  void _cancelTimers() {
    _fallbackTimer?.cancel();
    _fallbackTimer = null;

    _hardTimeoutTimer?.cancel();
    _hardTimeoutTimer = null;
  }

  bool _isValidPlayerUrl(String value) {
    final uri = Uri.tryParse(value);

    if (uri == null) {
      return false;
    }

    if (!uri.hasScheme) {
      return false;
    }

    if (uri.scheme != 'https' && uri.scheme != 'http') {
      return false;
    }

    if (uri.host.trim().isEmpty) {
      return false;
    }

    return true;
  }

  void _createIframe() {
    _cancelTimers();

    final currentUrl = widget.url.trim();

    if (!_isValidPlayerUrl(currentUrl)) {
      _generation++;

      _viewType =
          'theeb-player-invalid-${DateTime.now().microsecondsSinceEpoch}';

      if (mounted) {
        setState(() {
          _loading = false;
          _hasError = true;
          _errorMessage = 'رابط المشغل غير صالح';
        });
      }

      return;
    }

    final generation = ++_generation;

    _viewType =
        'theeb-player-$generation-${DateTime.now().microsecondsSinceEpoch}';

    _loading = true;
    _hasError = false;
    _errorMessage = null;

    ui_web.platformViewRegistry.registerViewFactory(_viewType, (int viewId) {
      final iframe = web.HTMLIFrameElement()
        ..src = currentUrl
        ..style.border = '0'
        ..style.width = '100%'
        ..style.height = '100%'
        ..style.backgroundColor = '#000000'
        ..style.display = 'block';

      /*
         * ----------------------------------------------------------
         * لا نستخدم sandbox حالياً.
         * ----------------------------------------------------------
         *
         * بعض المشغلات الخارجية تعتمد على قدرات داخلية تتعطل
         * عند فرض Sandbox مشدد.
         *
         * معالجة الإعلانات الجذرية ليست ضمن هذه الدفعة.
         */

      iframe.setAttribute(
        'allow',
        'autoplay; '
            'fullscreen; '
            'encrypted-media; '
            'picture-in-picture',
      );

      iframe.setAttribute('allowfullscreen', 'true');

      iframe.setAttribute('webkitallowfullscreen', 'true');

      iframe.setAttribute('referrerpolicy', 'origin-when-cross-origin');

      iframe.setAttribute('loading', 'eager');

      /*
         * منع ظهور Scrollbars الخاصة بالصفحة المضمنة
         * إذا كانت الصفحة تدعم الخاصية.
         */
      iframe.setAttribute('scrolling', 'no');

      iframe.onLoad.listen((_) {
        if (!mounted) {
          return;
        }

        /*
           * إذا تم تغيير الحلقة/السيرفر وأُنشئ iframe جديد،
           * نتجاهل onLoad الخاص بالنسخة القديمة.
           */
        if (generation != _generation) {
          return;
        }

        _cancelTimers();

        setState(() {
          _loading = false;
          _hasError = false;
          _errorMessage = null;
        });
      });

      iframe.onError.listen((_) {
        if (!mounted) {
          return;
        }

        if (generation != _generation) {
          return;
        }

        _cancelTimers();

        setState(() {
          _loading = false;
          _hasError = true;
          _errorMessage = 'تعذر تحميل صفحة المشغل';
        });
      });

      return iframe;
    });

    /*
     * ----------------------------------------------------------
     * Fallback قصير
     * ----------------------------------------------------------
     *
     * بعض المتصفحات لا ترسل onLoad بشكل متوقع مع iframe
     * الخارجي، لذلك لا نبقي شاشة التحميل للأبد.
     */
    _fallbackTimer = Timer(const Duration(milliseconds: 1800), () {
      if (!mounted) {
        return;
      }

      if (generation != _generation) {
        return;
      }

      setState(() {
        _loading = false;
      });
    });

    /*
     * ----------------------------------------------------------
     * Hard timeout
     * ----------------------------------------------------------
     *
     * إذا ظل المشغل فعلياً في حالة غريبة مدة طويلة،
     * نعرض للمستخدم خيار إعادة المحاولة.
     */
    _hardTimeoutTimer = Timer(const Duration(seconds: 20), () {
      if (!mounted) {
        return;
      }

      if (generation != _generation) {
        return;
      }

      if (!_loading) {
        return;
      }

      setState(() {
        _loading = false;
        _hasError = true;
        _errorMessage = 'استغرق تحميل المشغل وقتاً أطول من المتوقع';
      });
    });

    if (mounted) {
      setState(() {});
    }
  }

  void _reloadPlayer() {
    _createIframe();
  }

  @override
  Widget build(BuildContext context) {
    if (_hasError) {
      return _buildPlayerStack(showIframe: false);
    }

    return _buildPlayerStack(showIframe: true);
  }

  Widget _buildPlayerStack({required bool showIframe}) {
    return ColoredBox(
      color: Colors.black,
      child: Stack(
        fit: StackFit.expand,
        children: [
          const ColoredBox(color: Colors.black),

          if (showIframe)
            HtmlElementView(key: ValueKey(_viewType), viewType: _viewType),

          if (_hasError)
            _ErrorView(
              message: _errorMessage ?? 'تعذر تحميل المشغل',
              onRetry: _reloadPlayer,
            ),

          if (!_hasError && (_loading || widget.externalLoading))
            const _LoadingView(),
        ],
      ),
    );
  }
}

class _LoadingView extends StatelessWidget {
  const _LoadingView();

  @override
  Widget build(BuildContext context) {
    return const IgnorePointer(
      child: ColoredBox(
        color: Color(0xEE0A0A0F),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 42,
                height: 42,
                child: CircularProgressIndicator(
                  strokeWidth: 3,
                  color: AppTheme.info,
                ),
              ),
              SizedBox(height: 14),
              Text(
                'جاري تحميل المشغل...',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  color: AppTheme.textSecondary,
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _ErrorView({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: const Color(0xF20A0A0F),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.error_outline_rounded,
                color: AppTheme.danger,
                size: 46,
              ),

              const SizedBox(height: 12),

              const Text(
                'تعذر تحميل المشغل',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  color: AppTheme.textPrimary,
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                message,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  color: AppTheme.textMuted,
                  fontSize: 11,
                ),
              ),

              const SizedBox(height: 16),

              OutlinedButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh),
                label: const Text('إعادة المحاولة'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
