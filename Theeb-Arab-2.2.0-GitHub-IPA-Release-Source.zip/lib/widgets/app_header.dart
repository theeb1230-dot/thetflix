import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../tv/tv_focus_manager.dart';
import 'tv_focusable.dart';

class TheebAppHeader extends StatelessWidget {
  final VoidCallback onFavorites;
  final VoidCallback onMobileMode;
  final VoidCallback onHistory;
  final VoidCallback onUpdates;
  final VoidCallback onFullscreen;

  final bool mobileMode;
  final bool fullscreenActive;

  const TheebAppHeader({
    super.key,
    required this.onFavorites,
    required this.onMobileMode,
    required this.onHistory,
    required this.onUpdates,
    required this.onFullscreen,
    required this.mobileMode,
    required this.fullscreenActive,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return FocusTraversalGroup(
      policy: OrderedTraversalPolicy(),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 1400),
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        decoration: BoxDecoration(
          color: scheme.surface.withValues(alpha: 0.96),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: scheme.outlineVariant),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.20 : 0.10),
              blurRadius: 20,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                'assets/images/theeb_arab_icon.webp',
                width: 34,
                height: 34,
                fit: BoxFit.cover,
              ),
            ),

            const SizedBox(width: 10),

            Text(
              'ذيب العرب',
              style: TextStyle(
                fontFamily: AppTheme.fontFamily,
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: scheme.onSurface,
              ),
            ),

            const Spacer(),

            const _OnlineIndicator(),

            const SizedBox(width: 8),

            FocusTraversalOrder(
              order: const NumericFocusOrder(1),
              child: _HeaderButton(
                tooltip: 'المفضلة',
                icon: Icons.favorite,
                onPressed: onFavorites,

                // أول عنصر افتراضي في منطقة الهيدر.
                registerAsDefault: true,
              ),
            ),

            const SizedBox(width: 7),

            FocusTraversalOrder(
              order: const NumericFocusOrder(2),
              child: _HeaderButton(
                tooltip: mobileMode
                    ? 'تدوير الواجهة إلى أفقي'
                    : 'تدوير الواجهة إلى عمودي',
                icon: Icons.screen_rotation_alt_rounded,
                active: mobileMode,
                onPressed: onMobileMode,
              ),
            ),

            const SizedBox(width: 7),

            FocusTraversalOrder(
              order: const NumericFocusOrder(3),
              child: _HeaderButton(
                tooltip: 'سجل المشاهدة',
                icon: Icons.history,
                onPressed: onHistory,
              ),
            ),

            const SizedBox(width: 7),

            FocusTraversalOrder(
              order: const NumericFocusOrder(4),
              child: _HeaderButton(
                tooltip: 'التحديثات والمشاركة المحلية',
                icon: Icons.system_update_alt,
                onPressed: onUpdates,
              ),
            ),

            const SizedBox(width: 7),

            FocusTraversalOrder(
              order: const NumericFocusOrder(5),
              child: _HeaderButton(
                tooltip: fullscreenActive
                    ? 'الخروج من ملء الشاشة'
                    : 'تكبير المشغل',
                icon: fullscreenActive
                    ? Icons.fullscreen_exit
                    : Icons.fullscreen,
                active: fullscreenActive,
                onPressed: onFullscreen,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnlineIndicator extends StatelessWidget {
  const _OnlineIndicator();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            color: AppTheme.success,
            shape: BoxShape.circle,
          ),
          child: SizedBox(width: 8, height: 8),
        ),

        const SizedBox(width: 6),

        Text(
          'متصل',
          style: TextStyle(
            fontFamily: AppTheme.fontFamily,
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: scheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}

class _HeaderButton extends StatelessWidget {
  final String tooltip;
  final IconData icon;
  final VoidCallback onPressed;

  final bool active;

  /// هل يكون هذا العنصر نقطة البداية الافتراضية للهيدر؟
  final bool registerAsDefault;

  const _HeaderButton({
    required this.tooltip,
    required this.icon,
    required this.onPressed,
    this.active = false,
    this.registerAsDefault = false,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Tooltip(
      message: tooltip,
      child: TheebTvFocusable(
        onPressed: onPressed,
        focusOnHover: true,

        // ربط جميع أزرار الهيدر بنفس المنطقة.
        focusZone: TheebFocusZone.header,

        // زر المفضلة هو نقطة الدخول الافتراضية للهيدر.
        registerAsDefault: registerAsDefault,

        borderRadius: BorderRadius.circular(8),
        focusScale: 1.10,
        pressedScale: 0.94,

        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          curve: Curves.easeOutCubic,
          width: 38,
          height: 38,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: active
                ? scheme.primary.withValues(alpha: 0.16)
                : scheme.surfaceContainerHigh,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: active ? scheme.primary : scheme.outlineVariant,
            ),
          ),
          child: Icon(
            icon,
            size: 19,
            color: active ? scheme.primary : scheme.onSurfaceVariant,
          ),
        ),
      ),
    );
  }
}
