import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../models/update_models.dart';
import '../services/hybrid_update_service.dart';
import '../tv/tv_focus_manager.dart';
import 'tv_focusable.dart';

class UpdateCenterDialog extends StatelessWidget {
  final HybridUpdateService service;

  const UpdateCenterDialog({super.key, required this.service});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: const EdgeInsets.all(24),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 780, maxHeight: 720),
        child: AnimatedBuilder(
          animation: service,
          builder: (context, _) => FocusTraversalGroup(
            policy: OrderedTraversalPolicy(),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.system_update_alt,
                        color: AppTheme.primary,
                      ),
                      const SizedBox(width: 10),
                      const Expanded(
                        child: Text(
                          'التحديثات والمشاركة داخل الشبكة',
                          style: TextStyle(
                            fontFamily: AppTheme.fontFamily,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      _Action(
                        order: 99,
                        icon: Icons.close,
                        label: 'إغلاق',
                        onPressed: () => Navigator.pop(context),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'الإصدار الحالي ${service.currentVersion.isEmpty ? '…' : service.currentVersion} '
                    '(${service.currentBuild}) • المنصة ${_platformName(service.currentPlatform)}',
                    style: const TextStyle(color: AppTheme.textSecondary),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.surface2,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppTheme.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(service.message),
                        if (service.progress != null) ...[
                          const SizedBox(height: 8),
                          LinearProgressIndicator(value: service.progress),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _Action(
                          order: 1,
                          icon: Icons.cloud_download_outlined,
                          label: 'فحص الإنترنت',
                          enabled: !service.busy,
                          onPressed: service.checkInternet,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: _Action(
                          order: 2,
                          icon: Icons.wifi_find,
                          label: 'بحث داخل الشبكة',
                          enabled: !service.busy,
                          onPressed: service.scanLocal,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Expanded(
                    child: ListView(
                      children: [
                        if (service.remoteManifest != null)
                          _remoteSection(service.remoteManifest!),
                        _cachedSection(),
                        _peerSection(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _remoteSection(UpdateManifest manifest) {
    final newerArtifacts = manifest.artifacts.values
        .where((artifact) => artifact.build > service.currentBuild)
        .toList();
    if (newerArtifacts.isEmpty) {
      return const _Section(
        title: 'حالة التحديث',
        children: [
          ListTile(
            leading: Icon(Icons.verified_rounded, color: AppTheme.success),
            title: Text('أنت تستخدم آخر إصدار متوفر'),
            subtitle: Text('لا توجد حزمة تثبيت مطلوبة لهذا الجهاز.'),
          ),
        ],
      );
    }
    return _Section(
      title: 'الحزم المتاحة عبر الإنترنت',
      children: newerArtifacts.map((artifact) {
        final cached = service.cachedFor(artifact);
        return _ArtifactTile(
          artifact: artifact,
          suffix: cached != null ? 'محفوظة' : 'تنزيل',
          onPressed: cached != null || service.busy
              ? null
              : () => service.cacheRemoteArtifact(artifact),
        );
      }).toList(),
    );
  }

  Widget _cachedSection() {
    if (service.cachedArtifacts.isEmpty) return const SizedBox.shrink();
    return _Section(
      title: 'حزم التحديث المؤقتة',
      children: [
        _Action(
          order: 8,
          icon: Icons.delete_sweep_outlined,
          label: 'حذف الحزم وتحرير المساحة',
          enabled: !service.busy,
          onPressed: service.clearCachedArtifacts,
        ),
        const SizedBox(height: 6),
        ...service.cachedArtifacts.values.map((cached) {
          final ownPlatform =
              cached.artifact.platform == service.currentPlatform;
          final newer = cached.artifact.build > service.currentBuild;
          return _ArtifactTile(
            artifact: cached.artifact,
            suffix: ownPlatform
                ? (newer ? 'تثبيت' : 'مثبتة حاليًا')
                : 'جاهزة للمشاركة',
            onPressed: ownPlatform && newer && !service.busy
                ? () => service.installCached(cached)
                : null,
          );
        }),
      ],
    );
  }

  Widget _peerSection() {
    if (service.peers.isEmpty) return const SizedBox.shrink();
    return _Section(
      title: 'أجهزة ذيب العرب القريبة',
      children: service.peers.expand((peer) {
        final compatible = peer.artifacts[service.currentPlatform];
        return [
          ListTile(
            leading: const Icon(Icons.devices, color: AppTheme.info),
            title: Text(peer.name),
            subtitle: Text('الإصدار ${peer.version} (${peer.build})'),
          ),
          if (compatible != null)
            _ArtifactTile(
              artifact: compatible,
              suffix: 'استلام من هذا الجهاز',
              onPressed: service.busy
                  ? null
                  : () => service.downloadFromPeer(peer, compatible),
            ),
        ];
      }).toList(),
    );
  }

  static String _platformName(String platform) => switch (platform) {
    'android' => 'Android/TV',
    'ios' => 'iPhone/iPad',
    'windows' => 'Windows',
    'macos' => 'macOS',
    'linux' => 'Linux',
    'web' => 'Web',
    _ => platform,
  };
}

class _Section extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _Section({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: AppTheme.primary,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 6),
          ...children,
        ],
      ),
    );
  }
}

class _ArtifactTile extends StatelessWidget {
  final UpdateArtifact artifact;
  final String suffix;
  final VoidCallback? onPressed;

  const _ArtifactTile({
    required this.artifact,
    required this.suffix,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.inventory_2_outlined),
      title: Text(
        '${UpdateCenterDialog._platformName(artifact.platform)} • ${artifact.version}',
      ),
      subtitle: Text(
        artifact.size > 0
            ? '${(artifact.size / 1048576).toStringAsFixed(1)} MB • بناء ${artifact.build}'
            : 'بناء ${artifact.build}',
      ),
      trailing: _Action(
        order: 10 + artifact.platform.hashCode.abs() % 70,
        icon: onPressed == null ? Icons.check_circle_outline : Icons.download,
        label: suffix,
        enabled: onPressed != null,
        onPressed: onPressed ?? () {},
      ),
    );
  }
}

class _Action extends StatelessWidget {
  final double order;
  final IconData icon;
  final String label;
  final VoidCallback onPressed;
  final bool enabled;

  const _Action({
    required this.order,
    required this.icon,
    required this.label,
    required this.onPressed,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    return FocusTraversalOrder(
      order: NumericFocusOrder(order),
      child: TheebTvFocusable(
        enabled: enabled,
        focusZone: TheebFocusZone.dialog,
        onPressed: onPressed,
        borderRadius: BorderRadius.circular(9),
        child: Container(
          constraints: const BoxConstraints(minHeight: 42),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            color: enabled ? AppTheme.surface3 : AppTheme.surface2,
            borderRadius: BorderRadius.circular(9),
            border: Border.all(
              color: enabled ? AppTheme.borderLight : AppTheme.border,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 18,
                color: enabled ? AppTheme.primary : AppTheme.textMuted,
              ),
              const SizedBox(width: 7),
              Flexible(child: Text(label, overflow: TextOverflow.ellipsis)),
            ],
          ),
        ),
      ),
    );
  }
}
