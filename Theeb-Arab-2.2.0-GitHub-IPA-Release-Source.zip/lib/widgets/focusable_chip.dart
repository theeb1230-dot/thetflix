import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/app_theme.dart';
import '../tv/tv_focus_manager.dart';

/// زر السيرفرات المخصص لتطبيق ذيب.
///
/// هذا العنصر مربوط مباشرة بنظام التنقل المركزي للتلفزيون.
///
/// السلوك المطلوب:
///
/// ← →
/// التنقل بين السيرفرات.
///
/// ↑
/// الانتقال إلى Header.
///
/// ↓
/// الانتقال إلى Player Controls.
///
/// OK / Enter
/// تشغيل السيرفر.
///
/// ولا يسمح للـ Focus بالقفز إلى Dropdown الموسم/الحلقة
/// بسبب خوارزمية Flutter المكانية.
class FocusableTvChip extends StatefulWidget {
  final String text;
  final bool isSelected;
  final VoidCallback onClick;

  final FocusNode? focusNode;

  final bool autofocus;
  final bool enabled;

  /// هل هذا العنصر هو نقطة الدخول الافتراضية
  /// لمنطقة السيرفرات؟
  final bool registerAsDefault;

  const FocusableTvChip({
    super.key,
    required this.text,
    required this.isSelected,
    required this.onClick,
    this.focusNode,
    this.autofocus = false,
    this.enabled = true,
    this.registerAsDefault = false,
  });

  @override
  State<FocusableTvChip> createState() => _FocusableTvChipState();
}

class _FocusableTvChipState extends State<FocusableTvChip> {
  final TheebTvFocusManager _focusManager = TheebTvFocusManager.instance;

  FocusNode? _internalFocusNode;

  bool _isFocused = false;
  bool _isHovered = false;

  bool _pointerPressed = false;
  bool _keyboardPressed = false;

  bool get _isPressed => _pointerPressed || _keyboardPressed;

  FocusNode get _effectiveFocusNode {
    return widget.focusNode ??
        (_internalFocusNode ??= FocusNode(
          debugLabel: 'TheebServerChip:${widget.text}',
        ));
  }

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        return;
      }

      _registerWithFocusManager();
    });
  }

  @override
  void didUpdateWidget(covariant FocusableTvChip oldWidget) {
    super.didUpdateWidget(oldWidget);

    final nodeChanged = oldWidget.focusNode != widget.focusNode;

    final defaultChanged =
        oldWidget.registerAsDefault != widget.registerAsDefault;

    if (nodeChanged || defaultChanged) {
      final oldNode = oldWidget.focusNode ?? _internalFocusNode;

      if (oldNode != null) {
        _focusManager.unregisterNode(oldNode);
      }

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) {
          return;
        }

        _registerWithFocusManager();
      });
    }

    if (oldWidget.enabled && !widget.enabled) {
      if (_effectiveFocusNode.hasFocus) {
        _effectiveFocusNode.unfocus();
      }

      if (_pointerPressed || _keyboardPressed || _isHovered) {
        setState(() {
          _pointerPressed = false;
          _keyboardPressed = false;
          _isHovered = false;
        });
      }
    }

    if (!oldWidget.isSelected &&
        widget.isSelected &&
        _effectiveFocusNode.hasFocus) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) {
          return;
        }

        _ensureVisible();
      });
    }
  }

  @override
  void dispose() {
    final node = widget.focusNode ?? _internalFocusNode;

    if (node != null) {
      _focusManager.unregisterNode(node);
    }

    _internalFocusNode?.dispose();

    super.dispose();
  }

  void _registerWithFocusManager() {
    final node = _effectiveFocusNode;

    _focusManager.registerNode(zone: TheebFocusZone.servers, node: node);

    if (widget.registerAsDefault) {
      _focusManager.registerDefault(zone: TheebFocusZone.servers, node: node);
    }

    if (node.hasFocus) {
      _focusManager.rememberFocus(zone: TheebFocusZone.servers, node: node);
    }
  }

  bool _isActivationKey(LogicalKeyboardKey key) {
    return key == LogicalKeyboardKey.select ||
        key == LogicalKeyboardKey.enter ||
        key == LogicalKeyboardKey.space ||
        key == LogicalKeyboardKey.gameButtonA;
  }

  void _activate() {
    if (!widget.enabled) {
      return;
    }

    widget.onClick();
  }

  void _handleFocusChange(bool hasFocus) {
    if (_isFocused == hasFocus) {
      return;
    }

    setState(() {
      _isFocused = hasFocus;

      if (!hasFocus) {
        _keyboardPressed = false;
      }
    });

    if (hasFocus) {
      _focusManager.rememberFocus(
        zone: TheebFocusZone.servers,
        node: _effectiveFocusNode,
      );

      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || !_isFocused) {
          return;
        }

        _ensureVisible();
      });
    } else {
      _focusManager.notifyFocusLost(_effectiveFocusNode);
    }
  }

  void _ensureVisible() {
    if (!mounted || !_isFocused) {
      return;
    }

    try {
      Scrollable.ensureVisible(
        context,
        alignment: 0.5,
        alignmentPolicy: ScrollPositionAlignmentPolicy.explicit,
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutCubic,
      );
    } catch (_) {
      // لا يوجد Scrollable في بعض الحالات.
    }
  }

  KeyEventResult _handleKeyEvent(FocusNode node, KeyEvent event) {
    if (!widget.enabled) {
      return KeyEventResult.ignored;
    }

    final key = event.logicalKey;

    // ============================================================
    // OK / ENTER / SELECT
    // ============================================================

    if (_isActivationKey(key)) {
      if (event is KeyDownEvent) {
        if (!_keyboardPressed) {
          setState(() {
            _keyboardPressed = true;
          });
        }

        return KeyEventResult.handled;
      }

      if (event is KeyUpEvent) {
        final shouldActivate = _keyboardPressed;

        if (_keyboardPressed) {
          setState(() {
            _keyboardPressed = false;
          });
        }

        if (shouldActivate) {
          _activate();
        }

        return KeyEventResult.handled;
      }

      // منع التكرار عند إبقاء OK مضغوطًا.
      return KeyEventResult.handled;
    }

    if (event is! KeyDownEvent) {
      return KeyEventResult.ignored;
    }

    if (key == LogicalKeyboardKey.arrowLeft ||
        key == LogicalKeyboardKey.arrowRight ||
        key == LogicalKeyboardKey.arrowUp ||
        key == LogicalKeyboardKey.arrowDown ||
        key == LogicalKeyboardKey.channelUp ||
        key == LogicalKeyboardKey.channelDown) {
      return KeyEventResult.ignored;
    }

    // ============================================================
    // D-PAD
    // ============================================================

    return KeyEventResult.ignored;
  }

  void _requestOwnFocus() {
    if (!widget.enabled || _effectiveFocusNode.hasFocus) {
      return;
    }

    final requested = _focusManager.requestFocus(
      zone: TheebFocusZone.servers,
      node: _effectiveFocusNode,
    );

    if (!requested) {
      _effectiveFocusNode.requestFocus();
    }
  }

  void _handlePointerDown() {
    if (!widget.enabled) {
      return;
    }

    _requestOwnFocus();

    if (!_pointerPressed) {
      setState(() {
        _pointerPressed = true;
      });
    }
  }

  void _handlePointerCancel() {
    if (!_pointerPressed) {
      return;
    }

    setState(() {
      _pointerPressed = false;
    });
  }

  void _handlePointerUp() {
    if (!widget.enabled) {
      return;
    }

    if (_pointerPressed) {
      setState(() {
        _pointerPressed = false;
      });
    }

    _requestOwnFocus();

    _activate();
  }

  void _handleMouseEnter() {
    if (!widget.enabled || _isHovered) {
      return;
    }

    setState(() {
      _isHovered = true;
    });
  }

  void _handleMouseExit() {
    if (!_isHovered && !_pointerPressed) {
      return;
    }

    setState(() {
      _isHovered = false;
      _pointerPressed = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final highlighted = widget.enabled && (_isFocused || _isHovered);

    final Color backgroundColor;

    if (!widget.enabled) {
      backgroundColor = AppTheme.surface3.withValues(alpha: 0.45);
    } else if (_isFocused) {
      backgroundColor = AppTheme.info;
    } else if (widget.isSelected) {
      backgroundColor = AppTheme.info.withValues(alpha: 0.16);
    } else if (_isHovered) {
      backgroundColor = AppTheme.surface2;
    } else {
      backgroundColor = AppTheme.surface3;
    }

    final Color borderColor;

    if (!widget.enabled) {
      borderColor = AppTheme.border.withValues(alpha: 0.45);
    } else if (_isFocused) {
      borderColor = Colors.white;
    } else if (widget.isSelected) {
      borderColor = AppTheme.info;
    } else if (_isHovered) {
      borderColor = AppTheme.borderLight;
    } else {
      borderColor = AppTheme.border;
    }

    final Color textColor;

    if (!widget.enabled) {
      textColor = AppTheme.textMuted.withValues(alpha: 0.55);
    } else if (_isFocused) {
      textColor = Colors.black;
    } else if (widget.isSelected) {
      textColor = AppTheme.info;
    } else if (_isHovered) {
      textColor = AppTheme.textPrimary;
    } else {
      textColor = AppTheme.textSecondary;
    }

    final double targetScale;

    if (!widget.enabled) {
      targetScale = 1.0;
    } else if (_isPressed) {
      targetScale = 0.95;
    } else if (_isFocused) {
      targetScale = 1.08;
    } else if (_isHovered) {
      targetScale = 1.03;
    } else {
      targetScale = 1.0;
    }

    return Focus(
      focusNode: _effectiveFocusNode,
      autofocus: widget.autofocus,
      canRequestFocus: widget.enabled,
      skipTraversal: !widget.enabled,
      descendantsAreFocusable: widget.enabled,
      onFocusChange: _handleFocusChange,
      onKeyEvent: _handleKeyEvent,
      child: MouseRegion(
        cursor: widget.enabled
            ? SystemMouseCursors.click
            : SystemMouseCursors.basic,
        onEnter: (_) {
          _handleMouseEnter();
        },
        onExit: (_) {
          _handleMouseExit();
        },
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: widget.enabled
              ? (_) {
                  _handlePointerDown();
                }
              : null,
          onTapCancel: widget.enabled
              ? () {
                  _handlePointerCancel();
                }
              : null,
          onTapUp: widget.enabled
              ? (_) {
                  _handlePointerUp();
                }
              : null,
          child: AnimatedScale(
            scale: targetScale,
            duration: Duration(milliseconds: _isPressed ? 80 : 130),
            curve: Curves.easeOutCubic,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              curve: Curves.easeOutCubic,
              constraints: const BoxConstraints(minHeight: 42, minWidth: 88),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: backgroundColor,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: borderColor,
                  width: _isFocused ? 2 : 1,
                ),
                boxShadow: highlighted
                    ? [
                        BoxShadow(
                          color: AppTheme.info.withValues(
                            alpha: _isFocused ? 0.34 : 0.18,
                          ),
                          blurRadius: _isFocused ? 16 : 10,
                          spreadRadius: _isFocused ? 1 : 0,
                        ),
                      ]
                    : const [],
              ),
              child: AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 150),
                curve: Curves.easeOutCubic,
                style: TextStyle(
                  fontFamily: AppTheme.fontFamily,
                  color: textColor,
                  fontSize: 14,
                  fontWeight: widget.isSelected || _isFocused
                      ? FontWeight.w700
                      : FontWeight.w500,
                ),
                child: Text(
                  widget.text,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
