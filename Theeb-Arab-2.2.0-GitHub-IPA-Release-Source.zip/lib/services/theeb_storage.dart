import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/theeb_models.dart';

class TheebStorage {
  TheebStorage._();

  static SharedPreferences? _prefs;

  static Future<void>? _initializationFuture;

  // ============================================================
  // INITIALIZATION
  // ============================================================

  static Future<void> init() async {
    if (_prefs != null) {
      return;
    }

    /*
     * إذا تم استدعاء init أكثر من مرة في نفس اللحظة،
     * نستخدم نفس Future بدل إنشاء SharedPreferences أكثر من مرة.
     */
    _initializationFuture ??= _initializeInternal();

    try {
      await _initializationFuture;
    } finally {
      /*
       * بعد نجاح التهيئة لن نحتاج Future مرة أخرى لأن _prefs
       * أصبحت موجودة.
       *
       * وفي حالة الفشل نسمح بمحاولة جديدة لاحقاً.
       */
      if (_prefs == null) {
        _initializationFuture = null;
      }
    }
  }

  static Future<void> _initializeInternal() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static SharedPreferences get _instance {
    final prefs = _prefs;

    if (prefs == null) {
      throw StateError(
        'TheebStorage.init() must be called before using TheebStorage.',
      );
    }

    return prefs;
  }

  // ============================================================
  // GENERIC STORAGE HELPERS
  // ============================================================

  static String? _readRawString(String key) {
    try {
      return _instance.getString(key);
    } catch (error) {
      debugPrint('[THEEB STORAGE] Failed to read "$key": $error');

      return null;
    }
  }

  static List<dynamic>? _decodeList({
    required String key,
    required String? raw,
  }) {
    if (raw == null || raw.trim().isEmpty) {
      return null;
    }

    try {
      final decoded = jsonDecode(raw);

      if (decoded is! List) {
        debugPrint('[THEEB STORAGE] "$key" does not contain a JSON list.');

        return null;
      }

      return decoded;
    } catch (error) {
      debugPrint('[THEEB STORAGE] Corrupted JSON in "$key": $error');

      return null;
    }
  }

  static Future<void> _writeJson({
    required String key,
    required Object value,
  }) async {
    final encoded = jsonEncode(value);

    final success = await _instance.setString(key, encoded);

    if (!success) {
      throw StateError('Failed to save Theeb storage key: $key');
    }
  }

  static Future<void> _removeKey(String key) async {
    final success = await _instance.remove(key);

    /*
     * remove قد يعيد false إذا لم يكن المفتاح موجوداً أصلاً.
     * لذلك لا نعتبر false هنا خطأ قاتلاً.
     */
    if (!success && _instance.containsKey(key)) {
      throw StateError('Failed to remove Theeb storage key: $key');
    }
  }

  // ============================================================
  // CUSTOM CATALOG
  // ============================================================

  static Future<List<TheebCatalogItem>> getCustomCatalog() async {
    final raw = _readRawString(TheebConfig.customCatalogStorageKey);

    final decoded = _decodeList(
      key: TheebConfig.customCatalogStorageKey,
      raw: raw,
    );

    if (decoded == null) {
      return [];
    }

    final result = <TheebCatalogItem>[];

    /*
     * يمنع وجود نسختين من نفس Slug في المكتبة المضافة.
     */
    final seenSlugs = <String>{};

    for (final rawItem in decoded) {
      if (rawItem is! Map) {
        continue;
      }

      try {
        final item = TheebCatalogItem.fromJson(
          Map<String, dynamic>.from(rawItem),
        );

        final normalizedSlug = item.slug.trim();

        /*
         * أي عنصر بدون Slug صالح لا فائدة منه.
         */
        if (normalizedSlug.isEmpty) {
          continue;
        }

        final normalizedKey = normalizedSlug.toLowerCase();

        if (!seenSlugs.add(normalizedKey)) {
          continue;
        }

        /*
         * العناصر الموجودة في CUSTOM storage يجب أن تبقى
         * معرفة كعناصر مضافة وليست Built-in.
         */
        final sanitized = item.copyWith(
          slug: normalizedSlug,
          title: item.title.trim().isEmpty
              ? (item.type == TheebContentType.movie
                    ? '🎬 $normalizedSlug'
                    : '📺 $normalizedSlug')
              : item.title.trim(),
          isBuiltIn: false,
          seasons: _sanitizeSeasons(type: item.type, seasons: item.seasons),
        );

        result.add(sanitized);
      } catch (error) {
        /*
         * عنصر تالف واحد لا يجب أن يلغي المكتبة كلها.
         */
        debugPrint(
          '[THEEB STORAGE] Skipped invalid custom catalog item: $error',
        );
      }
    }

    return result;
  }

  static Future<void> saveCustomCatalog(List<TheebCatalogItem> items) async {
    final sanitized = <TheebCatalogItem>[];

    final seenSlugs = <String>{};

    for (final item in items) {
      final slug = item.slug.trim();

      if (slug.isEmpty) {
        continue;
      }

      final normalizedKey = slug.toLowerCase();

      if (!seenSlugs.add(normalizedKey)) {
        continue;
      }

      sanitized.add(
        item.copyWith(
          slug: slug,
          title: item.title.trim().isEmpty
              ? (item.type == TheebContentType.movie ? '🎬 $slug' : '📺 $slug')
              : item.title.trim(),
          isBuiltIn: false,
          seasons: _sanitizeSeasons(type: item.type, seasons: item.seasons),
        ),
      );
    }

    final data = sanitized.map((item) => item.toJson()).toList();

    await _writeJson(key: TheebConfig.customCatalogStorageKey, value: data);
  }

  static Future<void> clearCustomCatalog() async {
    await _removeKey(TheebConfig.customCatalogStorageKey);
  }

  // ============================================================
  // FAVORITES
  // ============================================================

  static Future<List<TheebFavorite>> getFavorites() async {
    final raw = _readRawString(TheebConfig.favoritesStorageKey);

    final decoded = _decodeList(key: TheebConfig.favoritesStorageKey, raw: raw);

    if (decoded == null) {
      return [];
    }

    final result = <TheebFavorite>[];

    final seenSlugs = <String>{};

    for (final rawItem in decoded) {
      if (rawItem is! Map) {
        continue;
      }

      try {
        final item = TheebFavorite.fromJson(Map<String, dynamic>.from(rawItem));

        final slug = item.slug.trim();

        if (slug.isEmpty) {
          continue;
        }

        final normalizedKey = slug.toLowerCase();

        if (!seenSlugs.add(normalizedKey)) {
          continue;
        }

        result.add(
          item.copyWith(
            slug: slug,
            title: item.title.trim().isEmpty ? slug : item.title.trim(),
          ),
        );
      } catch (error) {
        debugPrint('[THEEB STORAGE] Skipped invalid favorite: $error');
      }
    }

    return result;
  }

  static Future<void> saveFavorites(List<TheebFavorite> items) async {
    final sanitized = <TheebFavorite>[];

    final seenSlugs = <String>{};

    for (final item in items) {
      final slug = item.slug.trim();

      if (slug.isEmpty) {
        continue;
      }

      final normalizedKey = slug.toLowerCase();

      if (!seenSlugs.add(normalizedKey)) {
        continue;
      }

      sanitized.add(
        item.copyWith(
          slug: slug,
          title: item.title.trim().isEmpty ? slug : item.title.trim(),
        ),
      );
    }

    final data = sanitized.map((item) => item.toJson()).toList();

    await _writeJson(key: TheebConfig.favoritesStorageKey, value: data);
  }

  static Future<void> clearFavorites() async {
    await _removeKey(TheebConfig.favoritesStorageKey);
  }

  // ============================================================
  // HISTORY
  // ============================================================

  static Future<List<TheebHistoryItem>> getHistory() async {
    final raw = _readRawString(TheebConfig.historyStorageKey);

    final decoded = _decodeList(key: TheebConfig.historyStorageKey, raw: raw);

    if (decoded == null) {
      return [];
    }

    final result = <TheebHistoryItem>[];

    final seenSlugs = <String>{};

    for (final rawItem in decoded) {
      if (rawItem is! Map) {
        continue;
      }

      try {
        final item = TheebHistoryItem.fromJson(
          Map<String, dynamic>.from(rawItem),
        );

        final slug = item.slug.trim();

        if (slug.isEmpty) {
          continue;
        }

        final normalizedKey = slug.toLowerCase();

        /*
         * السجل يحتوي آخر حالة فقط لكل مسلسل أو فيلم.
         *
         * لأن العنصر الأحدث يفترض أن يكون أولاً في القائمة،
         * نحتفظ بأول نسخة ونرفض المكرر بعدها.
         */
        if (!seenSlugs.add(normalizedKey)) {
          continue;
        }

        result.add(
          item.copyWith(
            slug: slug,
            title: item.title.trim().isEmpty ? slug : item.title.trim(),

            season: item.season < 1 ? 1 : item.season,

            episode: item.episode < 1 ? 1 : item.episode,

            server: _sanitizeServer(item.server),
          ),
        );

        if (result.length >= TheebConfig.maxHistoryItems) {
          break;
        }
      } catch (error) {
        debugPrint('[THEEB STORAGE] Skipped invalid history item: $error');
      }
    }

    return result;
  }

  static Future<void> saveHistory(List<TheebHistoryItem> items) async {
    final sanitized = <TheebHistoryItem>[];

    final seenSlugs = <String>{};

    for (final item in items) {
      final slug = item.slug.trim();

      if (slug.isEmpty) {
        continue;
      }

      final normalizedKey = slug.toLowerCase();

      if (!seenSlugs.add(normalizedKey)) {
        continue;
      }

      sanitized.add(
        item.copyWith(
          slug: slug,
          title: item.title.trim().isEmpty ? slug : item.title.trim(),

          season: item.season < 1 ? 1 : item.season,

          episode: item.episode < 1 ? 1 : item.episode,

          server: _sanitizeServer(item.server),
        ),
      );

      if (sanitized.length >= TheebConfig.maxHistoryItems) {
        break;
      }
    }

    final data = sanitized.map((item) => item.toJson()).toList();

    await _writeJson(key: TheebConfig.historyStorageKey, value: data);
  }

  static Future<void> clearHistory() async {
    await _removeKey(TheebConfig.historyStorageKey);
  }

  // ============================================================
  // CURRENT SESSION
  // ============================================================

  static Future<TheebSessionState?> getSession() async {
    final raw = _readRawString(TheebConfig.sessionStorageKey);
    if (raw == null || raw.trim().isEmpty) return null;

    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map) return null;
      final session = TheebSessionState.fromJson(
        Map<String, dynamic>.from(decoded),
      );
      if (session.slug.isEmpty) return null;
      return session;
    } catch (error) {
      debugPrint('[THEEB STORAGE] Corrupted session: $error');
      return null;
    }
  }

  static Future<void> saveSession(TheebSessionState session) async {
    await _writeJson(
      key: TheebConfig.sessionStorageKey,
      value: session.toJson(),
    );
  }

  static Future<void> clearSession() async {
    await _removeKey(TheebConfig.sessionStorageKey);
  }

  // ============================================================
  // UI STATE
  // ============================================================

  static double getPageScrollOffset() {
    try {
      final value = _instance.getDouble(TheebConfig.pageScrollOffsetStorageKey);
      if (value == null || !value.isFinite || value < 0) return 0;
      return value;
    } catch (error) {
      debugPrint('[THEEB STORAGE] Failed to read page scroll offset: $error');
      return 0;
    }
  }

  static Future<void> savePageScrollOffset(double offset) async {
    if (!offset.isFinite) return;
    final success = await _instance.setDouble(
      TheebConfig.pageScrollOffsetStorageKey,
      offset < 0 ? 0 : offset,
    );
    if (!success) {
      throw StateError('Failed to save Theeb page scroll offset.');
    }
  }

  static Future<void> clearUiState() async {
    await _removeKey(TheebConfig.pageScrollOffsetStorageKey);
  }

  // ============================================================
  // DATA SANITIZATION
  // ============================================================

  static int _sanitizeServer(int value) {
    if (value < 1 || value > TheebConfig.maxServers) {
      return 1;
    }

    return value;
  }

  static List<TheebSeason> _sanitizeSeasons({
    required TheebContentType type,
    required List<TheebSeason> seasons,
  }) {
    if (type == TheebContentType.movie) {
      return const [];
    }

    final result = <TheebSeason>[];

    final seenNumbers = <int>{};

    for (final season in seasons) {
      if (result.length >= TheebConfig.maxCustomSeasons) {
        break;
      }

      int number = season.number;

      if (number < 1) {
        number = result.length + 1;
      }

      /*
       * إذا وصل موسم مكرر أو غريب من بيانات قديمة،
       * نعطيه الرقم التالي المتاح.
       */
      while (seenNumbers.contains(number)) {
        number++;
      }

      final episodes = season.episodes > 0 ? season.episodes : 10;

      seenNumbers.add(number);

      result.add(TheebSeason(number: number, episodes: episodes));
    }

    /*
     * المسلسل يجب أن يملك موسماً واحداً على الأقل.
     */
    if (result.isEmpty) {
      return const [TheebSeason(number: 1, episodes: 10)];
    }

    /*
     * نحافظ على ترتيب المواسم حسب رقم الموسم.
     */
    result.sort((a, b) => a.number.compareTo(b.number));

    return result;
  }

  // ============================================================
  // COMBINED CLEAR OPERATIONS
  // ============================================================

  /// يمسح المفضلة + سجل المشاهدة.
  static Future<void> clearSavedActivity() async {
    await Future.wait<void>([clearFavorites(), clearHistory()]);
  }

  /// يعيد المكتبة المضافة للوضع الافتراضي.
  static Future<void> resetCustomCatalog() async {
    await clearCustomCatalog();
  }

  /// يمسح جميع بيانات ذيب المحلية.
  static Future<void> clearAllTheebData() async {
    await Future.wait<void>([
      clearCustomCatalog(),
      clearFavorites(),
      clearHistory(),
      clearSession(),
      clearUiState(),
    ]);
  }

  // ============================================================
  // RAW / DEBUG HELPERS
  // ============================================================

  static bool containsCustomCatalog() {
    return _instance.containsKey(TheebConfig.customCatalogStorageKey);
  }

  static bool containsFavorites() {
    return _instance.containsKey(TheebConfig.favoritesStorageKey);
  }

  static bool containsHistory() {
    return _instance.containsKey(TheebConfig.historyStorageKey);
  }

  static bool containsSession() {
    return _instance.containsKey(TheebConfig.sessionStorageKey);
  }
}
