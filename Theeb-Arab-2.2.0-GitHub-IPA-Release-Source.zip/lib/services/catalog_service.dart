import '../models/season.dart';
import '../models/show.dart';

class CatalogService {
  CatalogService._();

  static const List<Show> defaultCatalog = [
    Show(
      title: '📺 مسلسل وادي الذئاب (Kurtlar Vadisi Pusu)',
      slug: 'kurtlar-vadisi-pusu',
      type: ShowType.tv,
      isBuiltIn: true,
      seasons: [
        Season(number: 1, episodes: 9),
        Season(number: 2, episodes: 32),
        Season(number: 3, episodes: 22),
      ],
    ),

    Show(
      title: '📺 مسلسل المنظمة (Teskilat)',
      slug: 'teskilat',
      type: ShowType.tv,
      isBuiltIn: true,
      seasons: [Season(number: 1, episodes: 184)],
    ),

    Show(
      title: '📺 مسلسل ثلاث قروش (Uc Kurus)',
      slug: 'uc-kurus',
      type: ShowType.tv,
      isBuiltIn: true,
      seasons: [Season(number: 1, episodes: 28)],
    ),

    Show(
      title: '📺 مسلسل رامو (Ramo)',
      slug: 'ramo',
      type: ShowType.tv,
      isBuiltIn: true,
      seasons: [Season(number: 1, episodes: 40)],
    ),

    Show(
      title: '📺 مسلسل قطاع طرق لن يحكموا العالم (Eskiya Dunyaya)',
      slug: 'eskiya-dunyaya-hukumdar-olmaz',
      type: ShowType.tv,
      isBuiltIn: true,
      seasons: [
        Season(number: 1, episodes: 40),
        Season(number: 2, episodes: 31),
        Season(number: 3, episodes: 36),
        Season(number: 4, episodes: 32),
        Season(number: 5, episodes: 26),
        Season(number: 6, episodes: 34),
      ],
    ),

    Show(
      title: '📺 مسلسل قيامة أرطغرل (Dirilis Ertugrul)',
      slug: 'dirilis-ertugrul',
      type: ShowType.tv,
      isBuiltIn: true,
      seasons: [Season(number: 1, episodes: 150)],
    ),

    Show(
      title: '📺 مسلسل المؤسس عثمان (Kurulus Osman)',
      slug: 'kurulus-osman',
      type: ShowType.tv,
      isBuiltIn: true,
      seasons: [Season(number: 1, episodes: 194)],
    ),

    Show(
      title: '📺 مسلسل الحفرة (Cukur)',
      slug: 'cukur',
      type: ShowType.tv,
      isBuiltIn: true,
      seasons: [
        Season(number: 1, episodes: 33),
        Season(number: 2, episodes: 34),
        Season(number: 3, episodes: 26),
        Season(number: 4, episodes: 39),
      ],
    ),

    Show(
      title: '📺 مسلسل الذئب الوحيد (Yalniz Kurt)',
      slug: 'yalniz-kurt',
      type: ShowType.tv,
      isBuiltIn: true,
      seasons: [Season(number: 1, episodes: 32)],
    ),

    Show(
      title: '🎬 فيلم وادي الذئاب غلاديو (2009)',
      slug: 'kurtlar-vadisi-gladstatus',
      type: ShowType.movie,
      isBuiltIn: true,
    ),

    Show(
      title: '🎬 فيلم وادي الذئاب الوطن (2017)',
      slug: 'kurtlar-vadisi-vatan',
      type: ShowType.movie,
      isBuiltIn: true,
    ),

    Show(
      title: '🎬 فيلم وادي الذئاب فلسطين (2011)',
      slug: 'kurtlar-vadisi-filistin',
      type: ShowType.movie,
      isBuiltIn: true,
    ),

    Show(
      title: '🎬 فيلم وادي الذئاب العراق (2006)',
      slug: 'kurtlar-vadisi-irak',
      type: ShowType.movie,
      isBuiltIn: true,
    ),
  ];
}
