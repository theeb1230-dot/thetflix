import 'dart:js_interop';

import 'package:web/web.dart' as web;

/// يتم استدعاؤه كلما تغيرت حالة Fullscreen.
typedef TheebFullscreenChanged = void Function(bool fullscreen);

/// دالة لإلغاء الاستماع.
typedef TheebFullscreenSubscription = void Function();

Future<void> enterTheebFullscreen() async {
  final element = web.document.documentElement;

  if (element == null) {
    return;
  }

  if (web.document.fullscreenElement != null) {
    return;
  }

  try {
    element.requestFullscreen();
  } catch (_) {
    // إذا رفض المتصفح Fullscreen API،
    // تتعامل واجهة Flutter مع الوضع الداخلي.
  }
}

Future<void> exitTheebFullscreen() async {
  if (web.document.fullscreenElement == null) {
    return;
  }

  try {
    web.document.exitFullscreen();
  } catch (_) {
    // لا نعتبر رفض المتصفح خطأ قاتلاً.
  }
}

/// يستمع مباشرة إلى Fullscreen API الخاص بالمتصفح.
///
/// بهذا نستطيع معرفة أن المستخدم خرج بواسطة:
/// - Esc
/// - زر المتصفح
/// - أمر من النظام
/// - exitFullscreen()
TheebFullscreenSubscription listenTheebFullscreenChanges(
  TheebFullscreenChanged listener,
) {
  void handleFullscreenChange(web.Event event) {
    final active = web.document.fullscreenElement != null;

    listener(active);
  }

  final jsListener = handleFullscreenChange.toJS;

  web.document.addEventListener('fullscreenchange', jsListener);

  return () {
    try {
      web.document.removeEventListener('fullscreenchange', jsListener);
    } catch (_) {
      // تجاهل أي مشكلة أثناء التخلص من الـ Listener.
    }
  };
}
