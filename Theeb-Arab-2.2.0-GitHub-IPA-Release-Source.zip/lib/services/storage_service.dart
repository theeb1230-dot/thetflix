import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../core/app_constants.dart';
import '../models/favorite_item.dart';
import '../models/history_item.dart';
import '../models/show.dart';

class StorageService {
  StorageService._();

  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
  }

  static SharedPreferences get prefs {
    final instance = _prefs;

    if (instance == null) {
      throw StateError(
        'StorageService.init() must be called before using storage.',
      );
    }

    return instance;
  }

  // ============================================================
  // CUSTOM CATALOG
  // ============================================================

  static Future<List<Show>> getCustomCatalog() async {
    final raw = prefs.getString(AppConstants.customCatalogKey);

    if (raw == null || raw.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(raw);

      if (decoded is! List) {
        return [];
      }

      return decoded
          .whereType<Map>()
          .map((item) => Show.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveCustomCatalog(List<Show> catalog) async {
    final encoded = jsonEncode(catalog.map((show) => show.toJson()).toList());

    await prefs.setString(AppConstants.customCatalogKey, encoded);
  }

  // ============================================================
  // FAVORITES
  // ============================================================

  static Future<List<FavoriteItem>> getFavorites() async {
    final raw = prefs.getString(AppConstants.favoritesKey);

    if (raw == null || raw.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(raw);

      if (decoded is! List) {
        return [];
      }

      return decoded
          .whereType<Map>()
          .map((item) => FavoriteItem.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveFavorites(List<FavoriteItem> favorites) async {
    final encoded = jsonEncode(favorites.map((item) => item.toJson()).toList());

    await prefs.setString(AppConstants.favoritesKey, encoded);
  }

  // ============================================================
  // HISTORY
  // ============================================================

  static Future<List<HistoryItem>> getHistory() async {
    final raw = prefs.getString(AppConstants.historyKey);

    if (raw == null || raw.isEmpty) {
      return [];
    }

    try {
      final decoded = jsonDecode(raw);

      if (decoded is! List) {
        return [];
      }

      return decoded
          .whereType<Map>()
          .map((item) => HistoryItem.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveHistory(List<HistoryItem> history) async {
    final encoded = jsonEncode(history.map((item) => item.toJson()).toList());

    await prefs.setString(AppConstants.historyKey, encoded);
  }

  // ============================================================
  // CLEAR
  // ============================================================

  static Future<void> clearFavorites() async {
    await prefs.remove(AppConstants.favoritesKey);
  }

  static Future<void> clearHistory() async {
    await prefs.remove(AppConstants.historyKey);
  }

  static Future<void> clearCustomCatalog() async {
    await prefs.remove(AppConstants.customCatalogKey);
  }
}
