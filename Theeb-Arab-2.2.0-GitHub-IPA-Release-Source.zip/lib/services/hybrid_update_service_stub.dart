import 'package:flutter/foundation.dart';

import '../models/update_models.dart';

class HybridUpdateService extends ChangeNotifier {
  bool initialized = false;
  bool busy = false;
  double? progress;
  String message = 'مشاركة التحديثات المحلية غير متاحة في نسخة الويب.';
  String currentVersion = '';
  int currentBuild = 0;
  UpdateManifest? remoteManifest;
  final List<UpdatePeer> peers = [];
  final Map<String, CachedUpdateArtifact> cachedArtifacts = {};

  String get currentPlatform => 'web';

  Future<void> initialize() async {
    initialized = true;
    notifyListeners();
  }

  Future<void> checkInternet() async {
    message = 'تُحدّث نسخة الويب تلقائيًا عند نشر الإصدار الجديد.';
    notifyListeners();
  }

  Future<void> scanLocal() async {
    message = 'اكتشاف الأجهزة المحلية متاح في التطبيقات المثبتة فقط.';
    notifyListeners();
  }

  Future<void> cacheRemoteArtifact(UpdateArtifact artifact) async {}
  Future<void> downloadFromPeer(
    UpdatePeer peer,
    UpdateArtifact artifact,
  ) async {}
  Future<void> installCached(CachedUpdateArtifact cached) async {}

  CachedUpdateArtifact? cachedFor(UpdateArtifact artifact) => null;

  Future<void> clearCachedArtifacts() async {
    cachedArtifacts.clear();
    message = 'لا توجد حزم تحديث محلية في نسخة الويب.';
    notifyListeners();
  }
}
