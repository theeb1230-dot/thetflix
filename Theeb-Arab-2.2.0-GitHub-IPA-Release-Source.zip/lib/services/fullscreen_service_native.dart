import 'package:flutter/services.dart';

/// يتم استدعاؤه كلما تغيرت حالة Fullscreen.
typedef TheebFullscreenChanged = void Function(bool fullscreen);

/// دالة لإلغاء الاستماع.
typedef TheebFullscreenSubscription = void Function();

Future<void> enterTheebFullscreen() async {
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
}

Future<void> exitTheebFullscreen() async {
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
}

/// Android / iOS لا يملكان fullscreenchange
/// مثل المتصفح.
///
/// لذلك نعيد Subscription فارغًا.
/// حالة Fullscreen على Native تبقى تحت إدارة Flutter.
TheebFullscreenSubscription listenTheebFullscreenChanges(
  TheebFullscreenChanged listener,
) {
  return () {};
}
