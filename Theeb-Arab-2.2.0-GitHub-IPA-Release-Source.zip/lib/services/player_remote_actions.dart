import 'dart:async';

import 'package:flutter/foundation.dart';

/// جسر مركزي بين أزرار ريموت Google TV والقسم النشط حالياً.
///
/// كل قسم يسجل إجراءاته فقط عندما يكون نشطاً، وبذلك تعمل الأزرار نفسها
/// بشكل منطقي في التركي والبحث والبث المباشر دون أن تتداخل الأقسام.
class TheebPlayerRemoteActions {
  TheebPlayerRemoteActions._();

  static AsyncCallback? _togglePlay;
  static AsyncCallback? _toggleFullscreen;
  static AsyncCallback? _next;
  static AsyncCallback? _previous;
  static Future<void> Function(double direction)? _scroll;

  static void bind({
    AsyncCallback? togglePlay,
    AsyncCallback? toggleFullscreen,
    AsyncCallback? next,
    AsyncCallback? previous,
    Future<void> Function(double direction)? scroll,
  }) {
    _togglePlay = togglePlay;
    _toggleFullscreen = toggleFullscreen;
    _next = next;
    _previous = previous;
    _scroll = scroll;
  }

  static void clear() {
    _togglePlay = null;
    _toggleFullscreen = null;
    _next = null;
    _previous = null;
    _scroll = null;
  }

  static void bindTogglePlay(AsyncCallback callback) {
    _togglePlay = callback;
  }

  static void unbindTogglePlay(AsyncCallback callback) {
    if (identical(_togglePlay, callback)) _togglePlay = null;
  }

  static Future<void> togglePlay() async => _run(_togglePlay);
  static Future<void> toggleFullscreen() async => _run(_toggleFullscreen);
  static Future<void> next() async => _run(_next);
  static Future<void> previous() async => _run(_previous);

  static Future<void> scroll(double direction) async {
    final callback = _scroll;
    if (callback != null) await callback(direction);
  }

  static Future<void> _run(AsyncCallback? callback) async {
    if (callback != null) await callback();
  }
}
