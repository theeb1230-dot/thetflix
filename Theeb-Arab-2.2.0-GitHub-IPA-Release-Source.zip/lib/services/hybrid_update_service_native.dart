import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:bonsoir/bonsoir.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/app_constants.dart';
import '../models/update_models.dart';

class HybridUpdateService extends ChangeNotifier {
  static const String _serviceType = '_theeb-update._tcp';
  static const MethodChannel _installerChannel = MethodChannel(
    'com.theebturk.app/updater',
  );

  bool initialized = false;
  bool busy = false;
  double? progress;
  String message = 'جاهز لفحص التحديثات.';
  String currentVersion = '';
  int currentBuild = 0;
  UpdateManifest? remoteManifest;
  final List<UpdatePeer> peers = [];
  final Map<String, CachedUpdateArtifact> cachedArtifacts = {};

  HttpServer? _server;
  BonsoirBroadcast? _broadcast;
  BonsoirDiscovery? _discovery;
  StreamSubscription<BonsoirDiscoveryEvent>? _discoverySubscription;
  late Directory _cacheDirectory;
  late String _token;

  String get currentPlatform {
    if (Platform.isAndroid) return 'android';
    if (Platform.isIOS) return 'ios';
    if (Platform.isWindows) return 'windows';
    if (Platform.isMacOS) return 'macos';
    if (Platform.isLinux) return 'linux';
    return 'unknown';
  }

  Future<void> initialize() async {
    if (initialized) return;
    try {
      final package = await PackageInfo.fromPlatform();
      currentVersion = package.version;
      currentBuild = int.tryParse(package.buildNumber) ?? 0;
      _cacheDirectory = Directory(
        '${(await getApplicationSupportDirectory()).path}${Platform.pathSeparator}updates',
      );
      await _cacheDirectory.create(recursive: true);
      _token = base64UrlEncode(
        List<int>.generate(18, (_) => Random.secure().nextInt(256)),
      ).replaceAll('=', '');
      await _loadCacheIndex();
      await _pruneCache();
      await _startSharing();
      initialized = true;
      message = 'المشاركة المحلية تعمل. يمكنك فحص الإنترنت أو أجهزة المنزل.';
    } catch (error) {
      message = 'تعذر تشغيل المشاركة المحلية: $error';
    }
    notifyListeners();
  }

  Future<void> checkInternet() async {
    if (busy) return;
    final manifestUrl = AppConstants.updateManifestUrl.trim();
    if (manifestUrl.isEmpty) {
      message = 'لم يُضبط رابط ملف التحديث بعد.';
      notifyListeners();
      return;
    }
    await _runBusy(() async {
      message = 'جارٍ فحص آخر إصدار على الإنترنت…';
      notifyListeners();
      final request = await HttpClient().getUrl(Uri.parse(manifestUrl));
      request.headers.set(HttpHeaders.cacheControlHeader, 'no-cache');
      final response = await request.close();
      if (response.statusCode != HttpStatus.ok) {
        throw HttpException('استجابة الخادم ${response.statusCode}');
      }
      final body = await utf8.decoder.bind(response).join();
      remoteManifest = UpdateManifest.fromJson(
        Map<String, dynamic>.from(jsonDecode(body) as Map),
      );
      final artifact = remoteManifest!.artifacts[currentPlatform];
      if (artifact != null && artifact.build > currentBuild) {
        message = 'يتوفر تحديث ${artifact.version} لهذا الجهاز.';
      } else {
        message = 'هذا الجهاز يستخدم أحدث إصدار متوفر.';
      }
    });
  }

  Future<void> scanLocal() async {
    if (_discovery == null || busy) return;
    peers.clear();
    notifyListeners();
    message = 'جارٍ البحث عن أجهزة ذيب العرب داخل الشبكة…';
    notifyListeners();
    await _discovery!.stop().catchError((_) {});
    await _discovery!.start();
    await Future<void>.delayed(const Duration(seconds: 5));
    message = peers.isEmpty
        ? 'لم يتم العثور على أجهزة أخرى. تأكد أنها على الشبكة نفسها.'
        : 'تم العثور على ${peers.length} جهاز/أجهزة.';
    notifyListeners();
  }

  Future<void> cacheRemoteArtifact(UpdateArtifact artifact) async {
    await _downloadArtifact(artifact, Uri.parse(artifact.url));
  }

  Future<void> downloadFromPeer(
    UpdatePeer peer,
    UpdateArtifact artifact,
  ) async {
    final uri = peer.baseUri.replace(
      path: '/artifact/${Uri.encodeComponent(artifact.platform)}',
      queryParameters: {'token': peer.token},
    );
    await _downloadArtifact(artifact, uri);
  }

  Future<void> installCached(CachedUpdateArtifact cached) async {
    if (cached.artifact.platform != currentPlatform) {
      message =
          'هذه الحزمة محفوظة للمشاركة مع جهاز ${cached.artifact.platform}.';
      notifyListeners();
      return;
    }
    if (cached.artifact.build <= currentBuild) {
      message = 'هذه الحزمة مثبتة بالفعل أو أقدم من الإصدار الحالي.';
      notifyListeners();
      return;
    }
    if (Platform.isAndroid) {
      try {
        await _installerChannel.invokeMethod<void>('installApk', {
          'path': cached.path,
          'build': cached.artifact.build,
        });
        message = 'تم فتح مثبت Android. اختر «تثبيت» لإكمال التحديث.';
      } on PlatformException catch (error) {
        message = error.message ?? 'تعذر فتح مثبت Android.';
      }
      notifyListeners();
      return;
    }
    final storeUrl = cached.artifact.storeUrl;
    if (storeUrl != null && await canLaunchUrl(Uri.parse(storeUrl))) {
      await launchUrl(
        Uri.parse(storeUrl),
        mode: LaunchMode.externalApplication,
      );
      return;
    }
    message = 'تم حفظ التحديث في: ${cached.path}';
    notifyListeners();
  }

  CachedUpdateArtifact? cachedFor(UpdateArtifact artifact) {
    final cached = cachedArtifacts[artifact.platform];
    if (cached == null) return null;
    final file = File(cached.path);
    if (!file.existsSync()) return null;
    final sameArtifact =
        cached.artifact.build == artifact.build &&
        cached.artifact.version == artifact.version &&
        cached.artifact.sha256 == artifact.sha256 &&
        (artifact.size <= 0 || file.lengthSync() == artifact.size);
    return sameArtifact ? cached : null;
  }

  Future<void> clearCachedArtifacts() async {
    if (busy) return;
    await _runBusy(() async {
      for (final cached in cachedArtifacts.values.toList()) {
        final file = File(cached.path);
        if (await file.exists()) await file.delete();
      }
      cachedArtifacts.clear();
      await _deleteUntrackedCacheFiles();
      await _saveCacheIndex();
      message = 'تم حذف حزم التحديث المؤقتة وتحرير المساحة.';
    });
  }

  Future<void> _downloadArtifact(UpdateArtifact artifact, Uri uri) async {
    if (busy) return;
    await _runBusy(() async {
      progress = 0;
      message = 'جارٍ تنزيل ${artifact.fileName}…';
      notifyListeners();
      final request = await HttpClient().getUrl(uri);
      final response = await request.close();
      if (response.statusCode != HttpStatus.ok) {
        throw HttpException('فشل التنزيل: ${response.statusCode}');
      }
      final safeName = artifact.fileName.replaceAll(
        RegExp(r'[^A-Za-z0-9._-]'),
        '_',
      );
      final temporary = File(
        '${_cacheDirectory.path}${Platform.pathSeparator}$safeName.part',
      );
      final output = temporary.openWrite();
      var received = 0;
      final expected = response.contentLength > 0
          ? response.contentLength
          : artifact.size;
      await for (final chunk in response) {
        output.add(chunk);
        received += chunk.length;
        if (expected > 0) progress = received / expected;
        notifyListeners();
      }
      await output.close();
      if (artifact.size > 0 && received != artifact.size) {
        await temporary.delete();
        throw const FormatException('حجم ملف التحديث غير مطابق.');
      }
      final digest = await sha256.bind(temporary.openRead()).first;
      if (artifact.sha256.isEmpty || digest.toString() != artifact.sha256) {
        await temporary.delete();
        throw const FormatException('بصمة SHA-256 غير مطابقة؛ رُفض الملف.');
      }
      final target = File(
        '${_cacheDirectory.path}${Platform.pathSeparator}$safeName',
      );
      if (await target.exists()) await target.delete();
      await temporary.rename(target.path);
      final previous = cachedArtifacts[artifact.platform];
      cachedArtifacts[artifact.platform] = CachedUpdateArtifact(
        artifact: artifact,
        path: target.path,
      );
      if (previous != null && previous.path != target.path) {
        final previousFile = File(previous.path);
        if (await previousFile.exists()) await previousFile.delete();
      }
      await _deleteUntrackedCacheFiles();
      await _saveCacheIndex();
      progress = null;
      message = artifact.platform == currentPlatform
          ? 'اكتمل تنزيل تحديث هذا الجهاز والتحقق منه.'
          : 'تم حفظ حزمة ${artifact.platform} لمشاركتها داخل الشبكة.';
    });
  }

  Future<void> _startSharing() async {
    _server = await HttpServer.bind(InternetAddress.anyIPv4, 0, shared: true);
    _server!.listen(_handleRequest);

    final package = await PackageInfo.fromPlatform();
    _broadcast = BonsoirBroadcast(
      service: BonsoirService(
        name: 'ذيب العرب ${Platform.localHostname}',
        type: _serviceType,
        port: _server!.port,
        attributes: {
          'id': _token.substring(0, 10),
          'token': _token,
          'version': currentVersion,
          'build': '$currentBuild',
          'platform': currentPlatform,
          'package': package.packageName,
        },
      ),
      printLogs: kDebugMode,
    );
    await _broadcast!.initialize();
    await _broadcast!.start();

    _discovery = BonsoirDiscovery(type: _serviceType, printLogs: kDebugMode);
    await _discovery!.initialize();
    _discoverySubscription = _discovery!.eventStream!.listen((event) {
      switch (event) {
        case BonsoirDiscoveryServiceFoundEvent():
          event.service.resolve(_discovery!.serviceResolver);
        case BonsoirDiscoveryServiceResolvedEvent():
          unawaited(_readPeer(event.service));
        case BonsoirDiscoveryServiceUpdatedEvent():
          unawaited(_readPeer(event.service));
        case BonsoirDiscoveryServiceLostEvent():
          final id = event.service.attributes['id'];
          peers.removeWhere((peer) => peer.id == id);
          notifyListeners();
        default:
          break;
      }
    });
    await _discovery!.start();
  }

  Future<void> _readPeer(BonsoirService service) async {
    final id = service.attributes['id'];
    final token = service.attributes['token'];
    if (id == null ||
        token == null ||
        token == _token ||
        service.hostAddresses.isEmpty) {
      return;
    }
    for (final address in service.hostAddresses) {
      try {
        final base = Uri(scheme: 'http', host: address, port: service.port);
        final request = await HttpClient().getUrl(
          base.replace(path: '/status', queryParameters: {'token': token}),
        );
        final response = await request.close().timeout(
          const Duration(seconds: 3),
        );
        if (response.statusCode != HttpStatus.ok) continue;
        final body = Map<String, dynamic>.from(
          jsonDecode(await utf8.decoder.bind(response).join()) as Map,
        );
        final rawArtifacts = Map<String, dynamic>.from(
          body['artifacts'] as Map? ?? const {},
        );
        final peer = UpdatePeer(
          id: id,
          name: (body['name'] ?? service.name).toString(),
          version: (body['version'] ?? '').toString(),
          build: int.tryParse('${body['build']}') ?? 0,
          baseUri: base,
          token: token,
          artifacts: rawArtifacts.map(
            (key, value) => MapEntry(
              key,
              UpdateArtifact.fromJson(
                key,
                Map<String, dynamic>.from(value as Map),
              ),
            ),
          ),
        );
        peers.removeWhere((item) => item.id == id);
        peers.add(peer);
        notifyListeners();
        return;
      } catch (_) {
        // جرّب العنوان التالي؛ بعض الأجهزة تعلن IPv6 غير قابل للوصول.
      }
    }
  }

  Future<void> _handleRequest(HttpRequest request) async {
    request.response.headers.set(
      HttpHeaders.contentTypeHeader,
      'application/json; charset=utf-8',
    );
    if (request.uri.queryParameters['token'] != _token) {
      request.response.statusCode = HttpStatus.forbidden;
      await request.response.close();
      return;
    }
    if (request.uri.path == '/status') {
      request.response.write(
        jsonEncode({
          'name': 'ذيب العرب ${Platform.localHostname}',
          'version': currentVersion,
          'build': currentBuild,
          'platform': currentPlatform,
          'artifacts': cachedArtifacts.map(
            (key, value) => MapEntry(key, value.artifact.toJson()),
          ),
        }),
      );
      await request.response.close();
      return;
    }
    if (request.uri.pathSegments.length == 2 &&
        request.uri.pathSegments.first == 'artifact') {
      final cached = cachedArtifacts[request.uri.pathSegments.last];
      if (cached == null || !await File(cached.path).exists()) {
        request.response.statusCode = HttpStatus.notFound;
        await request.response.close();
        return;
      }
      final file = File(cached.path);
      request.response.headers.contentType = ContentType.binary;
      request.response.contentLength = await file.length();
      await request.response.addStream(file.openRead());
      await request.response.close();
      return;
    }
    request.response.statusCode = HttpStatus.notFound;
    await request.response.close();
  }

  Future<void> _loadCacheIndex() async {
    final index = File(
      '${_cacheDirectory.path}${Platform.pathSeparator}index.json',
    );
    if (!await index.exists()) return;
    try {
      final raw = Map<String, dynamic>.from(
        jsonDecode(await index.readAsString()) as Map,
      );
      for (final entry in raw.entries) {
        final cached = CachedUpdateArtifact.fromJson(
          Map<String, dynamic>.from(entry.value as Map),
        );
        if (await File(cached.path).exists()) {
          cachedArtifacts[entry.key] = cached;
        }
      }
    } catch (_) {
      // تجاهل فهرس قديم أو غير مكتمل بدون حذف ملفات المستخدم الأخرى.
    }
  }

  Future<void> _pruneCache() async {
    var changed = false;
    for (final entry in cachedArtifacts.entries.toList()) {
      final cached = entry.value;
      final file = File(cached.path);
      final missing = !await file.exists();
      final wrongSize =
          !missing &&
          cached.artifact.size > 0 &&
          await file.length() != cached.artifact.size;
      final alreadyInstalled =
          cached.artifact.platform == currentPlatform &&
          cached.artifact.build <= currentBuild;
      if (missing || wrongSize || alreadyInstalled) {
        if (!missing) await file.delete();
        cachedArtifacts.remove(entry.key);
        changed = true;
      }
    }
    if (await _deleteUntrackedCacheFiles()) changed = true;
    if (changed) await _saveCacheIndex();
  }

  Future<bool> _deleteUntrackedCacheFiles() async {
    if (!await _cacheDirectory.exists()) return false;
    final tracked = cachedArtifacts.values
        .map((cached) => File(cached.path).absolute.path.toLowerCase())
        .toSet();
    var changed = false;
    await for (final entity in _cacheDirectory.list()) {
      if (entity is! File) continue;
      final name = entity.uri.pathSegments.last;
      if (name == 'index.json') continue;
      final isTracked = tracked.contains(entity.absolute.path.toLowerCase());
      if (!isTracked || name.endsWith('.part')) {
        await entity.delete();
        changed = true;
      }
    }
    return changed;
  }

  Future<void> _saveCacheIndex() async {
    final index = File(
      '${_cacheDirectory.path}${Platform.pathSeparator}index.json',
    );
    await index.writeAsString(
      jsonEncode(
        cachedArtifacts.map((key, value) => MapEntry(key, value.toJson())),
      ),
      flush: true,
    );
  }

  Future<void> _runBusy(Future<void> Function() action) async {
    busy = true;
    notifyListeners();
    try {
      await action();
    } catch (error) {
      progress = null;
      message = 'تعذر إكمال العملية: $error';
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    unawaited(_discoverySubscription?.cancel());
    unawaited(_discovery?.stop());
    unawaited(_broadcast?.stop());
    unawaited(_server?.close(force: true));
    super.dispose();
  }
}
