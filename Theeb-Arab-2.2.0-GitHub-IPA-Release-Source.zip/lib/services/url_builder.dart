import '../core/app_constants.dart';
import '../models/show.dart';

class UrlBuilder {
  UrlBuilder._();

  /// يبني رابط الحلقة أو الفيلم بنفس منطق HTML الأصلي.
  static String build({
    required String slug,
    required ShowType type,
    required int season,
    required int episode,
    required int server,
  }) {
    final safeServer = server.clamp(1, AppConstants.maxServers);

    String episodePath = '';

    if (type == ShowType.tv) {
      final seasonText = season.toString().padLeft(2, '0');
      final episodeText = episode.toString().padLeft(2, '0');

      episodePath = '-s${seasonText}e$episodeText';
    }

    return '${AppConstants.baseUrl}'
        '$slug'
        '$episodePath'
        '/?serv=$safeServer';
  }

  /// يبني الرابط مباشرة من كائن Show.
  static String buildForShow({
    required Show show,
    required int season,
    required int episode,
    required int server,
  }) {
    return build(
      slug: show.slug,
      type: show.type,
      season: season,
      episode: episode,
      server: server,
    );
  }
}
