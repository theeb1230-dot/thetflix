import 'package:flutter/material.dart';

/// المناطق الرئيسية للتنقل داخل تطبيق ذيب على التلفزيون.
///
/// كل منطقة تمثل مجموعة من العناصر التي تعمل كوحدة واحدة
/// في نظام التنقل بالريموت.
enum TheebFocusZone {
  header,
  servers,
  playerControls,
  sidebar,
  advanced,
  dialog,
}

/// مدير مركزي لنظام Focus الخاص بتطبيق ذيب.
///
/// مسؤول عن:
/// - حفظ آخر عنصر كان عليه Focus داخل كل منطقة.
/// - تسجيل العنصر الافتراضي لكل منطقة.
/// - استعادة آخر Focus.
/// - الانتقال بين المناطق.
/// - التنقل بالـ D-pad.
/// - تنظيف FocusNodes التي لم تعد مستخدمة.
/// - منع الانتقالات العشوائية قدر الإمكان على Android TV / Google TV.
///
/// ملاحظة:
/// هذا المدير لا يملك FocusNodes المسجلة داخله،
/// لذلك لا يقوم بعمل dispose لها.
class TheebTvFocusManager extends ChangeNotifier {
  TheebTvFocusManager._();

  static final TheebTvFocusManager instance = TheebTvFocusManager._();

  /// آخر Focus تم استخدامه داخل كل منطقة.
  final Map<TheebFocusZone, FocusNode> _lastFocusedNodes = {};

  /// Focus الافتراضي لكل منطقة.
  final Map<TheebFocusZone, FocusNode> _defaultFocusNodes = {};
  final Map<TheebFocusZone, List<FocusNode>> _orderedNodes = {};

  TheebFocusZone? _currentZone;
  FocusNode? _currentNode;

  bool _disposed = false;

  // ============================================================
  // GETTERS
  // ============================================================

  TheebFocusZone? get currentZone => _currentZone;

  FocusNode? get currentNode => _currentNode;

  bool get hasPrimaryFocus => _currentNode?.hasPrimaryFocus ?? false;

  bool get hasFocus => _currentNode?.hasFocus ?? false;

  bool hasRememberedFocus(TheebFocusZone zone) {
    return _isNodeUsable(_lastFocusedNodes[zone]);
  }

  bool hasDefaultFocus(TheebFocusZone zone) {
    return _isNodeUsable(_defaultFocusNodes[zone]);
  }

  bool hasAvailableFocus(TheebFocusZone zone) {
    return hasRememberedFocus(zone) || hasDefaultFocus(zone);
  }

  FocusNode? rememberedNode(TheebFocusZone zone) {
    final node = _lastFocusedNodes[zone];

    if (!_isNodeUsable(node)) {
      return null;
    }

    return node;
  }

  FocusNode? defaultNode(TheebFocusZone zone) {
    final node = _defaultFocusNodes[zone];

    if (!_isNodeUsable(node)) {
      return null;
    }

    return node;
  }

  // ============================================================
  // REGISTER DEFAULT FOCUS
  // ============================================================

  /// يسجل العنصر الافتراضي داخل منطقة معينة.
  ///
  /// أمثلة:
  /// - أول زر في Header.
  /// - أول Server.
  /// - زر المفضلة في Player Controls عند عدم توفر السابق.
  void registerDefault({
    required TheebFocusZone zone,
    required FocusNode node,
  }) {
    if (_disposed) {
      return;
    }

    if (!_isNodeUsable(node)) {
      return;
    }

    _defaultFocusNodes[zone] = node;
    registerNode(zone: zone, node: node);
  }

  /// يسجل كل محطة بترتيب بناء الواجهة كي يكون ↑/↓ حتميًا على التلفزيون.
  void registerNode({required TheebFocusZone zone, required FocusNode node}) {
    if (_disposed || !_isNodeUsable(node)) return;
    final nodes = _orderedNodes.putIfAbsent(zone, () => <FocusNode>[]);
    if (!nodes.contains(node)) nodes.add(node);
  }

  /// يلغي تسجيل Focus الافتراضي إذا كان هو نفس الـ Node.
  void unregisterDefault({
    required TheebFocusZone zone,
    required FocusNode node,
  }) {
    if (_disposed) {
      return;
    }

    if (_defaultFocusNodes[zone] == node) {
      _defaultFocusNodes.remove(zone);
    }

    if (_lastFocusedNodes[zone] == node) {
      _lastFocusedNodes.remove(zone);
    }

    if (_currentNode == node) {
      _currentNode = null;

      if (_currentZone == zone) {
        _currentZone = null;
      }
    }
  }

  // ============================================================
  // REMEMBER FOCUS
  // ============================================================

  /// يستدعى عندما يحصل عنصر على Focus.
  void rememberFocus({required TheebFocusZone zone, required FocusNode node}) {
    if (_disposed) {
      return;
    }

    if (!_isNodeUsable(node)) {
      return;
    }

    final changed = _currentZone != zone || _currentNode != node;

    _currentZone = zone;
    _currentNode = node;

    _lastFocusedNodes[zone] = node;

    if (changed) {
      notifyListeners();
    }
  }

  /// يستدعى عند خروج Focus من عنصر.
  ///
  /// لا نحذف الـ Node من ذاكرة المنطقة لأننا نريد
  /// الرجوع إليه عند العودة للمنطقة.
  void notifyFocusLost(FocusNode node) {
    if (_disposed) {
      return;
    }

    if (_currentNode != node) {
      return;
    }

    _currentNode = null;

    notifyListeners();
  }

  // ============================================================
  // REQUEST FOCUS
  // ============================================================

  /// يعيد Focus إلى آخر عنصر مستخدم داخل المنطقة.
  ///
  /// إذا لم يوجد، يستخدم العنصر الافتراضي.
  bool restoreZone(TheebFocusZone zone) {
    if (_disposed) {
      return false;
    }

    cleanup();

    final remembered = _lastFocusedNodes[zone];

    if (_requestNode(remembered)) {
      _setCurrent(zone: zone, node: remembered!, remember: true);

      return true;
    }

    final fallback = _defaultFocusNodes[zone];

    if (_requestNode(fallback)) {
      _setCurrent(zone: zone, node: fallback!, remember: true);

      return true;
    }

    return false;
  }

  /// يطلب Focus مباشرة لعنصر معين.
  bool requestFocus({required TheebFocusZone zone, required FocusNode node}) {
    if (_disposed) {
      return false;
    }

    if (!_requestNode(node)) {
      return false;
    }

    _setCurrent(zone: zone, node: node, remember: true);

    return true;
  }

  /// يختار أول منطقة متوفرة حسب الأولوية.
  bool requestInitialFocus({
    List<TheebFocusZone> priority = const [
      TheebFocusZone.servers,
      TheebFocusZone.playerControls,
      TheebFocusZone.header,
      TheebFocusZone.sidebar,
      TheebFocusZone.advanced,
    ],
  }) {
    if (_disposed) {
      return false;
    }

    cleanup();

    for (final zone in priority) {
      if (restoreZone(zone)) {
        return true;
      }
    }

    return false;
  }

  // ============================================================
  // NORMAL DIRECTIONAL NAVIGATION
  // ============================================================

  /// يستخدم خوارزمية Flutter الطبيعية للتنقل.
  ///
  /// مناسب بشكل خاص للحركة:
  /// ← →
  ///
  /// داخل نفس صف السيرفرات أو أزرار الهيدر.
  bool move(BuildContext context, TraversalDirection direction) {
    if (_disposed) {
      return false;
    }

    try {
      return FocusScope.of(context).focusInDirection(direction);
    } catch (_) {
      return false;
    }
  }

  bool moveLeft(BuildContext context) {
    return move(context, TraversalDirection.left);
  }

  bool moveRight(BuildContext context) {
    return move(context, TraversalDirection.right);
  }

  bool moveUp(BuildContext context) {
    return move(context, TraversalDirection.up);
  }

  bool moveDown(BuildContext context) {
    return move(context, TraversalDirection.down);
  }

  // ============================================================
  // SMART TV NAVIGATION
  // ============================================================

  /// التنقل الرئيسي المخصص للريموت.
  ///
  /// الفكرة:
  ///
  /// ← →
  /// نحاول أولًا استخدام Flutter الطبيعي داخل المنطقة.
  ///
  /// ↑ ↓
  /// نعطي الأولوية للانتقال المنظم بين مناطق ذيب.
  ///
  /// هذا يمنع Flutter من القفز إلى زر بعيد
  /// بسبب اختلاف أحجام العناصر ومواقعها.
  bool moveSmart(BuildContext context, TraversalDirection direction) {
    if (_disposed) {
      return false;
    }

    cleanup();

    switch (direction) {
      case TraversalDirection.left:
      case TraversalDirection.right:
        return _moveHorizontal(context, direction);

      case TraversalDirection.up:
        return _moveVertical(context: context, upwards: true);

      case TraversalDirection.down:
        return _moveVertical(context: context, upwards: false);
    }
  }

  bool _moveHorizontal(BuildContext context, TraversalDirection direction) {
    /// الحركة الأفقية داخل الصف نفسه تحصل على الأولوية.
    final movedNaturally = move(context, direction);

    if (movedNaturally) {
      return true;
    }

    /// إذا انتهت العناصر أفقيًا، لا نقفز تلقائيًا
    /// إلى منطقة أخرى إلا في الحالات المناسبة.
    final zone = _currentZone;

    if (zone == TheebFocusZone.playerControls) {
      if (goToSidebar()) {
        return true;
      }
    }

    if (zone == TheebFocusZone.sidebar) {
      if (goToPlayerControls()) {
        return true;
      }
    }

    return false;
  }

  bool _moveVertical({required BuildContext context, required bool upwards}) {
    final zone = _currentZone;

    /// إذا لم نعرف المنطقة الحالية، نجرب Flutter أولًا.
    if (zone == null) {
      final direction = upwards
          ? TraversalDirection.up
          : TraversalDirection.down;

      if (move(context, direction)) {
        return true;
      }

      return requestInitialFocus();
    }

    final nodes =
        _orderedNodes[zone]?.where(_isNodeUsable).toList(growable: false) ??
        const <FocusNode>[];
    final currentNode = _currentNode;
    final currentIndex = currentNode == null ? -1 : nodes.indexOf(currentNode);
    if (currentIndex >= 0) {
      final targetIndex = upwards ? currentIndex - 1 : currentIndex + 1;
      if (targetIndex >= 0 && targetIndex < nodes.length) {
        return requestFocus(zone: zone, node: nodes[targetIndex]);
      }
    }

    final targetZones = upwards ? _zonesAbove(zone) : _zonesBelow(zone);

    /// نحاول المناطق المنظمة أولًا.
    for (final target in targetZones) {
      if (restoreZone(target)) {
        return true;
      }
    }

    /// لو لم تتوفر منطقة مناسبة،
    /// نترك Flutter يحاول البحث المكاني.
    return move(
      context,
      upwards ? TraversalDirection.up : TraversalDirection.down,
    );
  }

  // ============================================================
  // ZONE GRAPH
  // ============================================================

  /// ترتيب المناطق عند الضغط ↑.
  List<TheebFocusZone> _zonesAbove(TheebFocusZone zone) {
    switch (zone) {
      case TheebFocusZone.header:
        return const [];

      case TheebFocusZone.servers:
        return const [TheebFocusZone.header];

      case TheebFocusZone.playerControls:
        return const [TheebFocusZone.servers, TheebFocusZone.header];

      case TheebFocusZone.sidebar:
        return const [
          TheebFocusZone.playerControls,
          TheebFocusZone.servers,
          TheebFocusZone.header,
        ];

      case TheebFocusZone.advanced:
        return const [
          TheebFocusZone.sidebar,
          TheebFocusZone.playerControls,
          TheebFocusZone.servers,
        ];

      case TheebFocusZone.dialog:
        return const [];
    }
  }

  /// ترتيب المناطق عند الضغط ↓.
  List<TheebFocusZone> _zonesBelow(TheebFocusZone zone) {
    switch (zone) {
      case TheebFocusZone.header:
        return const [
          TheebFocusZone.servers,
          TheebFocusZone.playerControls,
          TheebFocusZone.sidebar,
        ];

      case TheebFocusZone.servers:
        return const [
          TheebFocusZone.playerControls,
          TheebFocusZone.sidebar,
          TheebFocusZone.advanced,
        ];

      case TheebFocusZone.playerControls:
        return const [TheebFocusZone.sidebar, TheebFocusZone.advanced];

      case TheebFocusZone.sidebar:
        return const [TheebFocusZone.advanced];

      case TheebFocusZone.advanced:
        return const [];

      case TheebFocusZone.dialog:
        return const [];
    }
  }

  // ============================================================
  // ZONE NAVIGATION
  // ============================================================

  bool goToZone(TheebFocusZone zone) {
    return restoreZone(zone);
  }

  bool goToHeader() {
    return restoreZone(TheebFocusZone.header);
  }

  bool goToServers() {
    return restoreZone(TheebFocusZone.servers);
  }

  bool goToPlayerControls() {
    return restoreZone(TheebFocusZone.playerControls);
  }

  bool goToSidebar() {
    return restoreZone(TheebFocusZone.sidebar);
  }

  bool goToAdvanced() {
    return restoreZone(TheebFocusZone.advanced);
  }

  bool goToDialog() {
    return restoreZone(TheebFocusZone.dialog);
  }

  // ============================================================
  // RESTORE AFTER SPECIAL STATES
  // ============================================================

  /// يستخدم بعد الخروج من Fullscreen.
  ///
  /// يحاول الرجوع للمنطقة الأخيرة،
  /// ثم للسيرفرات، ثم للأزرار، ثم للهيدر.
  bool restoreAfterFullscreen() {
    if (_disposed) {
      return false;
    }

    cleanup();

    final zone = _currentZone;

    if (zone != null && restoreZone(zone)) {
      return true;
    }

    return requestInitialFocus(
      priority: const [
        TheebFocusZone.servers,
        TheebFocusZone.playerControls,
        TheebFocusZone.header,
        TheebFocusZone.sidebar,
        TheebFocusZone.advanced,
      ],
    );
  }

  /// يعيد التركيز إلى المنطقة التي فتحت حوارًا أو قائمة اختيار.
  ///
  /// عقد الحوار تُزال أولًا حتى لا يبقى Focus على Route أُغلق، ثم نحاول
  /// المنطقة السابقة قبل الرجوع إلى ترتيب البداية المعتاد.
  bool restoreAfterDialog(TheebFocusZone? previousZone) {
    if (_disposed) {
      return false;
    }

    _lastFocusedNodes.remove(TheebFocusZone.dialog);
    _defaultFocusNodes.remove(TheebFocusZone.dialog);

    if (_currentZone == TheebFocusZone.dialog) {
      _currentZone = null;
      _currentNode = null;
    }

    cleanup();

    if (previousZone != null &&
        previousZone != TheebFocusZone.dialog &&
        restoreZone(previousZone)) {
      return true;
    }

    return requestInitialFocus();
  }

  // ============================================================
  // CLEANUP
  // ============================================================

  /// يحذف Node محدد من جميع سجلات المدير.
  ///
  /// يجب استدعاؤه قبل dispose للـ FocusNode المسجل.
  void unregisterNode(FocusNode node) {
    if (_disposed) {
      return;
    }

    final rememberedZones = _lastFocusedNodes.entries
        .where((entry) => entry.value == node)
        .map((entry) => entry.key)
        .toList();

    for (final zone in rememberedZones) {
      _lastFocusedNodes.remove(zone);
    }

    final defaultZones = _defaultFocusNodes.entries
        .where((entry) => entry.value == node)
        .map((entry) => entry.key)
        .toList();

    for (final zone in defaultZones) {
      _defaultFocusNodes.remove(zone);
    }

    for (final nodes in _orderedNodes.values) {
      nodes.remove(node);
    }

    if (_currentNode == node) {
      _currentNode = null;
      _currentZone = null;
    }
  }

  /// ينظف Nodes التي لم تعد صالحة.
  void cleanup() {
    if (_disposed) {
      return;
    }

    final rememberedZones = _lastFocusedNodes.entries
        .where((entry) => !_isNodeUsable(entry.value))
        .map((entry) => entry.key)
        .toList();

    for (final zone in rememberedZones) {
      _lastFocusedNodes.remove(zone);
    }

    for (final nodes in _orderedNodes.values) {
      nodes.removeWhere((node) => !_isNodeUsable(node));
    }

    final defaultZones = _defaultFocusNodes.entries
        .where((entry) => !_isNodeUsable(entry.value))
        .map((entry) => entry.key)
        .toList();

    for (final zone in defaultZones) {
      _defaultFocusNodes.remove(zone);
    }

    if (!_isNodeUsable(_currentNode)) {
      _currentNode = null;

      /// لا نمسح currentZone مباشرة إذا كانت المنطقة
      /// لا تزال تحتوي على Focus افتراضي أو محفوظ.
      final zone = _currentZone;

      if (zone == null || !hasAvailableFocus(zone)) {
        _currentZone = null;
      }
    }
  }

  /// يمسح ذاكرة آخر Focus فقط.
  ///
  /// العناصر الافتراضية تبقى مسجلة.
  void reset() {
    if (_disposed) {
      return;
    }

    _lastFocusedNodes.clear();

    _currentZone = null;
    _currentNode = null;

    notifyListeners();
  }

  /// يمسح كل التسجيلات من المدير.
  ///
  /// لا يعمل dispose لأي FocusNode.
  void clearRegistrations() {
    if (_disposed) {
      return;
    }

    _lastFocusedNodes.clear();
    _defaultFocusNodes.clear();

    _currentZone = null;
    _currentNode = null;

    notifyListeners();
  }

  // ============================================================
  // INTERNAL
  // ============================================================

  void _setCurrent({
    required TheebFocusZone zone,
    required FocusNode node,
    required bool remember,
  }) {
    final changed = _currentZone != zone || _currentNode != node;

    _currentZone = zone;
    _currentNode = node;

    if (remember) {
      _lastFocusedNodes[zone] = node;
    }

    if (changed && !_disposed) {
      notifyListeners();
    }
  }

  bool _requestNode(FocusNode? node) {
    if (!_isNodeUsable(node)) {
      return false;
    }

    try {
      node!.requestFocus();

      return true;
    } catch (_) {
      return false;
    }
  }

  bool _isNodeUsable(FocusNode? node) {
    if (node == null) {
      return false;
    }

    if (!node.canRequestFocus) {
      return false;
    }

    if (node.context == null) {
      return false;
    }

    return true;
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    if (_disposed) {
      return;
    }

    _disposed = true;

    _lastFocusedNodes.clear();
    _defaultFocusNodes.clear();

    _currentZone = null;
    _currentNode = null;

    super.dispose();
  }
}
