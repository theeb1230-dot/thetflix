import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/app_theme.dart';
import '../../services/fullscreen_service.dart';
import '../../services/player_remote_actions.dart';
import '../../widgets/tv_focusable.dart';
import 'live_stream_player.dart';

class _Channel {
  final String name;
  final String logo;
  final String group;
  final String url;

  const _Channel(this.name, this.logo, this.group, this.url);
}

class LiveChannelsScreen extends StatefulWidget {
  final bool active;

  const LiveChannelsScreen({super.key, this.active = true});

  @override
  State<LiveChannelsScreen> createState() => _LiveChannelsScreenState();
}

class _LiveChannelsScreenState extends State<LiveChannelsScreen>
    with AutomaticKeepAliveClientMixin {
  late final Future<List<_Channel>> _future = _load();
  final _search = TextEditingController();
  final _gridController = ScrollController();

  String _query = '';
  String _category = 'الكل';
  _Channel? _selected;
  List<_Channel> _loadedChannels = const [];
  bool _fullscreen = false;

  static const _categoryOrder = <String>[
    'الكل',
    'سعودية',
    'أخبار',
    'رياضة',
    'أفلام',
    'مسلسلات',
    'أطفال',
    'ترفيه',
    'وثائقي',
    'أعمال',
    'عامة',
  ];

  /// قائمة محافظة ومقصودة لقنوات معروفة وذات حضور فعلي لدى المشاهد السعودي.
  /// نستخدمها بدلاً من عرض مئات القنوات الهامشية من ملف IPTV العام.
  static const _saudiRelevantTokens = <String>[
    'al saudiya',
    'al saudiya alaan',
    'sbc',
    'al ekhbar',
    'al quran al kareem',
    'al sunnah al nabawiyah',
    'ksa sports',
    'thikrayat',
    'saudi thaqafiya',
    'asharq news',
    'asharq discovery',
    'asharq documentary',
    'al arabiya',
    'al hadath',
    'mbc 1',
    'mbc 4',
    'mbc 5',
    'mbc drama',
    'mbc masr',
    'mbc iraq',
    'rotana cinema ksa',
    'rotana cinema egypt',
    'rotana classic',
    'rotana comedy',
    'rotana drama',
    'rotana khalij',
    'rotana clip',
    'rotana music',
    'al resalah',
    'al jazeera',
    'sky news arabia',
    'cnbc arabiya',
    'abu dhabi tv',
    'dubai tv',
    'sharjah tv',
    'sharjah sports',
    'alkass one',
    'alkass two',
    'spacetoon arabic',
    'babyfirst',
    'bbc arabic',
    'france 24 arabic',
    'dw arabic',
    'trt arabi',
  ];

  static const _blockedShiaReligiousTokens = <String>[
    'al maaref',
    'al-aimma',
    'al aimma',
    'al-naeem',
    'al naeem',
    'al wilayah',
    'al-jawadain',
    'al jawadain',
    'alabbassia',
    'beitolabbas',
    'imam hussein',
    'marjaeyat',
    'karbala documentary',
    'assirat',
    'as-sirat',
    'anwar tv2',
    'aliman tv',
    'safeer tv',
    'habib tv',
    'alghadeer',
    'al manar',
  ];

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    if (widget.active) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _bindRemoteActions());
    }
  }

  @override
  void didUpdateWidget(covariant LiveChannelsScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.active != widget.active && widget.active) {
      _bindRemoteActions();
    }
  }

  @override
  void dispose() {
    _search.dispose();
    _gridController.dispose();
    super.dispose();
  }

  void _bindRemoteActions() {
    if (!mounted || !widget.active) return;
    TheebPlayerRemoteActions.bind(
      toggleFullscreen: _toggleFullscreen,
      next: _nextChannel,
      previous: _previousChannel,
      scroll: _scrollGrid,
    );
  }

  Future<void> _toggleFullscreen() async {
    if (_selected == null) return;
    final entering = !_fullscreen;
    try {
      if (entering) {
        await enterTheebFullscreen();
      } else {
        await exitTheebFullscreen();
      }
    } catch (_) {}
    if (!mounted) return;
    setState(() => _fullscreen = entering);
  }

  Future<void> _nextChannel() async {
    final channels = _visibleChannels;
    if (channels.isEmpty) return;
    final current = _selected;
    final index = current == null ? -1 : channels.indexOf(current);
    final next = channels[(index + 1).clamp(0, channels.length - 1)];
    if (mounted) setState(() => _selected = next);
  }

  Future<void> _previousChannel() async {
    final channels = _visibleChannels;
    if (channels.isEmpty) return;
    final current = _selected;
    final index = current == null ? channels.length : channels.indexOf(current);
    final previousIndex = (index <= 0 ? 0 : index - 1).clamp(0, channels.length - 1);
    if (mounted) setState(() => _selected = channels[previousIndex]);
  }

  Future<void> _scrollGrid(double direction) async {
    if (!_gridController.hasClients || direction == 0 || _fullscreen) return;
    final position = _gridController.position;
    final target = (_gridController.offset + direction.sign * 280)
        .clamp(position.minScrollExtent, position.maxScrollExtent)
        .toDouble();
    if (target == _gridController.offset) return;
    await _gridController.animateTo(
      target,
      duration: const Duration(milliseconds: 160),
      curve: Curves.easeOutCubic,
    );
  }

  bool _isBlockedReligiousChannel(String name, String group) {
    final normalized = '$name $group'.toLowerCase();
    return _blockedShiaReligiousTokens.any(normalized.contains);
  }

  bool _isSaudiRelevant(String name) {
    final normalized = name.toLowerCase();
    return _saudiRelevantTokens.any(normalized.contains);
  }

  String _cleanName(String value) {
    return value
        .replaceAll(RegExp(r'\s*\([^)]*p\)'), '')
        .replaceAll(RegExp(r'\s*\[[^]]*\]'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  String _categoryFor(String name, String rawGroup) {
    final n = name.toLowerCase();
    final group = rawGroup.toLowerCase();
    bool has(String value) => n.contains(value) || group.contains(value);

    if (has('al saudiya') ||
        has('sbc') ||
        has('al ekhbar') ||
        has('ksa sports') ||
        has('thikrayat') ||
        has('saudi thaqafiya') ||
        has('al quran al kareem') ||
        has('al sunnah al nabawiyah')) {
      return 'سعودية';
    }
    if (has('news') ||
        has('arabiya') ||
        has('hadath') ||
        has('jazeera') ||
        has('bbc') ||
        has('france 24') ||
        has('dw arabic') ||
        has('trt arabi')) {
      return 'أخبار';
    }
    if (has('sport') || has('alkass')) return 'رياضة';
    if (has('cinema') || has('classic') || has('movie')) return 'أفلام';
    if (has('drama')) return 'مسلسلات';
    if (has('spacetoon') || has('babyfirst') || has('kids')) return 'أطفال';
    if (has('discovery') || has('documentary')) return 'وثائقي';
    if (has('business') || has('cnbc')) return 'أعمال';
    if (has('rotana') || has('mbc')) return 'ترفيه';
    return 'عامة';
  }

  Future<List<_Channel>> _load() async {
    final raw = await rootBundle.loadString('assets/data/arab_channels.m3u');
    final lines = raw.split(RegExp(r'\r?\n'));
    final result = <_Channel>[];
    final seenNames = <String>{};

    for (var index = 0; index < lines.length; index++) {
      final info = lines[index].trim();
      if (!info.startsWith('#EXTINF:')) continue;

      final rawName = info.contains(',')
          ? info.substring(info.lastIndexOf(',') + 1).trim()
          : 'قناة';
      final name = _cleanName(rawName);
      final sourceGroup =
          RegExp(r'group-title="([^"]*)"').firstMatch(info)?.group(1) ?? '';

      if (name.toLowerCase().contains(' usa') ||
          _isBlockedReligiousChannel(name, sourceGroup) ||
          !_isSaudiRelevant(name)) {
        continue;
      }

      final logo = RegExp(r'tvg-logo="([^"]*)"').firstMatch(info)?.group(1) ?? '';
      String? url;
      for (var cursor = index + 1;
          cursor < lines.length && cursor < index + 7;
          cursor++) {
        final candidate = lines[cursor].trim();
        if (candidate.startsWith('#EXTINF:')) break;
        if (candidate.startsWith('http://') || candidate.startsWith('https://')) {
          url = candidate;
          break;
        }
      }
      if (url == null || url.isEmpty) continue;

      final nameKey = name.toLowerCase();
      if (!seenNames.add(nameKey)) continue;
      result.add(_Channel(name, logo, _categoryFor(name, sourceGroup), url));
    }

    result.sort((a, b) {
      final category = _categoryOrder
          .indexOf(a.group)
          .compareTo(_categoryOrder.indexOf(b.group));
      return category != 0 ? category : a.name.compareTo(b.name);
    });
    _loadedChannels = result;
    if (_selected == null && result.isNotEmpty) _selected = result.first;
    return result;
  }

  List<_Channel> get _visibleChannels {
    final q = _query.toLowerCase();
    return _loadedChannels.where((channel) {
      final matchesCategory =
          _category == 'الكل' || channel.group == _category;
      final matchesQuery = q.isEmpty ||
          channel.name.toLowerCase().contains(q) ||
          channel.group.toLowerCase().contains(q);
      return matchesCategory && matchesQuery;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (_fullscreen && _selected != null) {
      return Stack(
        fit: StackFit.expand,
        children: [
          ColoredBox(
            color: Colors.black,
            child: LiveStreamPlayer(url: _selected!.url, active: widget.active),
          ),
          PositionedDirectional(
            top: 14,
            start: 14,
            child: SafeArea(
              child: IconButton.filled(
                tooltip: 'الخروج من ملء الشاشة',
                onPressed: _toggleFullscreen,
                icon: const Icon(Icons.fullscreen_exit),
              ),
            ),
          ),
          PositionedDirectional(
            top: 14,
            end: 14,
            child: SafeArea(
              child: Chip(
                avatar: const Icon(Icons.circle, color: Colors.redAccent, size: 12),
                label: Text(_selected!.name),
              ),
            ),
          ),
        ],
      );
    }

    return FutureBuilder<List<_Channel>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('تعذر تحميل القنوات: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        _loadedChannels = snapshot.data!;
        final visible = _visibleChannels;
        final availableCategories = _categoryOrder
            .where(
              (category) =>
                  category == 'الكل' ||
                  _loadedChannels.any((channel) => channel.group == category),
            )
            .toList();
        final wide = MediaQuery.sizeOf(context).width >= 980;

        final browser = Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
              child: Row(
                children: [
                  const Expanded(
                    flex: 2,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'البث المباشر',
                          style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'قنوات منتقاة للمشاهد السعودي',
                          style: TextStyle(color: AppTheme.textSecondary),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 3,
                    child: TextField(
                      controller: _search,
                      onChanged: (value) => setState(() => _query = value.trim()),
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.search),
                        hintText: 'ابحث عن قناة…',
                        suffixIcon: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: Center(
                            widthFactor: 1,
                            child: Text('${visible.length}'),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 50,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                scrollDirection: Axis.horizontal,
                itemCount: availableCategories.length,
                separatorBuilder: (_, _) => const SizedBox(width: 7),
                itemBuilder: (_, index) {
                  final category = availableCategories[index];
                  return TheebTvFocusable(
                    onPressed: () => setState(() => _category = category),
                    child: ChoiceChip(
                      label: Text(category),
                      selected: _category == category,
                      onSelected: (_) => setState(() => _category = category),
                    ),
                  );
                },
              ),
            ),
            Expanded(
              child: GridView.builder(
                controller: _gridController,
                key: const PageStorageKey('live-grid-scroll-v2'),
                padding: const EdgeInsets.fromLTRB(16, 6, 16, 16),
                gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: wide ? 230 : 190,
                  childAspectRatio: 1.55,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: visible.length,
                itemBuilder: (_, index) {
                  final channel = visible[index];
                  return TheebTvFocusable(
                    onPressed: () => setState(() => _selected = channel),
                    child: _ChannelCard(
                      channel: channel,
                      selected: _selected == channel,
                    ),
                  );
                },
              ),
            ),
          ],
        );

        if (!wide) {
          return Column(
            children: [
              if (_selected != null)
                AspectRatio(
                  aspectRatio: 16 / 9,
                  child: LiveStreamPlayer(
                    key: ValueKey(_selected!.url),
                    url: _selected!.url,
                    active: widget.active,
                  ),
                ),
              _LiveToolbar(
                channel: _selected,
                onPrevious: _previousChannel,
                onNext: _nextChannel,
                onFullscreen: _toggleFullscreen,
              ),
              Expanded(child: browser),
            ],
          );
        }

        return Row(
          children: [
            Expanded(flex: 5, child: browser),
            const VerticalDivider(width: 1, color: AppTheme.border),
            Expanded(
              flex: 6,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: _selected == null
                            ? const ColoredBox(
                                color: Colors.black,
                                child: Center(child: Text('اختر قناة للمشاهدة')),
                              )
                            : LiveStreamPlayer(
                                key: ValueKey(_selected!.url),
                                url: _selected!.url,
                                active: widget.active,
                              ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    _LiveToolbar(
                      channel: _selected,
                      onPrevious: _previousChannel,
                      onNext: _nextChannel,
                      onFullscreen: _toggleFullscreen,
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _ChannelCard extends StatelessWidget {
  final _Channel channel;
  final bool selected;

  const _ChannelCard({required this.channel, required this.selected});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: selected
            ? AppTheme.primary.withValues(alpha: .30)
            : AppTheme.surface2,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: selected ? AppTheme.info : AppTheme.border),
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
            ),
            child: channel.logo.isEmpty
                ? const Icon(Icons.live_tv, color: Colors.black54)
                : Image.network(
                    channel.logo,
                    fit: BoxFit.contain,
                    errorBuilder: (_, _, _) =>
                        const Icon(Icons.live_tv, color: Colors.black54),
                  ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  channel.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 5),
                Text(
                  channel.group,
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LiveToolbar extends StatelessWidget {
  final _Channel? channel;
  final Future<void> Function() onPrevious;
  final Future<void> Function() onNext;
  final Future<void> Function() onFullscreen;

  const _LiveToolbar({
    required this.channel,
    required this.onPrevious,
    required this.onNext,
    required this.onFullscreen,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: AppTheme.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.border),
      ),
      child: Row(
        children: [
          const Icon(Icons.circle, size: 10, color: Colors.redAccent),
          const SizedBox(width: 7),
          Expanded(
            child: Text(
              channel?.name ?? 'لا توجد قناة محددة',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
          TheebTvFocusable(
            onPressed: onPrevious,
            child: IconButton.filledTonal(
              tooltip: 'القناة السابقة • زر 167',
              onPressed: onPrevious,
              icon: const Icon(Icons.skip_next),
            ),
          ),
          const SizedBox(width: 6),
          TheebTvFocusable(
            onPressed: onNext,
            child: IconButton.filledTonal(
              tooltip: 'القناة التالية • زر 166',
              onPressed: onNext,
              icon: const Icon(Icons.skip_previous),
            ),
          ),
          const SizedBox(width: 6),
          TheebTvFocusable(
            onPressed: onFullscreen,
            child: IconButton.filledTonal(
              tooltip: 'ملء الشاشة • زر 174',
              onPressed: onFullscreen,
              icon: const Icon(Icons.fullscreen),
            ),
          ),
        ],
      ),
    );
  }
}
