import 'dart:async';

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import '../../core/app_theme.dart';

/// مشغل مستقل للبث المباشر يعتمد VideoPlayer/ExoPlayer بدل WebView.
/// هذا يقلل الذاكرة والـ JavaScript ويعطي HLS مسارًا أنسب على Android/iOS.
class LiveStreamPlayer extends StatefulWidget {
  final String url;
  final bool active;

  const LiveStreamPlayer({
    super.key,
    required this.url,
    this.active = true,
  });

  @override
  State<LiveStreamPlayer> createState() => _LiveStreamPlayerState();
}

class _LiveStreamPlayerState extends State<LiveStreamPlayer> {
  VideoPlayerController? _controller;
  bool _loading = true;
  String? _error;
  Timer? _retryTimer;
  int _retry = 0;

  @override
  void initState() {
    super.initState();
    _open();
  }

  @override
  void didUpdateWidget(covariant LiveStreamPlayer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.url != widget.url) {
      _retry = 0;
      _open();
    } else if (oldWidget.active != widget.active) {
      if (widget.active) {
        _controller?.play();
      } else {
        _controller?.pause();
      }
    }
  }

  Future<void> _open() async {
    _retryTimer?.cancel();
    final old = _controller;
    _controller = null;
    await old?.dispose();
    if (mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final controller = VideoPlayerController.networkUrl(
        Uri.parse(widget.url),
        httpHeaders: const {
          'User-Agent':
              'Mozilla/5.0 (Linux; Android 14; TV) AppleWebKit/537.36 '
              '(KHTML, like Gecko) Chrome/142.0 Mobile Safari/537.36',
        },
        videoPlayerOptions: VideoPlayerOptions(
          mixWithOthers: false,
          allowBackgroundPlayback: false,
        ),
      );
      _controller = controller;
      await controller.initialize().timeout(const Duration(seconds: 14));
      await controller.setLooping(false);
      if (widget.active) {
        await controller.play();
      }
      if (!mounted) {
        return;
      }
      setState(() => _loading = false);
      controller.addListener(_watchState);
    } catch (error) {
      if (!mounted) {
        return;
      }
      setState(() {
        _loading = false;
        _error = error.toString();
      });
      _scheduleRetry();
    }
  }

  void _watchState() {
    final value = _controller?.value;
    if (value == null || !mounted) {
      return;
    }
    if (value.hasError && _error == null) {
      setState(() => _error = value.errorDescription ?? 'تعذر تشغيل البث');
      _scheduleRetry();
    }
  }

  void _scheduleRetry() {
    if (_retry >= 2 || _retryTimer?.isActive == true) {
      return;
    }
    _retry++;
    _retryTimer = Timer(Duration(seconds: 2 + _retry), _open);
  }

  @override
  void dispose() {
    _retryTimer?.cancel();
    _controller?.removeListener(_watchState);
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    return ColoredBox(
      color: Colors.black,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (controller != null && controller.value.isInitialized)
            Center(
              child: AspectRatio(
                aspectRatio: controller.value.aspectRatio > 0
                    ? controller.value.aspectRatio
                    : 16 / 9,
                child: VideoPlayer(controller),
              ),
            ),
          if (_loading)
            const Center(child: CircularProgressIndicator(color: AppTheme.info)),
          if (_error != null && !_loading)
            Center(
              child: FilledButton.icon(
                onPressed: () {
                  _retry = 0;
                  _open();
                },
                icon: const Icon(Icons.refresh),
                label: const Text('إعادة الاتصال'),
              ),
            ),
          if (controller != null && controller.value.isInitialized)
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                color: const Color(0x77000000),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () => controller.value.isPlaying
                          ? controller.pause()
                          : controller.play(),
                      icon: Icon(controller.value.isPlaying ? Icons.pause : Icons.play_arrow),
                    ),
                    const Spacer(),
                    const Icon(Icons.circle, size: 9, color: Colors.redAccent),
                    const SizedBox(width: 6),
                    const Text('مباشر', style: TextStyle(fontWeight: FontWeight.w800)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
