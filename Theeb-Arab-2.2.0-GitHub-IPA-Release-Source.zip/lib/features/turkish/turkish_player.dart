import 'package:flutter/material.dart';

import '../../widgets/theeb_player.dart';

/// المشغل المخصص لقسم المحتوى التركي.
/// يبقي كل قواعد الحماية والتنظيف الخاصة بـ anaplayer معزولة عن بقية الأقسام.
class TurkishPlayer extends StatelessWidget {
  final String url;
  final bool externalLoading;
  final bool active;

  const TurkishPlayer({
    super.key,
    required this.url,
    this.externalLoading = false,
    this.active = true,
  });

  @override
  Widget build(BuildContext context) {
    return TickerMode(
      enabled: active,
      child: TheebPlayer(
        url: url,
        externalLoading: externalLoading,
        active: active,
      ),
    );
  }
}
