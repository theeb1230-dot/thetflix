import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../core/app_theme.dart';

/// WebView خفيف مستقل لمشغلات البحث.
/// لا يحمل تنظيف DOM الخاص بالمشغل التركي، لذلك يقل العمل داخل الصفحة.
class SearchMediaPlayer extends StatefulWidget {
  final String url;
  final bool active;

  const SearchMediaPlayer({
    super.key,
    required this.url,
    this.active = true,
  });

  @override
  State<SearchMediaPlayer> createState() => _SearchMediaPlayerState();
}

class _SearchMediaPlayerState extends State<SearchMediaPlayer> {
  WebViewController? _controller;
  bool _loading = true;
  bool _error = false;
  Timer? _timeout;

  bool get _supported =>
      defaultTargetPlatform == TargetPlatform.android ||
      defaultTargetPlatform == TargetPlatform.iOS;

  @override
  void initState() {
    super.initState();
    if (_supported) {
      _initialize();
    }
  }

  @override
  void didUpdateWidget(covariant SearchMediaPlayer oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!_supported) {
      return;
    }
    if (oldWidget.url != widget.url) {
      _load();
    }
    if (oldWidget.active != widget.active) {
      _setPlaybackActive(widget.active);
    }
  }

  Future<void> _initialize() async {
    final controller = WebViewController();
    await controller.setJavaScriptMode(JavaScriptMode.unrestricted);
    await controller.setBackgroundColor(Colors.black);
    await controller.setNavigationDelegate(
      NavigationDelegate(
        onNavigationRequest: (request) {
          if (!request.isMainFrame) {
            return NavigationDecision.navigate;
          }
          final target = Uri.tryParse(request.url);
          final source = Uri.tryParse(widget.url);
          if (target == null || source == null) {
            return NavigationDecision.prevent;
          }
          if (target.scheme != 'https' && target.scheme != 'http') {
            return NavigationDecision.prevent;
          }
          String rootDomain(String host) {
            final parts = host.toLowerCase().split('.');
            if (parts.length < 2) {
              return host.toLowerCase();
            }
            return parts.sublist(parts.length - 2).join('.');
          }
          final targetHost = target.host.toLowerCase();
          final sourceHost = source.host.toLowerCase();
          final sameFamily = targetHost == sourceHost ||
              rootDomain(targetHost) == rootDomain(sourceHost);
          return sameFamily ? NavigationDecision.navigate : NavigationDecision.prevent;
        },
        onPageStarted: (_) {
          _timeout?.cancel();
          if (mounted) {
            setState(() {
              _loading = true;
              _error = false;
            });
          }
          _timeout = Timer(const Duration(seconds: 15), () {
            if (mounted && _loading) {
              setState(() => _error = true);
            }
          });
        },
        onPageFinished: (_) async {
          _timeout?.cancel();
          if (mounted) {
            setState(() {
              _loading = false;
              _error = false;
            });
          }
          await _installLeanGuards();
          await _setPlaybackActive(widget.active);
        },
        onWebResourceError: (error) {
          if (error.isForMainFrame == false) {
            return;
          }
          _timeout?.cancel();
          if (mounted) {
            setState(() {
              _loading = false;
              _error = true;
            });
          }
        },
      ),
    );
    _controller = controller;
    await _load();
  }

  Future<void> _load() async {
    final controller = _controller;
    final uri = Uri.tryParse(widget.url.trim());
    if (controller == null || uri == null ||
        (uri.scheme != 'https' && uri.scheme != 'http')) {
      return;
    }
    await controller.loadRequest(uri);
  }

  Future<void> _installLeanGuards() async {
    final controller = _controller;
    if (controller == null) {
      return;
    }
    try {
      await controller.runJavaScript('''
(() => {
  try {
    window.open = () => null;
    document.addEventListener('click', (event) => {
      const a = event.target?.closest?.('a[target="_blank"]');
      if (a) a.removeAttribute('target');
    }, true);
  } catch (_) {}
})();
''');
    } catch (_) {}
  }

  Future<void> _setPlaybackActive(bool active) async {
    final controller = _controller;
    if (controller == null) {
      return;
    }
    try {
      await controller.runJavaScript(active
          ? "document.querySelectorAll('video').forEach(v=>{if(v.paused&&v.autoplay){v.play().catch(()=>{});}});"
          : "document.querySelectorAll('video,audio').forEach(v=>{try{v.pause();}catch(_){}});");
    } catch (_) {}
  }

  @override
  void dispose() {
    _timeout?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_supported) {
      return const ColoredBox(
        color: Colors.black,
        child: Center(child: Text('المشغل متاح على Android و iOS')),
      );
    }
    final controller = _controller;
    if (controller == null) {
      return const ColoredBox(
        color: Colors.black,
        child: Center(child: CircularProgressIndicator()),
      );
    }
    return Stack(
      fit: StackFit.expand,
      children: [
        ColoredBox(color: Colors.black, child: WebViewWidget(controller: controller)),
        if (_loading)
          const IgnorePointer(
            child: ColoredBox(
              color: Color(0xAA000000),
              child: Center(child: CircularProgressIndicator(color: AppTheme.info)),
            ),
          ),
        if (_error)
          Center(
            child: FilledButton.icon(
              onPressed: _load,
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة تحميل المشغل'),
            ),
          ),
      ],
    );
  }
}
