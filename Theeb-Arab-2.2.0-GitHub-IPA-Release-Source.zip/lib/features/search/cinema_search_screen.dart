import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../core/app_theme.dart';
import '../../services/fullscreen_service.dart';
import '../../services/player_remote_actions.dart';
import '../../widgets/tv_focusable.dart';
import 'search_media_player.dart';

class CinemaMedia {
  final int id;
  final bool series;
  final String title;
  final String poster;
  final String year;
  final double rating;
  final int season;
  final int episode;

  const CinemaMedia({
    required this.id,
    required this.series,
    required this.title,
    required this.poster,
    required this.year,
    required this.rating,
    this.season = 1,
    this.episode = 1,
  });

  CinemaMedia copyWith({int? season, int? episode}) => CinemaMedia(
    id: id,
    series: series,
    title: title,
    poster: poster,
    year: year,
    rating: rating,
    season: season ?? this.season,
    episode: episode ?? this.episode,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'series': series,
    'title': title,
    'poster': poster,
    'year': year,
    'rating': rating,
    'season': season,
    'episode': episode,
  };

  factory CinemaMedia.fromJson(Map<String, dynamic> json) => CinemaMedia(
    id: (json['id'] as num?)?.toInt() ?? 0,
    series: json['series'] == true,
    title: (json['title'] ?? '').toString(),
    poster: (json['poster'] ?? '').toString(),
    year: (json['year'] ?? '').toString(),
    rating: (json['rating'] as num?)?.toDouble() ?? 0,
    season: (json['season'] as num?)?.toInt() ?? 1,
    episode: (json['episode'] as num?)?.toInt() ?? 1,
  );
}

class CinemaServer {
  final String name;
  final String movie;
  final String series;
  const CinemaServer(this.name, this.movie, this.series);

  String build(CinemaMedia media, int season, int episode) {
    final source = media.series ? series : movie;
    return source
        .replaceAll('{id}', '${media.id}')
        .replaceAll('{s}', '$season')
        .replaceAll('{e}', '$episode');
  }
}

const cinemaServers = <CinemaServer>[
  CinemaServer(
    'Pomfy',
    'https://api.pomfy.stream/filme/{id}#cor:6C63FF',
    'https://api.pomfy.stream/serie/{id}/{s}/{e}#cor:6C63FF',
  ),
  CinemaServer(
    'Videasy',
    'https://player.videasy.net/movie/{id}?color=6C63FF',
    'https://player.videasy.net/tv/{id}/{s}/{e}?color=6C63FF',
  ),
  CinemaServer(
    'Superflix',
    'https://superflixapi.one/filme/{id}#noEpList#noLink#color:6C63FF',
    'https://superflixapi.one/serie/{id}/{s}/{e}#noEpList#noLink#color:6C63FF',
  ),
  CinemaServer(
    'VidFast',
    'https://vidfast.pro/movie/{id}?server=samba&hideServerControls=true&autoPlay=true&theme=6C63FF',
    'https://vidfast.pro/tv/{id}/{s}/{e}?server=samba&hideServerControls=true&autoPlay=true&theme=6C63FF',
  ),
  CinemaServer(
    'VidSrc Pro',
    'https://vidsrc.pro/embed/movie/{id}',
    'https://vidsrc.pro/embed/tv/{id}/{s}/{e}',
  ),
  CinemaServer(
    'VidSrc To',
    'https://vidsrc.to/embed/movie/{id}',
    'https://vidsrc.to/embed/tv/{id}/{s}/{e}',
  ),
  CinemaServer(
    'SuperEmbed',
    'https://multiembed.mov/directstream.php?video_id={id}&tmdb=1',
    'https://multiembed.mov/directstream.php?video_id={id}&tmdb=1&s={s}&e={e}',
  ),
  CinemaServer(
    '2Embed',
    'https://www.2embed.cc/embed/{id}',
    'https://www.2embed.cc/embedtv/{id}&s={s}&e={e}',
  ),
  CinemaServer(
    'AutoEmbed',
    'https://player.autoembed.cc/embed/movie/{id}',
    'https://player.autoembed.cc/embed/tv/{id}/{s}/{e}',
  ),
  CinemaServer(
    'VidSrc Me',
    'https://vidsrc.me/embed/movie?tmdb={id}',
    'https://vidsrc.me/embed/tv?tmdb={id}&season={s}&episode={e}',
  ),
  CinemaServer(
    'EmbedSu',
    'https://embed.su/embed/movie/{id}',
    'https://embed.su/embed/tv/{id}/{s}/{e}',
  ),
  CinemaServer(
    'SmashyStream',
    'https://player.smashy.stream/movie/{id}',
    'https://player.smashy.stream/tv/{id}?s={s}&e={e}',
  ),
  CinemaServer(
    'NontonGo',
    'https://www.NontonGo.win/embed/movie/{id}',
    'https://www.NontonGo.win/embed/tv/{id}/{s}/{e}',
  ),
  CinemaServer(
    'MovieAPI',
    'https://movieapi.club/movie/{id}',
    'https://movieapi.club/tv/{id}-{s}-{e}',
  ),
  CinemaServer(
    'VidBox',
    'https://vidbox.to/embed/movie/{id}',
    'https://vidbox.to/embed/tv/{id}/{s}/{e}',
  ),
  CinemaServer(
    'MoviesAPI',
    'https://moviesapi.club/movie/{id}',
    'https://moviesapi.club/tv/{id}-{s}-{e}',
  ),
  CinemaServer(
    'Fembed',
    'https://fembed.sx/e/{id}',
    'https://fembed.sx/e/{id}/{s}-{e}',
  ),
  CinemaServer(
    'Frembed',
    'https://www.frembed.pro/api/film.php?id={id}',
    'https://www.frembed.pro/api/film.php?id={id}&s={s}&e={e}',
  ),
  CinemaServer(
    'DatabaseGdrive',
    'https://databasegdriveplayer.xyz/player.php?type=movie&tmdb={id}',
    'https://databasegdriveplayer.xyz/player.php?type=tv&tmdb={id}&season={s}&episode={e}',
  ),
  CinemaServer(
    'أنمي داي',
    'https://anime.videoportal.cc/embed/{id}',
    'https://anime.videoportal.cc/embed/{id}/{s}/{e}',
  ),
  CinemaServer(
    'AnimeVibe',
    'https://animevibe.to/embed?id={id}',
    'https://animevibe.to/embed?id={id}&s={s}&e={e}',
  ),
  CinemaServer(
    'VidSrc XYZ',
    'https://vidsrc.xyz/embed/movie/{id}',
    'https://vidsrc.xyz/embed/tv/{id}/{s}/{e}',
  ),
  CinemaServer(
    'StreamHD',
    'https://streamhd.to/embed/movie/{id}',
    'https://streamhd.to/embed/tv/{id}/{s}/{e}',
  ),
  CinemaServer(
    'VidLink',
    'https://vidlink.pro/embed/movie/{id}',
    'https://vidlink.pro/embed/tv/{id}/{s}/{e}',
  ),
  CinemaServer(
    'FilmFast',
    'https://filmfast.net/embed/{id}',
    'https://filmfast.net/embed/{id}?s={s}&e={e}',
  ),
  CinemaServer(
    'ArabStream',
    'https://embed.arabstream.net/movie/{id}',
    'https://embed.arabstream.net/tv/{id}/{s}/{e}',
  ),
  CinemaServer(
    'الاحتياطي العام',
    'https://vidsrc.in/embed/movie/{id}',
    'https://vidsrc.in/embed/tv/{id}/{s}/{e}',
  ),
];

class _SeasonMeta {
  final int number;
  final String name;
  final int episodeCount;
  const _SeasonMeta(this.number, this.name, this.episodeCount);
}

class CinemaSearchScreen extends StatefulWidget {
  final bool active;
  const CinemaSearchScreen({super.key, this.active = true});

  @override
  State<CinemaSearchScreen> createState() => _CinemaSearchScreenState();
}

class _CinemaSearchScreenState extends State<CinemaSearchScreen>
    with AutomaticKeepAliveClientMixin {
  static const _apiKey = String.fromEnvironment(
    'TMDB_API_KEY',
    defaultValue: '3644dd4950b67cd8067b8772de576d6b',
  );
  static const _favoritesKey = 'ARAB_SEARCH_FAVORITES_V2';
  static const _historyKey = 'ARAB_SEARCH_HISTORY_V2';

  final _query = TextEditingController();
  final _scrollController = ScrollController();
  List<CinemaMedia> _results = const [];
  List<CinemaMedia> _favorites = const [];
  List<CinemaMedia> _history = const [];
  List<_SeasonMeta> _seasons = const [];
  CinemaMedia? _selected;
  int _season = 1;
  int _episode = 1;
  int _episodeCount = 1;
  int _server = 0;
  bool _loading = false;
  bool _fullscreen = false;
  bool _loadingEpisodes = false;
  String? _error;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _restore();
    if (widget.active) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _bindRemoteActions());
    }
  }

  @override
  void didUpdateWidget(covariant CinemaSearchScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.active != widget.active && widget.active) {
      _bindRemoteActions();
    }
  }

  void _bindRemoteActions() {
    if (!mounted || !widget.active) return;
    TheebPlayerRemoteActions.bind(
      toggleFullscreen: _toggleFullscreen,
      next: _nextEpisode,
      previous: _previousEpisode,
      scroll: _scrollPage,
    );
  }

  Future<void> _scrollPage(double direction) async {
    if (!_scrollController.hasClients || direction == 0 || _fullscreen) return;
    final position = _scrollController.position;
    final target = (_scrollController.offset + direction.sign * 240)
        .clamp(position.minScrollExtent, position.maxScrollExtent)
        .toDouble();
    if (target == _scrollController.offset) return;
    await _scrollController.animateTo(
      target,
      duration: const Duration(milliseconds: 160),
      curve: Curves.easeOutCubic,
    );
  }

  Future<void> _toggleFullscreen() async {
    final selected = _selected;
    if (selected == null) return;
    final entering = !_fullscreen;
    try {
      if (entering) {
        await enterTheebFullscreen();
      } else {
        await exitTheebFullscreen();
      }
    } catch (_) {}
    if (!mounted) return;
    setState(() => _fullscreen = entering);
  }

  @override
  void dispose() {
    _query.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _restore() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) {
        return;
      }
    setState(() {
      _favorites = _decode(
        prefs.getString(_favoritesKey) ?? prefs.getString('ARAB_SEARCH_FAVORITES_V1'),
      );
      _history = _decode(
        prefs.getString(_historyKey) ?? prefs.getString('ARAB_SEARCH_HISTORY_V1'),
      );
    });
  }

  List<CinemaMedia> _decode(String? raw) {
    if (raw == null) {
      return const [];
    }
    try {
      return (jsonDecode(raw) as List)
          .whereType<Map>()
          .map((item) => CinemaMedia.fromJson(Map<String, dynamic>.from(item)))
          .where((item) => item.id > 0)
          .toList();
    } catch (_) {
      return const [];
    }
  }

  Future<Map<String, dynamic>> _tmdb(String path) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
    try {
      final uri = Uri.https('api.themoviedb.org', '/3$path', {
        'api_key': _apiKey,
        'language': 'ar-SA',
      });
      final response = await (await client.getUrl(uri)).close();
      if (response.statusCode != HttpStatus.ok) {
        throw HttpException('TMDB ${response.statusCode}');
      }
      return Map<String, dynamic>.from(
        jsonDecode(await utf8.decoder.bind(response).join()) as Map,
      );
    } finally {
      client.close(force: true);
    }
  }

  Future<void> _search() async {
    final value = _query.text.trim();
    if (value.isEmpty || _loading) {
      return;
    }
    FocusManager.instance.primaryFocus?.unfocus();
    setState(() {
      _loading = true;
      _error = null;
    });
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
    try {
      final uri = Uri.https('api.themoviedb.org', '/3/search/multi', {
        'api_key': _apiKey,
        'query': value,
        'include_adult': 'false',
        'language': 'ar-SA',
      });
      final response = await (await client.getUrl(uri)).close();
      if (response.statusCode != HttpStatus.ok) {
        throw HttpException('TMDB ${response.statusCode}');
      }
      final body = jsonDecode(await utf8.decoder.bind(response).join()) as Map;
      final found = (body['results'] as List? ?? const [])
          .whereType<Map>()
          .where((item) => item['media_type'] == 'movie' || item['media_type'] == 'tv')
          .map((item) {
            final series = item['media_type'] == 'tv';
            final date = (item[series ? 'first_air_date' : 'release_date'] ?? '').toString();
            final id = (item['id'] as num?)?.toInt() ?? 0;
            return CinemaMedia(
              id: id,
              series: series,
              title: (item[series ? 'name' : 'title'] ?? '').toString(),
              poster: item['poster_path'] == null
                  ? ''
                  : 'https://image.tmdb.org/t/p/w342${item['poster_path']}',
              year: date.isEmpty ? '' : date.split('-').first,
              rating: (item['vote_average'] as num?)?.toDouble() ?? 0,
            );
          })
          .where((item) => item.id > 0 && item.title.isNotEmpty)
          .toList();
      if (mounted) {
        setState(() => _results = found);
      }
    } catch (error) {
      if (mounted) {
        setState(() => _error = 'تعذر البحث الآن: $error');
      }
    } finally {
      client.close(force: true);
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _select(CinemaMedia media) async {
    setState(() {
      _selected = media;
      _season = media.series ? media.season.clamp(1, 999).toInt() : 1;
      _episode = media.series ? media.episode.clamp(1, 9999).toInt() : 1;
      _seasons = const [];
      _episodeCount = 1;
      _error = null;
    });
    if (media.series) {
      await _loadSeriesMetadata(preferredSeason: _season, preferredEpisode: _episode);
    }
    await _saveProgress();
  }

  Future<void> _loadSeriesMetadata({int preferredSeason = 1, int preferredEpisode = 1}) async {
    final media = _selected;
    if (media == null || !media.series) {
      return;
    }
    setState(() => _loadingEpisodes = true);
    try {
      final details = await _tmdb('/tv/${media.id}');
      final seasons = (details['seasons'] as List? ?? const [])
          .whereType<Map>()
          .map((item) => _SeasonMeta(
                (item['season_number'] as num?)?.toInt() ?? 0,
                (item['name'] ?? '').toString(),
                (item['episode_count'] as num?)?.toInt() ?? 0,
              ))
          .where((item) => item.number > 0 && item.episodeCount > 0)
          .toList()
        ..sort((a, b) => a.number.compareTo(b.number));
      if (seasons.isEmpty) {
        throw const FormatException('لا توجد مواسم قابلة للتشغيل');
      }
      final season = seasons.any((item) => item.number == preferredSeason)
          ? preferredSeason
          : seasons.first.number;
      if (!mounted) {
        return;
      }
      setState(() {
        _seasons = seasons;
        _season = season;
      });
      await _loadSeasonEpisodes(season, preferredEpisode: preferredEpisode, persist: false);
    } catch (error) {
      if (mounted) {
        setState(() => _error = 'تعذر استخراج المواسم من TMDB: $error');
      }
    } finally {
      if (mounted) {
        setState(() => _loadingEpisodes = false);
      }
    }
  }

  Future<void> _loadSeasonEpisodes(
    int season, {
    int preferredEpisode = 1,
    bool persist = true,
  }) async {
    final media = _selected;
    if (media == null || !media.series) {
      return;
    }
    setState(() => _loadingEpisodes = true);
    try {
      final details = await _tmdb('/tv/${media.id}/season/$season');
      final episodes = (details['episodes'] as List? ?? const [])
          .whereType<Map>()
          .map((item) => (item['episode_number'] as num?)?.toInt() ?? 0)
          .where((value) => value > 0)
          .toList();
      final count = episodes.isEmpty
          ? (_seasons.where((s) => s.number == season).firstOrNull?.episodeCount ?? 1)
          : episodes.reduce((a, b) => a > b ? a : b);
      if (!mounted) {
        return;
      }
      setState(() {
        _season = season;
        _episodeCount = count.clamp(1, 9999).toInt();
        _episode = preferredEpisode.clamp(1, _episodeCount).toInt();
      });
      if (persist) {
        await _saveProgress();
      }
    } catch (error) {
      final fallback = _seasons.where((s) => s.number == season).firstOrNull?.episodeCount ?? 1;
      if (mounted) {
        setState(() {
          _season = season;
          _episodeCount = fallback.clamp(1, 9999).toInt();
          _episode = preferredEpisode.clamp(1, _episodeCount).toInt();
          _error = 'تعذر جلب تفاصيل الموسم؛ تم استخدام العدد المتاح في TMDB.';
        });
      }
      if (persist) {
        await _saveProgress();
      }
    } finally {
      if (mounted) {
        setState(() => _loadingEpisodes = false);
      }
    }
  }

  Future<void> _setEpisode(int value) async {
    if (value == _episode) {
      return;
    }
    setState(() => _episode = value.clamp(1, _episodeCount).toInt());
    await _saveProgress();
  }

  Future<void> _previousEpisode() async {
    if (_selected?.series != true || _seasons.isEmpty) {
      return;
    }
    if (_episode > 1) {
      await _setEpisode(_episode - 1);
      return;
    }
    final index = _seasons.indexWhere((item) => item.number == _season);
    if (index <= 0) {
      return;
    }
    final previous = _seasons[index - 1];
    await _loadSeasonEpisodes(
      previous.number,
      preferredEpisode: previous.episodeCount,
    );
  }

  Future<void> _nextEpisode() async {
    if (_selected?.series != true || _seasons.isEmpty) {
      return;
    }
    if (_episode < _episodeCount) {
      await _setEpisode(_episode + 1);
      return;
    }
    final index = _seasons.indexWhere((item) => item.number == _season);
    if (index < 0 || index >= _seasons.length - 1) {
      return;
    }
    await _loadSeasonEpisodes(_seasons[index + 1].number, preferredEpisode: 1);
  }

  bool get _canPrevious {
    if (_selected?.series != true || _seasons.isEmpty) {
      return false;
    }
    if (_episode > 1) {
      return true;
    }
    return _seasons.indexWhere((item) => item.number == _season) > 0;
  }

  bool get _canNext {
    if (_selected?.series != true || _seasons.isEmpty) {
      return false;
    }
    if (_episode < _episodeCount) {
      return true;
    }
    final index = _seasons.indexWhere((item) => item.number == _season);
    return index >= 0 && index < _seasons.length - 1;
  }

  Future<void> _saveProgress() async {
    final media = _selected;
    if (media == null) {
      return;
    }
    final current = media.copyWith(season: _season, episode: _episode);
    final next = [
      current,
      ..._history.where((item) => !(item.id == current.id && item.series == current.series)),
    ].take(30).toList();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _historyKey,
      jsonEncode(next.map((item) => item.toJson()).toList()),
    );
    if (mounted) {
      setState(() => _history = next);
    }
  }

  Future<void> _toggleFavorite() async {
    final media = _selected;
    if (media == null) {
      return;
    }
    final current = media.copyWith(season: _season, episode: _episode);
    final exists = _favorites.any((item) => item.id == current.id && item.series == current.series);
    final next = exists
        ? _favorites.where((item) => !(item.id == current.id && item.series == current.series)).toList()
        : [current, ..._favorites];
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _favoritesKey,
      jsonEncode(next.map((item) => item.toJson()).toList()),
    );
    if (mounted) {
      setState(() => _favorites = next);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final compact = MediaQuery.sizeOf(context).width < 700;
    final selected = _selected;
    final url = selected == null
        ? ''
        : cinemaServers[_server].build(selected, _season, _episode);
    if (_fullscreen && selected != null) {
      return Stack(
        fit: StackFit.expand,
        children: [
          ColoredBox(
            color: Colors.black,
            child: SearchMediaPlayer(url: url, active: widget.active),
          ),
          PositionedDirectional(
            top: 14,
            start: 14,
            child: SafeArea(
              child: IconButton.filled(
                tooltip: 'الخروج من ملء الشاشة',
                onPressed: _toggleFullscreen,
                icon: const Icon(Icons.fullscreen_exit),
              ),
            ),
          ),
        ],
      );
    }
    return ListView(
      controller: _scrollController,
      key: const PageStorageKey('cinema-search-scroll'),
      padding: EdgeInsets.all(compact ? 14 : 24),
      children: [
        const Text(
          'البحث والمشاهدة',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _query,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _search(),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'ابحث باسم الفيلم أو المسلسل…',
                ),
              ),
            ),
            const SizedBox(width: 8),
            FilledButton.icon(
              onPressed: _loading ? null : _search,
              icon: const Icon(Icons.search),
              label: const Text('بحث'),
            ),
          ],
        ),
        if (_loading) const LinearProgressIndicator(),
        if (_error != null) ...[
          const SizedBox(height: 8),
          Text(_error!, style: const TextStyle(color: AppTheme.danger)),
        ],
        if (_results.isNotEmpty) ...[
          const SizedBox(height: 12),
          SizedBox(
            height: 190,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _results.length,
              separatorBuilder: (_, _) => const SizedBox(width: 8),
              itemBuilder: (_, index) => _ResultCard(
                media: _results[index],
                onPressed: () => _select(_results[index]),
              ),
            ),
          ),
        ],
        if (selected != null) ...[
          const SizedBox(height: 18),
          _SelectedHeader(media: selected),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              SizedBox(
                width: 220,
                child: DropdownButtonFormField<int>(
                  key: ValueKey('search-server-$_server'),
                  initialValue: _server,
                  decoration: const InputDecoration(labelText: 'السيرفر'),
                  items: List.generate(
                    cinemaServers.length,
                    (index) => DropdownMenuItem(
                      value: index,
                      child: Text('${index + 1} - ${cinemaServers[index].name}'),
                    ),
                  ),
                  onChanged: (value) => setState(() => _server = value ?? 0),
                ),
              ),
              if (selected.series)
                SizedBox(
                  width: 155,
                  child: DropdownButtonFormField<int>(
                    key: ValueKey('search-season-$_season-${_seasons.length}'),
                    initialValue: _seasons.any((item) => item.number == _season) ? _season : null,
                    decoration: const InputDecoration(labelText: 'الموسم'),
                    items: _seasons
                        .map((item) => DropdownMenuItem(
                              value: item.number,
                              child: Text('الموسم ${item.number}'),
                            ))
                        .toList(),
                    onChanged: _loadingEpisodes
                        ? null
                        : (value) {
                            if (value != null) {
                              _loadSeasonEpisodes(value);
                            }
                          },
                  ),
                ),
              if (selected.series)
                SizedBox(
                  width: 155,
                  child: DropdownButtonFormField<int>(
                    key: ValueKey('search-episode-$_season-$_episode-$_episodeCount'),
                    initialValue: _episode.clamp(1, _episodeCount).toInt(),
                    decoration: const InputDecoration(labelText: 'الحلقة'),
                    menuMaxHeight: 420,
                    items: List.generate(
                      _episodeCount,
                      (index) => DropdownMenuItem(
                        value: index + 1,
                        child: Text('الحلقة ${index + 1}'),
                      ),
                    ),
                    onChanged: _loadingEpisodes
                        ? null
                        : (value) {
                            if (value != null) {
                              _setEpisode(value);
                            }
                          },
                  ),
                ),
              if (selected.series)
                FilledButton.tonalIcon(
                  onPressed: _canPrevious ? _previousEpisode : null,
                  icon: const Icon(Icons.skip_next),
                  label: const Text('السابقة'),
                ),
              if (selected.series)
                FilledButton.tonalIcon(
                  onPressed: _canNext ? _nextEpisode : null,
                  icon: const Icon(Icons.skip_previous),
                  label: const Text('التالية'),
                ),
              IconButton.filledTonal(
                onPressed: _toggleFullscreen,
                tooltip: 'ملء الشاشة',
                icon: const Icon(Icons.fullscreen),
              ),
              IconButton.filledTonal(
                onPressed: _toggleFavorite,
                tooltip: 'مفضلة البحث',
                icon: Icon(
                  _favorites.any((item) => item.id == selected.id && item.series == selected.series)
                      ? Icons.favorite
                      : Icons.favorite_border,
                ),
              ),
            ],
          ),
          if (_loadingEpisodes) const Padding(
            padding: EdgeInsets.only(top: 8),
            child: LinearProgressIndicator(),
          ),
          const SizedBox(height: 12),
          AspectRatio(
            aspectRatio: 16 / 9,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: RepaintBoundary(
                child: SearchMediaPlayer(url: url, active: widget.active),
              ),
            ),
          ),
        ],
        _SavedRow(
          title: 'مفضلة البحث',
          icon: Icons.favorite,
          items: _favorites,
          onPressed: _select,
        ),
        _SavedRow(
          title: 'سجل مشاهدة البحث',
          icon: Icons.history,
          items: _history,
          onPressed: _select,
        ),
      ],
    );
  }
}

class _SelectedHeader extends StatelessWidget {
  final CinemaMedia media;
  const _SelectedHeader({required this.media});

  @override
  Widget build(BuildContext context) => Row(
    children: [
      ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: SizedBox(
          width: 62,
          height: 88,
          child: media.poster.isEmpty
              ? const ColoredBox(color: AppTheme.surface2, child: Icon(Icons.movie))
              : Image.network(media.poster, fit: BoxFit.cover),
        ),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(media.title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text(
              '${media.series ? 'مسلسل' : 'فيلم'}${media.year.isEmpty ? '' : ' • ${media.year}'} • TMDB ${media.id}',
              style: const TextStyle(color: AppTheme.textMuted),
            ),
          ],
        ),
      ),
    ],
  );
}

class _ResultCard extends StatelessWidget {
  final CinemaMedia media;
  final VoidCallback onPressed;
  const _ResultCard({required this.media, required this.onPressed});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: 126,
    child: TheebTvFocusable(
      onPressed: onPressed,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          fit: StackFit.expand,
          children: [
            ColoredBox(
              color: AppTheme.surface2,
              child: media.poster.isEmpty
                  ? const Icon(Icons.movie)
                  : Image.network(media.poster, fit: BoxFit.cover),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(7),
                color: Colors.black87,
                child: Text(
                  media.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class _SavedRow extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<CinemaMedia> items;
  final ValueChanged<CinemaMedia> onPressed;
  const _SavedRow({
    required this.title,
    required this.icon,
    required this.items,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return const SizedBox.shrink();
    }
    return Padding(
      padding: const EdgeInsets.only(top: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon),
              const SizedBox(width: 8),
              Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 142,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: items.length,
              separatorBuilder: (_, _) => const SizedBox(width: 9),
              itemBuilder: (_, index) {
                final item = items[index];
                return SizedBox(
                  width: 210,
                  child: TheebTvFocusable(
                    onPressed: () => onPressed(item),
                    child: Container(
                      decoration: BoxDecoration(
                        color: AppTheme.surface2,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: AppTheme.border),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: Row(
                        children: [
                          SizedBox(
                            width: 86,
                            height: double.infinity,
                            child: item.poster.isEmpty
                                ? const Icon(Icons.movie)
                                : Image.network(item.poster, fit: BoxFit.cover),
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.all(9),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item.title,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontWeight: FontWeight.w900),
                                  ),
                                  const SizedBox(height: 5),
                                  Text(
                                    item.series
                                        ? 'م ${item.season} • ح ${item.episode}'
                                        : 'فيلم',
                                    style: const TextStyle(
                                      color: AppTheme.textMuted,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

extension _FirstOrNullExtension<T> on Iterable<T> {
  T? get firstOrNull {
    final iterator = this.iterator;
    return iterator.moveNext() ? iterator.current : null;
  }
}
