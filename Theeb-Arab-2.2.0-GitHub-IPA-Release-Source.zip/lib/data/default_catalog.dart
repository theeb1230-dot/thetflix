import '../models/theeb_models.dart';

const List<TheebCatalogItem> theebDefaultCatalog = [
  TheebCatalogItem(
    title: '📺 مسلسل وادي الذئاب (Kurtlar Vadisi Pusu)',
    slug: 'kurtlar-vadisi-pusu',
    type: TheebContentType.tv,
    isBuiltIn: true,
    seasons: [
      TheebSeason(number: 1, episodes: 9),
      TheebSeason(number: 2, episodes: 32),
      TheebSeason(number: 3, episodes: 22),
    ],
  ),

  TheebCatalogItem(
    title: '📺 مسلسل المنظمة (Teskilat)',
    slug: 'teskilat',
    type: TheebContentType.tv,
    isBuiltIn: true,
    seasons: [TheebSeason(number: 1, episodes: 184)],
  ),

  TheebCatalogItem(
    title: '📺 مسلسل ثلاث قروش (Uc Kurus)',
    slug: 'uc-kurus',
    type: TheebContentType.tv,
    isBuiltIn: true,
    seasons: [TheebSeason(number: 1, episodes: 28)],
  ),

  TheebCatalogItem(
    title: '📺 مسلسل رامو (Ramo)',
    slug: 'ramo',
    type: TheebContentType.tv,
    isBuiltIn: true,
    seasons: [TheebSeason(number: 1, episodes: 40)],
  ),

  TheebCatalogItem(
    title: '📺 مسلسل قطاع طرق لن يحكموا العالم (Eskiya Dunyaya)',
    slug: 'eskiya-dunyaya-hukumdar-olmaz',
    type: TheebContentType.tv,
    isBuiltIn: true,
    seasons: [
      TheebSeason(number: 1, episodes: 40),
      TheebSeason(number: 2, episodes: 31),
      TheebSeason(number: 3, episodes: 36),
      TheebSeason(number: 4, episodes: 32),
      TheebSeason(number: 5, episodes: 26),
      TheebSeason(number: 6, episodes: 34),
    ],
  ),

  TheebCatalogItem(
    title: '📺 مسلسل قيامة أرطغرل (Dirilis Ertugrul)',
    slug: 'dirilis-ertugrul',
    type: TheebContentType.tv,
    isBuiltIn: true,
    seasons: [TheebSeason(number: 1, episodes: 150)],
  ),

  TheebCatalogItem(
    title: '📺 مسلسل المؤسس عثمان (Kurulus Osman)',
    slug: 'kurulus-osman',
    type: TheebContentType.tv,
    isBuiltIn: true,
    seasons: [TheebSeason(number: 1, episodes: 194)],
  ),

  TheebCatalogItem(
    title: '📺 مسلسل الحفرة (Cukur)',
    slug: 'cukur',
    type: TheebContentType.tv,
    isBuiltIn: true,
    seasons: [
      TheebSeason(number: 1, episodes: 33),
      TheebSeason(number: 2, episodes: 34),
      TheebSeason(number: 3, episodes: 26),
      TheebSeason(number: 4, episodes: 39),
    ],
  ),

  TheebCatalogItem(
    title: '📺 مسلسل الذئب الوحيد (Yalniz Kurt)',
    slug: 'yalniz-kurt',
    type: TheebContentType.tv,
    isBuiltIn: true,
    seasons: [TheebSeason(number: 1, episodes: 32)],
  ),

  TheebCatalogItem(
    title: '🎬 فيلم وادي الذئاب غلاديو (2009)',
    slug: 'kurtlar-vadisi-gladstatus',
    type: TheebContentType.movie,
    isBuiltIn: true,
  ),

  TheebCatalogItem(
    title: '🎬 فيلم وادي الذئاب الوطن (2017)',
    slug: 'kurtlar-vadisi-vatan',
    type: TheebContentType.movie,
    isBuiltIn: true,
  ),

  TheebCatalogItem(
    title: '🎬 فيلم وادي الذئاب فلسطين (2011)',
    slug: 'kurtlar-vadisi-filistin',
    type: TheebContentType.movie,
    isBuiltIn: true,
  ),

  TheebCatalogItem(
    title: '🎬 فيلم وادي الذئاب العراق (2006)',
    slug: 'kurtlar-vadisi-irak',
    type: TheebContentType.movie,
    isBuiltIn: true,
  ),
];
