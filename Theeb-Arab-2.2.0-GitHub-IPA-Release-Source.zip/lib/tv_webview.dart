import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class TvWebView extends StatefulWidget {
  final String url;

  const TvWebView({super.key, required this.url});

  @override
  State<TvWebView> createState() => _TvWebViewState();
}

class _TvWebViewState extends State<TvWebView> {
  bool isLoading = true;

  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (!mounted) {
              return;
            }

            setState(() {
              isLoading = true;
            });
          },
          onPageFinished: (_) {
            if (!mounted) {
              return;
            }

            setState(() {
              isLoading = false;
            });

            _forceAutoPlay();
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  void didUpdateWidget(covariant TvWebView oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.url == oldWidget.url) {
      return;
    }

    if (mounted) {
      setState(() {
        isLoading = true;
      });
    }

    _controller.loadRequest(Uri.parse(widget.url));
  }

  Future<void> _forceAutoPlay() async {
    try {
      await _controller.runJavaScript('''
        (() => {
          try {
            const video = document.querySelector('video');

            if (video) {
              const playResult = video.play();

              if (
                playResult &&
                typeof playResult.catch === 'function'
              ) {
                playResult.catch(() => {});
              }

              return;
            }

            const button =
              document.querySelector('.vjs-big-play-button');

            if (button) {
              button.click();
            }
          } catch (_) {}
        })();
      ''');
    } catch (_) {
      // فشل التشغيل التلقائي لا يعني فشل WebView.
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        WebViewWidget(controller: _controller),
        if (isLoading)
          Container(
            color: Colors.black.withValues(alpha: 0.9),
            child: const Center(
              child: CircularProgressIndicator(color: Color(0xFFD4AF37)),
            ),
          ),
      ],
    );
  }
}
