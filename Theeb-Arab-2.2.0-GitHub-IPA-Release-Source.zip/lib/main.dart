import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:dpad/dpad.dart';

import 'core/app_theme.dart';
import 'screens/arab_clean_shell.dart';
import 'services/theeb_storage.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  FlutterError.onError = (details) {
    FlutterError.presentError(details);

    if (kDebugMode) {
      debugPrint('[THEEB] Flutter error: ${details.exceptionAsString()}');
    }
  };

  Object? startupError;

  try {
    await TheebStorage.init();

    // إعدادات SystemChrome مخصصة لتطبيقات Android / iOS.
    // نتجنب تنفيذها على Web.
    if (!kIsWeb) {
      const target = String.fromEnvironment(
        'THEEB_TARGET',
        defaultValue: String.fromEnvironment(
      'THEEB_PLATFORM',
      defaultValue: 'adaptive',
    ),
      );
      await SystemChrome.setPreferredOrientations(
        target == 'tv'
            ? [
                DeviceOrientation.landscapeLeft,
                DeviceOrientation.landscapeRight,
              ]
            : [
                DeviceOrientation.portraitUp,
                DeviceOrientation.landscapeLeft,
                DeviceOrientation.landscapeRight,
              ],
      );

      await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

      SystemChrome.setSystemUIOverlayStyle(
        const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.light,
          statusBarBrightness: Brightness.dark,
          systemNavigationBarColor: AppTheme.background,
          systemNavigationBarIconBrightness: Brightness.light,
        ),
      );
    }
  } catch (error, stackTrace) {
    startupError = error;

    debugPrint('[THEEB] Startup failed: $error');
    debugPrintStack(
      label: '[THEEB] Startup stack trace',
      stackTrace: stackTrace,
    );
  }

  runApp(TheebApp(startupError: startupError));
}

class TheebApp extends StatelessWidget {
  final Object? startupError;

  const TheebApp({super.key, this.startupError});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ذيب العرب',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.dark,
      locale: const Locale('ar'),
      builder: (context, child) {
        return Dpad(
          keySet: const DpadKeySet(
            up: <LogicalKeyboardKey>[
              LogicalKeyboardKey.arrowUp,
              LogicalKeyboardKey.channelUp,
            ],
            down: <LogicalKeyboardKey>[
              LogicalKeyboardKey.arrowDown,
              LogicalKeyboardKey.channelDown,
            ],
          ),
          restoreFocus: true,
          debugOverlay: false,
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: child ?? const SizedBox.shrink(),
          ),
        );
      },
      home: startupError == null
          ? const ArabCleanShell()
          : _TheebStartupErrorScreen(error: startupError!),
    );
  }
}

class _TheebStartupErrorScreen extends StatelessWidget {
  final Object error;

  const _TheebStartupErrorScreen({required this.error});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.border),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.error_outline_rounded,
                      color: AppTheme.danger,
                      size: 54,
                    ),

                    const SizedBox(height: 16),

                    const Text(
                      'تعذر تشغيل ذيب',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                      ),
                    ),

                    const SizedBox(height: 8),

                    const Text(
                      'حدث خطأ أثناء تهيئة التطبيق.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 13,
                      ),
                    ),

                    if (kDebugMode) ...[
                      const SizedBox(height: 16),

                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.25),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: SelectableText(
                          error.toString(),
                          textDirection: TextDirection.ltr,
                          style: const TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 11,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
