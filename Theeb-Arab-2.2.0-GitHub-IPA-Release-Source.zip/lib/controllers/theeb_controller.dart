import 'package:flutter/foundation.dart';

import '../models/theeb_models.dart';
import '../services/theeb_storage.dart';

class TheebController extends ChangeNotifier {
  TheebController({required List<TheebCatalogItem> defaultCatalog})
    : _defaultCatalog = List.unmodifiable(defaultCatalog);

  final List<TheebCatalogItem> _defaultCatalog;

  bool _initialized = false;
  bool _loading = false;
  bool _mobileMode = false;
  bool _disposed = false;

  List<TheebCatalogItem> _customCatalog = [];
  List<TheebCatalogItem> _catalog = [];

  List<TheebFavorite> _favorites = [];
  List<TheebHistoryItem> _history = [];

  late TheebPlayerState _state;

  int _loadGeneration = 0;

  Future<void> _historyWriteQueue = Future<void>.value();

  // ============================================================
  // GETTERS
  // ============================================================

  bool get initialized => _initialized;

  bool get loading => _loading;

  bool get mobileMode => _mobileMode;

  List<TheebCatalogItem> get catalog {
    return List.unmodifiable(_catalog);
  }

  List<TheebCatalogItem> get customCatalog {
    return List.unmodifiable(_customCatalog);
  }

  List<TheebFavorite> get favorites {
    return List.unmodifiable(_favorites);
  }

  List<TheebHistoryItem> get history {
    return List.unmodifiable(_history);
  }

  TheebPlayerState get state => _state;

  TheebCatalogItem get currentShow => _state.currentShow;

  int get season => _state.season;

  int get episode => _state.episode;

  int get server => _state.server;

  bool get isMovie => _state.isMovie;

  bool get isTv => _state.isTv;

  // ============================================================
  // SAFE NOTIFY
  // ============================================================

  void _notify() {
    if (_disposed) {
      return;
    }

    notifyListeners();
  }

  // ============================================================
  // INITIALIZATION
  // ============================================================

  Future<void> initialize() async {
    if (_initialized || _disposed) {
      return;
    }

    _customCatalog = await TheebStorage.getCustomCatalog();

    if (_disposed) {
      return;
    }

    _favorites = await TheebStorage.getFavorites();

    if (_disposed) {
      return;
    }

    _history = await TheebStorage.getHistory();

    if (_disposed) {
      return;
    }

    _rebuildCatalog();

    if (_catalog.isEmpty) {
      throw StateError('Theeb catalog cannot be empty.');
    }

    _state = TheebPlayerState.initial(_catalog.first);

    final savedSession = await TheebStorage.getSession();
    if (_disposed) return;
    if (savedSession != null) {
      _restoreSession(savedSession);
    }

    _initialized = true;

    await loadCurrent();
  }

  void _rebuildCatalog() {
    _catalog = [..._customCatalog, ..._defaultCatalog];
  }

  void _restoreSession(TheebSessionState session) {
    final showIndex = _catalog.indexWhere(
      (item) => item.normalizedSlug == normalizeCatalogIdentity(session.slug),
    );
    if (showIndex < 0) return;

    final show = _catalog[showIndex];
    var season = 1;
    var episode = 1;
    if (show.isTv && show.seasons.isNotEmpty) {
      final seasonIndex = show.seasons.indexWhere(
        (item) => item.number == session.season,
      );
      final selectedSeason = seasonIndex < 0
          ? show.seasons.first
          : show.seasons[seasonIndex];
      season = selectedSeason.number;
      episode = session.episode.clamp(1, selectedSeason.episodes);
    }

    _mobileMode = session.mobileMode;
    _state = _state.copyWith(
      currentShow: show,
      slug: show.slug,
      type: show.type,
      season: season,
      episode: episode,
      server: session.server.clamp(1, TheebConfig.maxServers),
    );
  }

  Future<void> _saveSession() async {
    if (!_initialized || _disposed) return;
    await TheebStorage.saveSession(
      TheebSessionState(
        slug: _state.slug,
        season: _state.season,
        episode: _state.episode,
        server: _state.server,
        mobileMode: _mobileMode,
      ),
    );
  }

  // ============================================================
  // PLAYER URL
  // ============================================================

  String get currentUrl {
    final episodePath = _state.type == TheebContentType.tv
        ? '-s${_state.season.toString().padLeft(2, '0')}'
              'e${_state.episode.toString().padLeft(2, '0')}'
        : '';

    return '${TheebConfig.baseUrl}'
        '${_state.slug}'
        '$episodePath'
        '/?serv=${_state.server}';
  }

  // ============================================================
  // PLAYER LOAD
  // ============================================================

  Future<void> loadCurrent() async {
    if (!_initialized || _disposed) {
      return;
    }

    final snapshot = _state;

    final generation = ++_loadGeneration;

    _loading = true;

    _notify();

    try {
      await Future.wait<void>([_queueHistoryWrite(snapshot), _saveSession()]);
    } catch (error, stackTrace) {
      debugPrint('[THEEB] Failed to save history: $error');

      debugPrintStack(stackTrace: stackTrace);
    }

    if (_disposed || generation != _loadGeneration) {
      return;
    }

    _loading = false;

    _notify();
  }

  // ============================================================
  // SHOW SELECTION
  // ============================================================

  Future<void> selectShow(TheebCatalogItem show) async {
    if (!_initialized || _disposed) {
      return;
    }

    final exists = _catalog.any((item) => item.slug == show.slug);

    if (!exists) {
      return;
    }

    int firstSeason = 1;

    if (show.isTv && show.seasons.isNotEmpty) {
      firstSeason = show.seasons.first.number;
    }

    final sameSelection =
        _state.slug == show.slug &&
        _state.type == show.type &&
        _state.season == firstSeason &&
        _state.episode == 1;

    if (sameSelection) {
      return;
    }

    _state = _state.copyWith(
      currentShow: show,
      slug: show.slug,
      type: show.type,
      season: firstSeason,
      episode: 1,
    );

    _notify();

    await loadCurrent();
  }

  Future<void> selectShowBySlug(String slug) async {
    if (!_initialized || _disposed) {
      return;
    }

    final normalized = slug.trim();

    if (normalized.isEmpty) {
      return;
    }

    final index = _catalog.indexWhere((item) => item.slug == normalized);

    if (index == -1) {
      return;
    }

    await selectShow(_catalog[index]);
  }

  // ============================================================
  // SEASONS
  // ============================================================

  List<TheebSeason> get availableSeasons {
    if (_state.isMovie) {
      return const [];
    }

    return List.unmodifiable(currentShow.seasons);
  }

  Future<void> setSeason(int seasonNumber) async {
    if (!_initialized || _disposed || _state.isMovie) {
      return;
    }

    final exists = currentShow.seasons.any(
      (item) => item.number == seasonNumber,
    );

    if (!exists) {
      return;
    }

    if (_state.season == seasonNumber && _state.episode == 1) {
      return;
    }

    _state = _state.copyWith(season: seasonNumber, episode: 1);

    _notify();

    await loadCurrent();
  }

  // ============================================================
  // EPISODES
  // ============================================================

  int get currentSeasonEpisodeCount {
    if (_state.isMovie) {
      return 0;
    }

    for (final season in currentShow.seasons) {
      if (season.number == _state.season) {
        return season.episodes;
      }
    }

    return 10;
  }

  List<int> get availableEpisodes {
    final count = currentSeasonEpisodeCount;

    if (count <= 0) {
      return const [];
    }

    return List<int>.generate(count, (index) => index + 1);
  }

  Future<void> setEpisode(int episodeNumber) async {
    if (!_initialized || _disposed || _state.isMovie) {
      return;
    }

    final maxEpisodes = currentSeasonEpisodeCount;

    if (episodeNumber < 1 || episodeNumber > maxEpisodes) {
      return;
    }

    if (_state.episode == episodeNumber) {
      return;
    }

    _state = _state.copyWith(episode: episodeNumber);

    _notify();

    await loadCurrent();
  }

  // ============================================================
  // SERVERS
  // ============================================================

  List<int> get servers {
    return List<int>.generate(TheebConfig.maxServers, (index) => index + 1);
  }

  Future<void> setServer(int serverNumber) async {
    if (!_initialized || _disposed) {
      return;
    }

    if (serverNumber < 1 || serverNumber > TheebConfig.maxServers) {
      return;
    }

    if (_state.server == serverNumber) {
      return;
    }

    _state = _state.copyWith(server: serverNumber);

    _notify();

    await loadCurrent();
  }

  // ============================================================
  // PREVIOUS / NEXT
  // ============================================================

  bool get canGoPrevious {
    if (_state.isMovie || currentShow.seasons.isEmpty) {
      return false;
    }

    final firstSeason = currentShow.seasons.first;

    return !(_state.season == firstSeason.number && _state.episode == 1);
  }

  bool get canGoNext {
    if (_state.isMovie || currentShow.seasons.isEmpty) {
      return false;
    }

    final lastSeason = currentShow.seasons.last;

    return !(_state.season == lastSeason.number &&
        _state.episode == lastSeason.episodes);
  }

  Future<void> previousEpisode() async {
    if (!_initialized || _disposed || !canGoPrevious) {
      return;
    }

    final seasons = currentShow.seasons;

    final currentSeasonIndex = seasons.indexWhere(
      (item) => item.number == _state.season,
    );

    if (currentSeasonIndex == -1) {
      return;
    }

    final targetEpisode = _state.episode - 1;

    if (targetEpisode >= 1) {
      _state = _state.copyWith(episode: targetEpisode);
    } else if (currentSeasonIndex > 0) {
      final previousSeason = seasons[currentSeasonIndex - 1];

      _state = _state.copyWith(
        season: previousSeason.number,
        episode: previousSeason.episodes,
      );
    } else {
      return;
    }

    _notify();

    await loadCurrent();
  }

  Future<void> nextEpisode() async {
    if (!_initialized || _disposed || !canGoNext) {
      return;
    }

    final seasons = currentShow.seasons;

    final currentSeasonIndex = seasons.indexWhere(
      (item) => item.number == _state.season,
    );

    if (currentSeasonIndex == -1) {
      return;
    }

    final currentSeason = seasons[currentSeasonIndex];

    final targetEpisode = _state.episode + 1;

    if (targetEpisode <= currentSeason.episodes) {
      _state = _state.copyWith(episode: targetEpisode);
    } else if (currentSeasonIndex < seasons.length - 1) {
      final nextSeason = seasons[currentSeasonIndex + 1];

      _state = _state.copyWith(season: nextSeason.number, episode: 1);
    } else {
      return;
    }

    _notify();

    await loadCurrent();
  }

  // ============================================================
  // FAVORITES
  // ============================================================

  bool get isCurrentFavorite {
    if (!_initialized) {
      return false;
    }

    return _favorites.any((item) => item.slug == _state.slug);
  }

  Future<bool> toggleFavorite() async {
    if (!_initialized || _disposed) {
      return false;
    }

    final index = _favorites.indexWhere((item) => item.slug == _state.slug);

    bool added;

    if (index >= 0) {
      _favorites.removeAt(index);

      added = false;
    } else {
      _favorites.insert(
        0,
        TheebFavorite(
          title: currentShow.displayTitle,
          slug: currentShow.slug,
          type: currentShow.type,
        ),
      );

      added = true;
    }

    await TheebStorage.saveFavorites(List<TheebFavorite>.from(_favorites));

    if (_disposed) {
      return added;
    }

    _notify();

    return added;
  }

  Future<void> removeFavoriteAt(int index) async {
    if (_disposed || index < 0 || index >= _favorites.length) {
      return;
    }

    _favorites.removeAt(index);

    await TheebStorage.saveFavorites(List<TheebFavorite>.from(_favorites));

    _notify();
  }

  Future<void> playFavorite(TheebFavorite favorite) async {
    if (_disposed) {
      return;
    }

    await selectShowBySlug(favorite.slug);
  }

  // ============================================================
  // HISTORY
  // ============================================================

  Future<void> _queueHistoryWrite(TheebPlayerState snapshot) {
    _historyWriteQueue = _historyWriteQueue
        .then((_) async {
          if (_disposed) {
            return;
          }

          await _writeHistorySnapshot(snapshot);
        })
        .catchError((Object error, StackTrace stackTrace) {
          debugPrint('[THEEB] History queue error: $error');

          debugPrintStack(stackTrace: stackTrace);
        });

    return _historyWriteQueue;
  }

  Future<void> _writeHistorySnapshot(TheebPlayerState snapshot) async {
    if (_disposed) {
      return;
    }

    _history.removeWhere((item) => item.slug == snapshot.slug);

    _history.insert(
      0,
      TheebHistoryItem(
        title: snapshot.currentShow.displayTitle,
        slug: snapshot.slug,
        type: snapshot.type,
        season: snapshot.season,
        episode: snapshot.episode,
        server: snapshot.server,
      ),
    );

    if (_history.length > TheebConfig.maxHistoryItems) {
      _history = _history.take(TheebConfig.maxHistoryItems).toList();
    }

    await TheebStorage.saveHistory(List<TheebHistoryItem>.from(_history));
  }

  Future<void> removeHistoryAt(int index) async {
    if (_disposed || index < 0 || index >= _history.length) {
      return;
    }

    _history.removeAt(index);

    final historySnapshot = List<TheebHistoryItem>.from(_history);

    _historyWriteQueue = _historyWriteQueue.then((_) async {
      if (_disposed) {
        return;
      }

      await TheebStorage.saveHistory(historySnapshot);
    });

    await _historyWriteQueue;

    _notify();
  }

  Future<void> playHistory(TheebHistoryItem item) async {
    if (!_initialized || _disposed) {
      return;
    }

    final index = _catalog.indexWhere((show) => show.slug == item.slug);

    if (index == -1) {
      return;
    }

    final show = _catalog[index];

    int restoredSeason = item.season;
    int restoredEpisode = item.episode;

    if (show.isTv) {
      if (show.seasons.isEmpty) {
        restoredSeason = 1;
        restoredEpisode = 1;
      } else {
        final matchingIndex = show.seasons.indexWhere(
          (value) => value.number == restoredSeason,
        );

        if (matchingIndex == -1) {
          restoredSeason = show.seasons.first.number;

          restoredEpisode = 1;
        } else {
          final maxEpisodes = show.seasons[matchingIndex].episodes;

          if (restoredEpisode < 1) {
            restoredEpisode = 1;
          }

          if (restoredEpisode > maxEpisodes) {
            restoredEpisode = maxEpisodes > 0 ? maxEpisodes : 1;
          }
        }
      }
    } else {
      restoredSeason = 1;
      restoredEpisode = 1;
    }

    int restoredServer = item.server;

    if (restoredServer < 1 || restoredServer > TheebConfig.maxServers) {
      restoredServer = 1;
    }

    _state = _state.copyWith(
      currentShow: show,
      slug: show.slug,
      type: show.type,
      season: restoredSeason,
      episode: restoredEpisode,
      server: restoredServer,
    );

    _notify();

    await loadCurrent();
  }

  // ============================================================
  // CUSTOM CATALOG VALIDATION
  // ============================================================

  String? validateCustomItemIdentity({
    required String slug,
    required String workTitle,
    int? ignoreIndex,
  }) {
    final normalizedSlug = normalizeCatalogIdentity(slug);

    final normalizedWorkTitle = normalizeCatalogIdentity(workTitle);

    if (normalizedSlug.isEmpty) {
      return 'اسم العمل المستخدم في الرابط لا يمكن أن يكون فارغًا';
    }

    for (int i = 0; i < _customCatalog.length; i++) {
      if (ignoreIndex != null && i == ignoreIndex) {
        continue;
      }

      final item = _customCatalog[i];

      final sameSlug = item.normalizedSlug == normalizedSlug;

      final sameWorkTitle =
          normalizedWorkTitle.isNotEmpty &&
          item.normalizedWorkTitle == normalizedWorkTitle;

      if (sameSlug || sameWorkTitle) {
        return 'يوجد عنصر مضاف مسبقًا بنفس اسم العمل';
      }
    }

    for (final item in _defaultCatalog) {
      final sameSlug = item.normalizedSlug == normalizedSlug;

      final sameWorkTitle =
          normalizedWorkTitle.isNotEmpty &&
          item.normalizedWorkTitle == normalizedWorkTitle;

      if (sameSlug || sameWorkTitle) {
        return 'يوجد عنصر في المكتبة الأساسية بنفس اسم العمل';
      }
    }

    return null;
  }

  bool customItemIdentityExists({
    required String slug,
    required String workTitle,
    int? ignoreIndex,
  }) {
    return validateCustomItemIdentity(
          slug: slug,
          workTitle: workTitle,
          ignoreIndex: ignoreIndex,
        ) !=
        null;
  }

  // ============================================================
  // CUSTOM CATALOG - ADD
  // ============================================================

  Future<TheebCatalogItem> addCustomItem({
    required TheebContentType type,
    required String arabicTitle,
    required String workTitle,
    required String slug,
    required List<int> episodeCounts,
  }) async {
    if (!_initialized || _disposed) {
      throw StateError('TheebController is not ready.');
    }

    final safeArabicTitle = arabicTitle.trim();

    final safeWorkTitle = workTitle.trim();

    final safeSlug = slug.trim();

    if (safeArabicTitle.isEmpty) {
      throw ArgumentError('الاسم العربي مطلوب');
    }

    if (safeWorkTitle.isEmpty) {
      throw ArgumentError('اسم العمل مطلوب');
    }

    if (safeSlug.isEmpty) {
      throw ArgumentError('اسم العمل المستخدم في الرابط مطلوب');
    }

    final validationError = validateCustomItemIdentity(
      slug: safeSlug,
      workTitle: safeWorkTitle,
    );

    if (validationError != null) {
      throw StateError(validationError);
    }

    final seasons = _buildCustomSeasons(
      type: type,
      episodeCounts: episodeCounts,
    );

    final input = TheebCustomItemInput(
      type: type,
      arabicTitle: safeArabicTitle,
      workTitle: safeWorkTitle,
      slug: safeSlug,
      seasons: seasons,
    );

    final item = input.toCatalogItem();

    _customCatalog.insert(0, item);

    await TheebStorage.saveCustomCatalog(
      List<TheebCatalogItem>.from(_customCatalog),
    );

    if (_disposed) {
      return item;
    }

    _rebuildCatalog();

    final initialSeason = item.isTv && item.seasons.isNotEmpty
        ? item.seasons.first.number
        : 1;

    _state = _state.copyWith(
      currentShow: item,
      slug: item.slug,
      type: item.type,
      season: initialSeason,
      episode: 1,
      server: 1,
    );

    _notify();

    await loadCurrent();

    return item;
  }

  // ============================================================
  // CUSTOM CATALOG - EDIT
  // ============================================================

  Future<TheebCatalogItem> updateCustomItemAt({
    required int index,
    required TheebContentType type,
    required String arabicTitle,
    required String workTitle,
    required String slug,
    required List<int> episodeCounts,
  }) async {
    if (!_initialized || _disposed) {
      throw StateError('TheebController is not ready.');
    }

    if (index < 0 || index >= _customCatalog.length) {
      throw RangeError.index(index, _customCatalog);
    }

    final oldItem = _customCatalog[index];

    final safeArabicTitle = arabicTitle.trim();

    final safeWorkTitle = workTitle.trim();

    final safeSlug = slug.trim();

    if (safeArabicTitle.isEmpty) {
      throw ArgumentError('الاسم العربي مطلوب');
    }

    if (safeWorkTitle.isEmpty) {
      throw ArgumentError('اسم العمل مطلوب');
    }

    if (safeSlug.isEmpty) {
      throw ArgumentError('اسم العمل المستخدم في الرابط مطلوب');
    }

    final validationError = validateCustomItemIdentity(
      slug: safeSlug,
      workTitle: safeWorkTitle,
      ignoreIndex: index,
    );

    if (validationError != null) {
      throw StateError(validationError);
    }

    final seasons = _buildCustomSeasons(
      type: type,
      episodeCounts: episodeCounts,
    );

    final input = TheebCustomItemInput(
      type: type,
      arabicTitle: safeArabicTitle,
      workTitle: safeWorkTitle,
      slug: safeSlug,
      seasons: seasons,
    );

    final updatedItem = input.toCatalogItem();

    _customCatalog[index] = updatedItem;

    _updateFavoriteReferences(oldItem: oldItem, newItem: updatedItem);

    _updateHistoryReferences(oldItem: oldItem, newItem: updatedItem);

    await Future.wait([
      TheebStorage.saveCustomCatalog(
        List<TheebCatalogItem>.from(_customCatalog),
      ),
      TheebStorage.saveFavorites(List<TheebFavorite>.from(_favorites)),
      TheebStorage.saveHistory(List<TheebHistoryItem>.from(_history)),
    ]);

    if (_disposed) {
      return updatedItem;
    }

    _rebuildCatalog();

    final wasCurrent = _state.slug == oldItem.slug;

    if (wasCurrent) {
      int restoredSeason = _state.season;
      int restoredEpisode = _state.episode;

      if (updatedItem.isMovie) {
        restoredSeason = 1;
        restoredEpisode = 1;
      } else if (updatedItem.seasons.isEmpty) {
        restoredSeason = 1;
        restoredEpisode = 1;
      } else {
        final seasonIndex = updatedItem.seasons.indexWhere(
          (value) => value.number == restoredSeason,
        );

        if (seasonIndex == -1) {
          restoredSeason = updatedItem.seasons.first.number;

          restoredEpisode = 1;
        } else {
          final maxEpisodes = updatedItem.seasons[seasonIndex].episodes;

          if (restoredEpisode < 1) {
            restoredEpisode = 1;
          }

          if (restoredEpisode > maxEpisodes) {
            restoredEpisode = maxEpisodes > 0 ? maxEpisodes : 1;
          }
        }
      }

      _state = _state.copyWith(
        currentShow: updatedItem,
        slug: updatedItem.slug,
        type: updatedItem.type,
        season: restoredSeason,
        episode: restoredEpisode,
      );

      _notify();

      await loadCurrent();
    } else {
      _notify();
    }

    return updatedItem;
  }

  List<TheebSeason> _buildCustomSeasons({
    required TheebContentType type,
    required List<int> episodeCounts,
  }) {
    if (type == TheebContentType.movie) {
      return const [];
    }

    final seasons = <TheebSeason>[];

    final count = episodeCounts.length > TheebConfig.maxCustomSeasons
        ? TheebConfig.maxCustomSeasons
        : episodeCounts.length;

    for (int i = 0; i < count; i++) {
      final rawEpisodes = episodeCounts[i];

      final episodes = rawEpisodes > 0 ? rawEpisodes : 10;

      seasons.add(TheebSeason(number: i + 1, episodes: episodes));
    }

    if (seasons.isEmpty) {
      return const [TheebSeason(number: 1, episodes: 10)];
    }

    return seasons;
  }

  void _updateFavoriteReferences({
    required TheebCatalogItem oldItem,
    required TheebCatalogItem newItem,
  }) {
    for (int i = 0; i < _favorites.length; i++) {
      final favorite = _favorites[i];

      if (favorite.slug != oldItem.slug) {
        continue;
      }

      _favorites[i] = favorite.copyWith(
        title: newItem.displayTitle,
        slug: newItem.slug,
        type: newItem.type,
      );
    }
  }

  void _updateHistoryReferences({
    required TheebCatalogItem oldItem,
    required TheebCatalogItem newItem,
  }) {
    for (int i = 0; i < _history.length; i++) {
      final history = _history[i];

      if (history.slug != oldItem.slug) {
        continue;
      }

      int season = history.season;

      int episode = history.episode;

      if (newItem.isMovie) {
        season = 1;
        episode = 1;
      } else if (newItem.seasons.isNotEmpty) {
        final seasonIndex = newItem.seasons.indexWhere(
          (value) => value.number == season,
        );

        if (seasonIndex == -1) {
          season = newItem.seasons.first.number;

          episode = 1;
        } else {
          final maxEpisodes = newItem.seasons[seasonIndex].episodes;

          if (episode < 1) {
            episode = 1;
          }

          if (episode > maxEpisodes) {
            episode = maxEpisodes > 0 ? maxEpisodes : 1;
          }
        }
      }

      _history[i] = history.copyWith(
        title: newItem.displayTitle,
        slug: newItem.slug,
        type: newItem.type,
        season: season,
        episode: episode,
      );
    }
  }

  // ============================================================
  // CUSTOM CATALOG - DELETE
  // ============================================================

  Future<void> deleteCustomItemAt(int index) async {
    if (_disposed || index < 0 || index >= _customCatalog.length) {
      return;
    }

    final removed = _customCatalog[index];

    final removedWasCurrent = _initialized && _state.slug == removed.slug;

    _customCatalog.removeAt(index);

    _favorites.removeWhere((item) => item.slug == removed.slug);

    _history.removeWhere((item) => item.slug == removed.slug);

    await Future.wait([
      TheebStorage.saveCustomCatalog(
        List<TheebCatalogItem>.from(_customCatalog),
      ),
      TheebStorage.saveFavorites(List<TheebFavorite>.from(_favorites)),
      TheebStorage.saveHistory(List<TheebHistoryItem>.from(_history)),
    ]);

    if (_disposed) {
      return;
    }

    _rebuildCatalog();

    if (_catalog.isEmpty) {
      throw StateError('Theeb catalog cannot be empty.');
    }

    if (removedWasCurrent) {
      _state = TheebPlayerState.initial(_catalog.first);

      _notify();

      await loadCurrent();

      return;
    }

    _notify();
  }

  // ============================================================
  // CUSTOM CATALOG - SEARCH
  // ============================================================

  List<TheebCatalogItem> searchCustomCatalog(String query) {
    final normalized = query.trim().toLowerCase();

    if (normalized.isEmpty) {
      return List.unmodifiable(_customCatalog);
    }

    return _customCatalog.where((item) {
      return item.displayTitle.toLowerCase().contains(normalized) ||
          item.arabicTitle.toLowerCase().contains(normalized) ||
          item.workTitle.toLowerCase().contains(normalized) ||
          item.slug.toLowerCase().contains(normalized);
    }).toList();
  }

  // ============================================================
  // CUSTOM CATALOG - CLEAR ALL
  // ============================================================

  Future<void> clearAllCustomItems() async {
    if (_disposed) {
      return;
    }

    final currentWasCustom =
        _initialized && _customCatalog.any((item) => item.slug == _state.slug);

    final removedSlugs = _customCatalog.map((item) => item.slug).toSet();

    _customCatalog.clear();

    _favorites.removeWhere((item) => removedSlugs.contains(item.slug));

    _history.removeWhere((item) => removedSlugs.contains(item.slug));

    await Future.wait([
      TheebStorage.clearCustomCatalog(),
      TheebStorage.saveFavorites(List<TheebFavorite>.from(_favorites)),
      TheebStorage.saveHistory(List<TheebHistoryItem>.from(_history)),
    ]);

    if (_disposed) {
      return;
    }

    _rebuildCatalog();

    if (_catalog.isEmpty) {
      throw StateError('Theeb catalog cannot be empty.');
    }

    if (currentWasCustom) {
      _state = TheebPlayerState.initial(_catalog.first);

      _notify();

      await loadCurrent();

      return;
    }

    _notify();
  }

  // ============================================================
  // CLEAR SAVED ACTIVITY
  // ============================================================

  Future<void> clearSavedActivity() async {
    if (_disposed) {
      return;
    }

    _favorites.clear();
    _history.clear();

    _historyWriteQueue = _historyWriteQueue.then((_) async {
      if (_disposed) {
        return;
      }

      await TheebStorage.clearSavedActivity();
    });

    await _historyWriteQueue;

    _notify();
  }

  // ============================================================
  // RESET LIBRARY DATA
  // ============================================================

  /// هذه الدالة ما زالت تمسح المكتبات المضافة فعليًا.
  ///
  /// لا نربطها بزر "إعادة الضبط" في لوحة إضافة المكتبة.
  /// زر إعادة الضبط الجديد سيقوم فقط بمسح حقول الإدخال.
  Future<void> resetToDefaults() async {
    if (_disposed) {
      return;
    }

    final removedSlugs = _customCatalog.map((item) => item.slug).toSet();

    _customCatalog.clear();

    _favorites.removeWhere((item) => removedSlugs.contains(item.slug));

    _history.removeWhere((item) => removedSlugs.contains(item.slug));

    await Future.wait([
      TheebStorage.resetCustomCatalog(),
      TheebStorage.saveFavorites(List<TheebFavorite>.from(_favorites)),
      TheebStorage.saveHistory(List<TheebHistoryItem>.from(_history)),
    ]);

    if (_disposed) {
      return;
    }

    _rebuildCatalog();

    if (_catalog.isEmpty) {
      throw StateError('Theeb catalog cannot be empty.');
    }

    _state = TheebPlayerState.initial(_catalog.first);

    _notify();

    await loadCurrent();
  }

  // ============================================================
  // MOBILE MODE
  // ============================================================

  Future<void> toggleMobileMode() async {
    if (_disposed) {
      return;
    }

    _mobileMode = !_mobileMode;

    _notify();
    await _saveSession();
  }

  Future<void> setMobileMode(bool enabled) async {
    if (_disposed || _mobileMode == enabled) {
      return;
    }

    _mobileMode = enabled;

    _notify();
    await _saveSession();
  }

  // ============================================================
  // MANUAL REFRESH
  // ============================================================

  Future<void> refreshPlayer() async {
    if (!_initialized || _disposed) {
      return;
    }

    await loadCurrent();
  }

  /// يضمن كتابة آخر اختيار قبل انتقال التطبيق للخلفية أو إغلاق النافذة.
  Future<void> persistSession() async {
    if (!_initialized || _disposed) return;
    await _saveSession();
    await _historyWriteQueue;
  }

  // ============================================================
  // DISPOSE
  // ============================================================

  @override
  void dispose() {
    _loadGeneration++;

    _disposed = true;

    super.dispose();
  }
}
