# ذيب العرب — Theeb Arab

تطبيق Flutter موحّد بثلاثة أقسام مستقلة:

- **تركي:** مكتبة ذيب التركية ومشغلها المحمي الخاص.
- **البحث:** بحث TMDB، أفلام ومسلسلات، مواسم وحلقات تلقائية، مفضلة وسجل متابعة.
- **مباشر:** قنوات عربية مصنفة مع مشغل HLS مباشر مستقل.

الإصدار الحالي في المصدر: `2.2.0+9`.

## بنية المشغلات

المشروع لا يستخدم مشغلاً واحداً لكل أنواع البيانات:

- `lib/features/turkish/turkish_player.dart` — واجهة مشغل القسم التركي ويعتمد قواعد `anaplayer` الموجودة في `TheebPlayer`.
- `lib/features/search/search_media_player.dart` — WebView خفيف مستقل لمصادر البحث، بدون DOM guards الثقيلة الخاصة بالقسم التركي.
- `lib/features/live/live_stream_player.dart` — تشغيل مباشر عبر `video_player`/ExoPlayer وAVPlayer، مع إعادة اتصال تلقائية.

## Google TV والماوس الافتراضي

`MainActivity.kt` يحوّل D-pad إلى مؤشر تلفزيون. عند وصول المؤشر قرب الحافة العلوية أو السفلية، يتم إرسال `ACTION_SCROLL` حقيقي تحت المؤشر، لذلك تتحرك `ListView` و`GridView` في البحث والمباشر بدلاً من تحرك المؤشر داخل حدود الشاشة فقط.

## البحث وTMDB

عند اختيار مسلسل:

1. يجلب التطبيق `/tv/{series_id}` لاستخراج المواسم.
2. يجلب `/tv/{series_id}/season/{season_number}` لاستخراج الحلقات الفعلية.
3. يعرض الموسم والحلقة في قائمتين منسدلتين.
4. زرا **السابقة** و**التالية** ينتقلان بين الحلقات والمواسم فعلياً.
5. سجل المشاهدة يحتفظ بسجل واحد لكل عمل ويحدّث الموسم والحلقة الأخيرة بدلاً من التكرار.
6. المفضلة والسجل يعرضان بوستر العمل.

يمكن تمرير مفتاح TMDB أثناء البناء:

```bash
--dart-define=TMDB_API_KEY=YOUR_KEY
```

## القنوات المباشرة

القائمة في `assets/data/arab_channels.m3u`. الواجهة تعيد تصنيف القنوات إلى مجموعات عربية واضحة مثل الأخبار والرياضة والأفلام والمسلسلات والأطفال والوثائقي والأعمال والموسيقى والثقافة والطبخ والتعليم والديني.

توجد قائمة استبعاد داخل `live_channels_screen.dart` للقنوات الدينية الشيعية التي تم التحقق منها. لا يتم حذف القنوات الإخبارية لمجرد انتماء سياسي/طائفي؛ الاستبعاد موجه للقنوات الدينية المقصودة.

## بناء Android

### دفعة واحدة على Windows

```powershell
powershell -ExecutionPolicy Bypass -File .\tool\build_android_releases.ps1
```

ينتج:

- `dist/theeb-arab-mobile-2.2.0.apk`
- `dist/theeb-arab-google-tv-2.2.0.apk`

أو يدوياً:

```powershell
flutter pub get
flutter analyze
flutter test
flutter build apk --release --target-platform android-arm64 --dart-define=THEEB_TARGET=mobile
flutter build apk --release --target-platform android-arm,android-arm64 --dart-define=THEEB_TARGET=tv
```

## تجهيز iPhone / IPA غير موقع

يتطلب macOS + Xcode. ملفات iOS في المشروع مجهزة باسم **ذيب العرب** وبـ Bundle ID `com.theebturk.app`، وتسمح بالبث الإعلامي عبر HTTP عند الحاجة.

```bash
./tool/build_unsigned_ios.sh
```

السكريبت يبني `Runner.app` بدون توقيع ثم يضعه داخل حاوية IPA في:

`dist/theeb-arab-ios-unsigned-2.2.0.ipa`

هذه الحزمة **غير موقعة**؛ يلزم توقيعها قبل التثبيت على جهاز فعلي.

## التحديث والمشاركة داخل الشبكة

مركز التحديثات يستخدم:

- manifest عبر الإنترنت عند ضبط `THEEB_UPDATE_MANIFEST_URL`.
- SHA-256 للتحقق من الحزمة.
- Bonjour/NSD لاكتشاف أجهزة ذيب العرب داخل الشبكة المحلية.
- خادم HTTP محلي مؤقت لنقل حزمة التحديث بين الأجهزة.

مثال:

```bash
flutter build apk --release \
  --dart-define=THEEB_UPDATE_MANIFEST_URL=https://example.com/update.json
```

راجع `update.example.json` و`UPDATES.md`.

## GitHub والأسرار

لا ترفع أبداً:

- `android/key.properties`
- `*.jks` / `*.keystore`
- `android/local.properties`
- مجلدات `.gradle`, `build`, `ios/Flutter/ephemeral`

المشروع يحتوي `android/key.properties.example` فقط كقالب عام. ملفات التوقيع المحلية يجب أن تبقى خارج المستودع العام.

## فحص المشروع

```bash
dart format lib test
flutter analyze
flutter test
```

ثم اختبر Google TV فعلياً، خصوصاً:

- التمرير عند حواف الماوس الافتراضي.
- قوائم الموسم والحلقة في البحث.
- السابق/التالي.
- تبديل السيرفرات.
- البث المباشر وإعادة الاتصال.
- حفظ المفضلة وسجل المشاهدة بعد إغلاق التطبيق.
