# بناء ذيب العرب 2.2.0

## Google TV remote
- 4056: تبديل وضع الماوس المدمج / التنقل بالريموت.
- 174: ملء الشاشة للقسم النشط (تركي / بحث / مباشر).
- 166: التالي. في التركي والبحث = الحلقة التالية، وفي المباشر = القناة التالية.
- 167: السابق. في التركي والبحث = الحلقة السابقة، وفي المباشر = القناة السابقة.
- الوضع الافتراضي عند فتح نسخة TV هو D-pad الحقيقي. المؤشر لا يظهر إلا بعد 4056.

## Windows: بناء نسختي Android
```powershell
powershell -ExecutionPolicy Bypass -File .\tool\build_android_releases.ps1
```
النتائج:
- `dist/theeb-arab-mobile-2.2.0.apk`
- `dist/theeb-arab-google-tv-2.2.0.apk`

## macOS: بناء IPA غير موقع
```bash
bash tool/build_unsigned_ios.sh
```
النتيجة:
- `dist/theeb-arab-ios-unsigned-2.2.0.ipa`

## GitHub Actions
بعد رفع المشروع، شغل workflow باسم `Build Theeb Arab 2.2.0` يدوياً، أو أنشئ Tag يبدأ بـ `v`.
سيبني نسختي Android وIPA غير موقع كـ Artifacts.
