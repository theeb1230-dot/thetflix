$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)

function Invoke-Flutter {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    & flutter @Arguments

    if ($LASTEXITCODE -ne 0) {
        throw "Flutter command failed with exit code ${LASTEXITCODE}: flutter $($Arguments -join ' ')"
    }
}

Write-Host "[1/7] Cleaning project..." -ForegroundColor Cyan
Invoke-Flutter @('clean')

Write-Host "[2/7] Resolving dependencies..." -ForegroundColor Cyan
Invoke-Flutter @('pub', 'get')

Write-Host "[3/7] Static analysis..." -ForegroundColor Cyan
Invoke-Flutter @('analyze')

Write-Host "[4/7] Running tests..." -ForegroundColor Cyan
Invoke-Flutter @('test')

New-Item -ItemType Directory -Force -Path dist | Out-Null

Write-Host "[5/7] Building Android mobile release..." -ForegroundColor Cyan
Invoke-Flutter @(
    'build', 'apk', '--release',
    '--target-platform', 'android-arm64',
    '--dart-define=THEEB_TARGET=mobile'
)
Copy-Item build\app\outputs\flutter-apk\app-release.apk dist\theeb-arab-mobile-2.2.0.apk -Force

Write-Host "[6/7] Building Google TV release..." -ForegroundColor Cyan
Invoke-Flutter @(
    'build', 'apk', '--release',
    '--target-platform', 'android-arm,android-arm64',
    '--dart-define=THEEB_TARGET=tv'
)
Copy-Item build\app\outputs\flutter-apk\app-release.apk dist\theeb-arab-google-tv-2.2.0.apk -Force

Write-Host "[7/7] Completed successfully." -ForegroundColor Green
Get-ChildItem dist\*.apk | Select-Object Name,Length,LastWriteTime
