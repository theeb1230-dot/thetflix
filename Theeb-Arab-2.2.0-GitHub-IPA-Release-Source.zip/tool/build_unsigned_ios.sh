#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
flutter clean
flutter pub get
flutter analyze
flutter test
flutter build ios --release --no-codesign --dart-define=THEEB_TARGET=mobile
rm -rf build/unsigned_ipa
mkdir -p build/unsigned_ipa/Payload dist
cp -R build/ios/iphoneos/Runner.app build/unsigned_ipa/Payload/
(
  cd build/unsigned_ipa
  /usr/bin/zip -qry ../../dist/theeb-arab-ios-unsigned-2.2.0.ipa Payload
)
echo "dist/theeb-arab-ios-unsigned-2.2.0.ipa"
