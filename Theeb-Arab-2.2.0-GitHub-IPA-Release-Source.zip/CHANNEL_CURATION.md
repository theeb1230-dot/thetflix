# مراجعة القنوات المباشرة — ذيب العرب

تمت مراجعة قائمة `assets/data/arab_channels.m3u` وإعادة التصنيف داخل `live_channels_screen.dart` بدل الاعتماد على `group-title` الخام فقط، لأن المصدر يحتوي مجموعات عامة أو خاطئة لبعض القنوات.

## الاستبعادات الدينية المطلوبة

تستبعد الواجهة القنوات الدينية الشيعية التالية عند التحميل، ولا تحذف القنوات الإخبارية أو السياسية لمجرد الانتماء أو التوجه:

- Al Maaref TV
- Al Wilayah
- Al-Aimma TV
- Al-Jawadain TV
- Al-Naeem TV
- Alabbassia TV
- Aliman TV
- Anwar TV2
- Assirat TV
- BeitolAbbas TV Channel
- Ch4Teen Documentary
- Habib TV
- Imam Hussein TV 2
- Karbala Documentary
- Marjaeyat TV Arabic
- Safeer TV

## تصحيحات تصنيف مهمة

- Al-Sahat TV → أخبار، وليس «ديني» كما في بيانات المصدر.
- Al Rafidain → أخبار، وليس «ديني» كما في بيانات المصدر.
- CBC Sofra / Jordan Kitchen → طبخ.
- Rotana Classic → أفلام.
- Rotana Clip / Rotana Tarab / Shabab FM → موسيقى.
- Asil TV / SAT-7 Arabic / Takbeer TV → ديني.
- Jordan Archive / Jordan Tourism / Qaf TV → ثقافة.

التصنيفات النهائية في التطبيق: أخبار، رياضة، أفلام، مسلسلات، أطفال، ترفيه، عامة، وثائقي، أعمال، موسيقى، ثقافة، طبخ، تعليم، ديني، أخرى.
