# التحقق من هذه الدفعة

تم التحقق داخل بيئة العمل من:

- صحة `pubspec.yaml` من ناحية YAML.
- صحة `web/manifest.json` و`update.example.json` من ناحية JSON.
- صحة `AndroidManifest.xml` و`ios/Runner/Info.plist` من ناحية XML.
- توازن الأقواس في ملفات Dart المعدلة بفحص ساكن إضافي.
- وجود 27 قالب سيرفر في قسم البحث كما في الاختبار الحالي.
- تجهيز اختبار إضافي لـ `CinemaMedia` للتأكد من حفظ البوستر وآخر موسم/حلقة.

## ما لم يمكن تشغيله هنا

أداة Flutter/Dart SDK غير مثبتة داخل حاوية العمل الحالية؛ لذلك لم يتم تنفيذ `dart format` أو `flutter analyze` أو `flutter test` أو بناء APK/IPA فعلياً داخل هذه الجلسة.

على Windows شغّل:

```powershell
flutter pub get
dart format lib test
flutter analyze
flutter test
powershell -ExecutionPolicy Bypass -File .\tool\build_android_releases.ps1
```

وعلى macOS عند وقت iPhone:

```bash
chmod +x tool/build_unsigned_ios.sh
./tool/build_unsigned_ios.sh
```

## Hotfix after Windows validation — 2026-08-27

تم إصلاح نتيجتي التحقق اللتين ظهرتا على Windows:

- إزالة تحذيرات `curly_braces_in_flow_control_structures` من ملفات المباشر والبحث.
- تعديل اختبار نافذة المكتبة ليستخدم `pump` بمدة محددة بدل `pumpAndSettle` لأن التطبيق يحتوي على animations/loaders مستمرة يمكن أن تمنع settle إلى الأبد.
- تقوية `tool/build_android_releases.ps1` بحيث يتوقف فورًا عند فشل أي أمر Flutter. في PowerShell، `$ErrorActionPreference = "Stop"` وحده لا يضمن إيقاف السكربت عند non-zero exit code لبرنامج خارجي؛ لذلك أصبح السكربت يفحص `$LASTEXITCODE` بعد كل أمر.

أعد التشغيل بهذا الترتيب:

```powershell
dart format lib test
flutter analyze
flutter test
powershell -ExecutionPolicy Bypass -File .\tool\build_android_releases.ps1
```
