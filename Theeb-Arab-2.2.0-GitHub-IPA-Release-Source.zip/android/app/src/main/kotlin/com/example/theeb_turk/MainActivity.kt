package com.theebturk.app

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    private lateinit var cursorView: TvCursorView
    private var lastBackPressedAt = 0L
    private var remoteChannel: MethodChannel? = null
    private var cursorMode = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        remoteChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            REMOTE_CHANNEL,
        )
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            UPDATER_CHANNEL,
        ).setMethodCallHandler { call, result ->
            if (call.method != "installApk") {
                result.notImplemented()
                return@setMethodCallHandler
            }
            val path = call.argument<String>("path")
            if (path.isNullOrBlank()) {
                result.error("INVALID_PATH", "مسار ملف التحديث غير صالح.", null)
                return@setMethodCallHandler
            }
            installApk(path, result)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cursorView = TvCursorView()
        val content = window.decorView as FrameLayout
        content.addView(
            cursorView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )
        cursorView.bringToFront()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // بعض ريموتات Google TV/TCL ترسل القيمة كـ keyCode، وأخرى تضعها
        // في scanCode. ندعم الاثنين حتى تعمل الأزرار المطلوبة على الجهاز نفسه.
        if (matchesRemoteCode(event, KEYCODE_CURSOR_MODE)) return toggleCursorMode(event)
        if (matchesRemoteCode(event, KEYCODE_FULLSCREEN)) {
            return dispatchRemoteAction(event, "toggleFullscreen")
        }
        if (matchesRemoteCode(event, KEYCODE_NEXT)) return dispatchRemoteAction(event, "next")
        if (matchesRemoteCode(event, KEYCODE_PREVIOUS)) {
            return dispatchRemoteAction(event, "previous")
        }

        return when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> if (cursorMode) moveCursor(event, 0f, -1f) else super.dispatchKeyEvent(event)
            KeyEvent.KEYCODE_DPAD_DOWN -> if (cursorMode) moveCursor(event, 0f, 1f) else super.dispatchKeyEvent(event)
            KeyEvent.KEYCODE_DPAD_LEFT -> if (cursorMode) moveCursor(event, -1f, 0f) else super.dispatchKeyEvent(event)
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (cursorMode) moveCursor(event, 1f, 0f) else super.dispatchKeyEvent(event)
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            -> if (cursorMode) clickCursor(event) else super.dispatchKeyEvent(event)
            KeyEvent.KEYCODE_BACK -> handleBack(event)
            else -> super.dispatchKeyEvent(event)
        }
    }

    private fun matchesRemoteCode(event: KeyEvent, code: Int): Boolean =
        event.keyCode == code || event.scanCode == code

    private fun toggleCursorMode(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            cursorMode = !cursorMode
            if (cursorMode) {
                cursorView.showTemporarily()
                dispatchHoverAtCursor()
                Toast.makeText(this, "وضع الماوس", Toast.LENGTH_SHORT).show()
            } else {
                cursorView.hideNow()
                Toast.makeText(this, "وضع التنقل بالريموت", Toast.LENGTH_SHORT).show()
            }
            remoteChannel?.invokeMethod("navigationMode", if (cursorMode) "mouse" else "remote")
        }
        return true
    }

    private fun moveCursor(event: KeyEvent, dx: Float, dy: Float): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            cursorView.showTemporarily()
            val reachedEdge = cursorView.move(dx, dy, event.repeatCount)
            dispatchHoverAtCursor()
            // عند دفع المؤشر خارج أعلى/أسفل الشاشة نمرّر المحتوى نفسه.
            // الاتجاه المعاكس يعيد المؤشر فوراً إلى داخل الشاشة، لذلك لا يوجد
            // وضع Scroll عالق يمنع الحركة الرأسية بعد ذلك.
            if (reachedEdge && dy != 0f) {
                dispatchPageScroll(dy)
            }
        }
        return true
    }

    private fun dispatchHoverAtCursor() {
        val now = SystemClock.uptimeMillis()
        val hover = MotionEvent.obtain(
            now,
            now,
            MotionEvent.ACTION_HOVER_MOVE,
            cursorView.cursorX,
            cursorView.cursorY,
            0,
        )
        hover.source = InputDevice.SOURCE_MOUSE
        try {
            super.dispatchGenericMotionEvent(hover)
        } finally {
            hover.recycle()
        }
    }

    private fun dispatchPageScroll(direction: Float) {
        if (direction == 0f) return

        // أولاً نرسل Wheel حقيقي للمحتوى الموجود تحت المؤشر. هذا يجعل
        // ListView/GridView في البحث والمباشر تتحرك فعلياً بدل تحريك صورة
        // المؤشر فقط، ويعمل أيضاً عندما يكون العنصر داخل PlatformView.
        val now = SystemClock.uptimeMillis()
        val properties = arrayOf(MotionEvent.PointerProperties().apply {
            id = 0
            toolType = MotionEvent.TOOL_TYPE_MOUSE
        })
        val coords = arrayOf(MotionEvent.PointerCoords().apply {
            x = cursorView.cursorX
            y = cursorView.cursorY
            pressure = 0f
            size = 1f
            // Android: قيمة سالبة تعني تمريراً للأسفل.
            setAxisValue(MotionEvent.AXIS_VSCROLL, if (direction > 0f) -1f else 1f)
        })
        val scroll = MotionEvent.obtain(
            now,
            now,
            MotionEvent.ACTION_SCROLL,
            1,
            properties,
            coords,
            0,
            0,
            1f,
            1f,
            0,
            0,
            InputDevice.SOURCE_MOUSE,
            0,
        )
        val consumed = try {
            super.dispatchGenericMotionEvent(scroll)
        } finally {
            scroll.recycle()
        }

        // Fallback لقسم التركي القديم الذي يملك ScrollController مخصصاً.
        if (!consumed) {
            remoteChannel?.invokeMethod("cursorScroll", direction)
        }
    }

    private fun clickCursor(event: KeyEvent): Boolean {
        when (event.action) {
            KeyEvent.ACTION_DOWN -> if (event.repeatCount == 0) {
                cursorView.showTemporarily()
                cursorView.isClickAnimating = true
                dispatchTouchAtCursor(MotionEvent.ACTION_DOWN)
            }
            KeyEvent.ACTION_UP -> {
                dispatchTouchAtCursor(MotionEvent.ACTION_UP)
                cursorView.isClickAnimating = false
                cursorView.scheduleHide()
            }
        }
        return true
    }

    private fun dispatchTouchAtCursor(action: Int) {
        val now = SystemClock.uptimeMillis()
        val touch = MotionEvent.obtain(
            cursorView.touchDownTime(action, now),
            now,
            action,
            cursorView.cursorX,
            cursorView.cursorY,
            0,
        )
        touch.source = InputDevice.SOURCE_TOUCHSCREEN
        val wasVisible = cursorView.visibility == View.VISIBLE
        cursorView.visibility = View.INVISIBLE
        try {
            super.dispatchTouchEvent(touch)
        } finally {
            if (wasVisible) cursorView.visibility = View.VISIBLE
            cursorView.bringToFront()
            touch.recycle()
        }
    }

    private fun handleBack(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN || event.repeatCount > 0) return true
        val now = SystemClock.uptimeMillis()
        if (now - lastBackPressedAt <= DOUBLE_BACK_WINDOW_MS) {
            finishAffinity()
            return true
        }
        lastBackPressedAt = now
        flutterEngine?.navigationChannel?.popRoute()
        Toast.makeText(this, "اضغط رجوع مرة أخرى للخروج", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun dispatchRemoteAction(event: KeyEvent, action: String): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            remoteChannel?.invokeMethod(action, null)
        }
        return true
    }

    private fun installApk(path: String, result: MethodChannel.Result) {
        val apk = File(path)
        if (!apk.exists() || !apk.isFile) {
            result.error("FILE_MISSING", "ملف التحديث غير موجود.", null)
            return
        }
        val archive = packageManager.getPackageArchiveInfo(apk.absolutePath, 0)
        if (archive?.packageName != packageName) {
            result.error("WRONG_PACKAGE", "حزمة التحديث لا تخص تطبيق ذيب العرب.", null)
            return
        }
        val incomingBuild = if (android.os.Build.VERSION.SDK_INT >= 28) {
            archive.longVersionCode
        } else {
            @Suppress("DEPRECATION") archive.versionCode.toLong()
        }
        val installed = packageManager.getPackageInfo(packageName, 0)
        val installedBuild = if (android.os.Build.VERSION.SDK_INT >= 28) {
            installed.longVersionCode
        } else {
            @Suppress("DEPRECATION") installed.versionCode.toLong()
        }
        if (incomingBuild <= installedBuild) {
            result.error("OLD_BUILD", "ملف التحديث ليس أحدث من النسخة المثبتة.", null)
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O &&
            !packageManager.canRequestPackageInstalls()
        ) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    android.net.Uri.parse("package:$packageName"),
                ),
            )
            result.error(
                "INSTALL_PERMISSION",
                "فعّل السماح بالتثبيت ثم اضغط تثبيت مرة أخرى.",
                null,
            )
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.updates", apk)
        val intent = Intent(Intent.ACTION_INSTALL_PACKAGE).apply {
            data = uri
            clipData = ClipData.newRawUri("تحديث ذيب العرب", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(Intent.EXTRA_NOT_UNKNOWN_SOURCE, true)
            putExtra(Intent.EXTRA_RETURN_RESULT, false)
        }
        try {
            startActivity(intent)
            result.success(null)
        } catch (_: ActivityNotFoundException) {
            val fallback = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                clipData = ClipData.newRawUri("تحديث ذيب العرب", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (fallback.resolveActivity(packageManager) == null) {
                result.error(
                    "NO_INSTALLER",
                    "لا يوجد مثبت حزم متاح على هذا الجهاز.",
                    null,
                )
                return
            }
            startActivity(fallback)
            result.success(null)
        }
    }

    private inner class TvCursorView : View(this) {
        private val handler = Handler(Looper.getMainLooper())
        private val hideRunnable = Runnable {
            animate().cancel()
            animate()
                .alpha(0f)
                .setDuration(120L)
                .withEndAction {
                    if (alpha == 0f) visibility = View.INVISIBLE
                }
                .start()
        }
        private val outerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(20, 24, 32)
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            strokeJoin = Paint.Join.ROUND
            setShadowLayer(8f, 1f, 2f, Color.BLACK)
        }
        private val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
            strokeJoin = Paint.Join.ROUND
        }
        private val cursorPath = Path()

        var cursorX = 0f
            private set
        var cursorY = 0f
            private set
        var isClickAnimating = false
            set(value) {
                field = value
                invalidate()
            }
        private var activeDownTime = 0L

        init {
            setWillNotDraw(false)
            isClickable = false
            isFocusable = false
            elevation = 10_000f
            setLayerType(LAYER_TYPE_SOFTWARE, null)
            visibility = View.INVISIBLE
            alpha = 0f
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            if (cursorX == 0f && cursorY == 0f) {
                cursorX = w / 2f
                cursorY = h / 2f
            } else if (oldw > 0 && oldh > 0) {
                // نحافظ على الموضع النسبي عند الدخول والخروج من ملء الشاشة.
                cursorX = (cursorX * w / oldw).coerceIn(0f, maxCursorX(w))
                cursorY = (cursorY * h / oldh).coerceIn(0f, maxCursorY(h))
            }
        }

        private fun maxCursorX(viewWidth: Int = width): Float =
            (viewWidth - CURSOR_WIDTH).coerceAtLeast(0f)

        private fun maxCursorY(viewHeight: Int = height): Float =
            (viewHeight - CURSOR_HEIGHT).coerceAtLeast(0f)

        fun move(dx: Float, dy: Float, repeatCount: Int): Boolean {
            val acceleration = (1f + repeatCount.coerceAtMost(10) * 0.12f)
                .coerceAtMost(CURSOR_MAX_ACCELERATION)
            val step = CURSOR_STEP_DP * acceleration * resources.displayMetrics.density
            val maxX = maxCursorX()
            val maxY = maxCursorY()
            val nextX = cursorX + dx * step
            val nextY = cursorY + dy * step
            cursorX = nextX.coerceIn(0f, maxX)
            cursorY = nextY.coerceIn(0f, maxY)
            val edgeMargin = CURSOR_EDGE_SCROLL_DP * resources.displayMetrics.density
            val reachedEdge =
                (dy < 0f && cursorY <= edgeMargin) ||
                (dy > 0f && cursorY >= (maxY - edgeMargin).coerceAtLeast(0f))
            invalidate()
            return reachedEdge
        }

        fun showTemporarily() {
            handler.removeCallbacks(hideRunnable)
            animate().cancel()
            visibility = View.VISIBLE
            alpha = 1f
            bringToFront()
            scheduleHide()
        }

        fun scheduleHide() {
            handler.removeCallbacks(hideRunnable)
            handler.postDelayed(hideRunnable, CURSOR_HIDE_DELAY_MS)
        }

        fun hideNow() {
            handler.removeCallbacks(hideRunnable)
            animate().cancel()
            alpha = 0f
            visibility = View.INVISIBLE
            isClickAnimating = false
        }

        fun touchDownTime(action: Int, now: Long): Long {
            if (action == MotionEvent.ACTION_DOWN) activeDownTime = now
            return if (activeDownTime == 0L) now else activeDownTime
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val scale = if (isClickAnimating) 0.90f else 1f
            canvas.save()
            canvas.translate(cursorX, cursorY)
            canvas.scale(scale, scale)
            cursorPath.reset()
            cursorPath.moveTo(1f, 1f)
            cursorPath.lineTo(2f, 38f)
            cursorPath.lineTo(11f, 29f)
            cursorPath.lineTo(19f, 46f)
            cursorPath.lineTo(27f, 42f)
            cursorPath.lineTo(19f, 26f)
            cursorPath.lineTo(33f, 25f)
            cursorPath.close()
            canvas.drawPath(cursorPath, innerPaint)
            canvas.drawPath(cursorPath, outerPaint)
            canvas.restore()
        }

        override fun onTouchEvent(event: MotionEvent?): Boolean = false
    }

    companion object {
        private const val DOUBLE_BACK_WINDOW_MS = 1_500L
        private const val REMOTE_CHANNEL = "com.theebturk.app/remote"
        private const val UPDATER_CHANNEL = "com.theebturk.app/updater"
        // أكواد الريموت المطلوبة في نسخة Google TV.
        private const val KEYCODE_CURSOR_MODE = 4056
        private const val KEYCODE_FULLSCREEN = 174
        private const val KEYCODE_NEXT = 166
        private const val KEYCODE_PREVIOUS = 167
        private const val CURSOR_HIDE_DELAY_MS = 3_200L
        private const val CURSOR_STEP_DP = 12f
        private const val CURSOR_EDGE_SCROLL_DP = 28f
        private const val CURSOR_MAX_ACCELERATION = 3.4f
        private const val CURSOR_WIDTH = 38f
        private const val CURSOR_HEIGHT = 50f
    }
}
