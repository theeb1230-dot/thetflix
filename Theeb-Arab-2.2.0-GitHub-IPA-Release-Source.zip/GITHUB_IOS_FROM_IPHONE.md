# بناء IPA من Safari على الآيفون

1. ارفع محتويات المشروع إلى مستودع GitHub خاص.
2. من إعدادات المستودع افتح Actions ثم General.
3. ضمن Workflow permissions اختر Read and write permissions واحفظ التغيير.
4. افتح تبويب Actions واختر Build iOS Unsigned IPA.
5. اضغط Run workflow ثم Run workflow.
6. بعد نجاح البناء افتح صفحة Releases ونزّل `Theeb-Arab-2.2.0-unsigned.ipa`.

الملف الناتج غير موقع، ولا يتضمن شهادة Apple أو Provisioning Profile.
