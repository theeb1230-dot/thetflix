import 'package:flutter_test/flutter_test.dart';
import 'package:theeb_turk/features/search/cinema_search_screen.dart';

void main() {
  test('CinemaMedia يحفظ آخر موسم وحلقة مع البوستر', () {
    const media = CinemaMedia(
      id: 123,
      series: true,
      title: 'مسلسل تجريبي',
      poster: 'https://image.tmdb.org/t/p/w342/example.jpg',
      year: '2026',
      rating: 8.4,
      season: 3,
      episode: 11,
    );

    final restored = CinemaMedia.fromJson(media.toJson());

    expect(restored.id, 123);
    expect(restored.series, isTrue);
    expect(restored.poster, media.poster);
    expect(restored.season, 3);
    expect(restored.episode, 11);
  });

  test('CinemaMedia copyWith يحدث الحلقة بدون تكرار هوية العمل', () {
    const media = CinemaMedia(
      id: 777,
      series: true,
      title: 'عمل',
      poster: '',
      year: '2025',
      rating: 7.2,
      season: 1,
      episode: 1,
    );

    final next = media.copyWith(season: 2, episode: 5);

    expect(next.id, media.id);
    expect(next.title, media.title);
    expect(next.season, 2);
    expect(next.episode, 5);
  });
}
