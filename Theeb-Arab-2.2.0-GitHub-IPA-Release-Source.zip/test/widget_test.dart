import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:theeb_turk/main.dart';
import 'package:theeb_turk/services/theeb_storage.dart';
import 'package:theeb_turk/widgets/tv_focusable.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    await TheebStorage.init();
  });

  testWidgets('Theeb app starts successfully', (WidgetTester tester) async {
    await tester.pumpWidget(const TheebApp());
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 100));

    expect(find.text('تركي'), findsOneWidget);
    expect(find.text('لوحة التحكم'), findsOneWidget);
    expect(find.text('الإعدادات المتقدمة والسحب'), findsOneWidget);
  });

  testWidgets('library dialog opens above the player and supports D-pad', (
    WidgetTester tester,
  ) async {
    tester.view.physicalSize = const Size(1280, 1000);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const TheebApp());
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 150));

    const currentTitle = '📺 مسلسل وادي الذئاب (Kurtlar Vadisi Pusu)';
    const nextTitle = '📺 مسلسل المنظمة (Teskilat)';

    // نضغط على عنصر الـ TV القابل للتركيز نفسه، لا على Text الداخلي.
    // الضغط على Text مباشرة قد يصيب RenderObject آخر لأن المشغل/Overlay
    // يمكن أن يكون فوق الإحداثية في بيئة flutter_test.
    final currentTitleFinder = find.text(currentTitle).first;
    final libraryControl = find.ancestor(
      of: currentTitleFinder,
      matching: find.byType(TheebTvFocusable),
    );

    expect(libraryControl, findsOneWidget);

    await tester.ensureVisible(libraryControl);
    await tester.pump(const Duration(milliseconds: 120));

    // في flutter_test قد توجد طبقة PlatformView/overlay افتراضية فوق
    // إحداثية عنصر المكتبة، لذلك اختبار tap() قد لا يصل إلى GestureDetector
    // رغم أن العنصر نفسه موجود وقابل للتركيز. هنا نستدعي callback الخاص
    // بعنصر TheebTvFocusable مباشرة، ثم نختبر النافذة والتنقل بالـ D-pad
    // كما يحدثان فعليًا بعد تفعيل الزر.
    final libraryWidget = tester.widget<TheebTvFocusable>(libraryControl);
    expect(libraryWidget.onPressed, isNotNull);
    libraryWidget.onPressed!.call();

    await tester.pump();
    await tester.pump(const Duration(milliseconds: 250));

    expect(find.text('اختر من القائمة'), findsOneWidget);
    expect(find.text(nextTitle), findsOneWidget);

    // العنصر الحالي داخل النافذة يأخذ autofocus.
    // سهم لأسفل ينقل للعنصر التالي ثم Enter يختاره.
    await tester.sendKeyEvent(LogicalKeyboardKey.arrowDown);
    await tester.pump(const Duration(milliseconds: 80));
    await tester.sendKeyEvent(LogicalKeyboardKey.enter);
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 250));

    expect(find.text('اختر من القائمة'), findsNothing);

    // بعد الاختيار يجب أن يصبح مسلسل المنظمة هو العنصر المحدد في المكتبة.
    expect(find.text(nextTitle), findsOneWidget);
  });
}
