import 'package:flutter_test/flutter_test.dart';
import 'package:theeb_turk/features/search/cinema_search_screen.dart';

void main() {
  test('search keeps all 27 supplied server templates', () {
    expect(cinemaServers, hasLength(27));
    expect(cinemaServers.first.name, 'Pomfy');
    expect(cinemaServers.last.name, 'الاحتياطي العام');
  });
}
