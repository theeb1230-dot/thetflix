import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:theeb_turk/controllers/theeb_controller.dart';
import 'package:theeb_turk/data/default_catalog.dart';
import 'package:theeb_turk/models/theeb_models.dart';
import 'package:theeb_turk/services/theeb_storage.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {
    SharedPreferences.setMockInitialValues({});
    await TheebStorage.init();
  });

  test('custom title uses the requested TV and movie formats', () {
    expect(
      buildCustomDisplayTitle(
        type: TheebContentType.tv,
        arabicTitle: 'مرعشلي',
        workTitle: 'Marasli',
      ),
      '📺 ⭐️ مرعشلي (Marasli)',
    );
    expect(
      buildCustomDisplayTitle(
        type: TheebContentType.movie,
        arabicTitle: 'العراق',
        workTitle: 'Iraq',
      ),
      '🎬 ⭐️ العراق (Iraq)',
    );
  });

  test('slug identity ignores case, extra spaces, and repeated dashes', () {
    expect(normalizeCatalogIdentity('  MARASLI  '), 'marasli');
    expect(normalizeCatalogIdentity('marasli---new'), 'marasli-new');
    expect(normalizeCatalogIdentity('marasli new'), 'marasli-new');
  });

  test('editing updates the same item, favorites, and history', () async {
    final controller = TheebController(defaultCatalog: theebDefaultCatalog);
    await controller.initialize();

    final added = await controller.addCustomItem(
      type: TheebContentType.tv,
      arabicTitle: 'مرعشلي',
      workTitle: 'Marasli',
      slug: 'marasli',
      episodeCounts: const [10, 12],
    );

    expect(added.displayTitle, '📺 ⭐️ مرعشلي (Marasli)');
    expect(controller.customCatalog, hasLength(1));
    expect(await controller.toggleFavorite(), isTrue);

    final updated = await controller.updateCustomItemAt(
      index: 0,
      type: TheebContentType.movie,
      arabicTitle: 'مرعشلي الفيلم',
      workTitle: 'Marasli Movie',
      slug: 'marasli-movie',
      episodeCounts: const [],
    );

    expect(controller.customCatalog, hasLength(1));
    expect(updated.displayTitle, '🎬 ⭐️ مرعشلي الفيلم (Marasli Movie)');
    expect(controller.favorites.single.slug, 'marasli-movie');
    expect(controller.favorites.single.title, updated.displayTitle);
    expect(controller.history.first.slug, 'marasli-movie');
    expect(controller.history.first.season, 1);
    expect(controller.history.first.episode, 1);

    controller.dispose();
  });

  test('duplicate custom and built-in slugs are rejected', () async {
    await TheebStorage.clearAllTheebData();
    final controller = TheebController(defaultCatalog: theebDefaultCatalog);
    await controller.initialize();

    await controller.addCustomItem(
      type: TheebContentType.tv,
      arabicTitle: 'مرعشلي',
      workTitle: 'Marasli',
      slug: 'marasli',
      episodeCounts: const [10],
    );

    expect(
      controller.validateCustomItemIdentity(
        slug: '  MARASLI  ',
        workTitle: 'Different',
      ),
      isNotNull,
    );
    expect(
      controller.validateCustomItemIdentity(
        slug: 'KURTLAR VADISI PUSU',
        workTitle: 'Different',
      ),
      isNotNull,
    );

    controller.dispose();
  });

  test('current player and mobile mode are restored across sessions', () async {
    await TheebStorage.clearAllTheebData();
    final first = TheebController(defaultCatalog: theebDefaultCatalog);
    await first.initialize();
    await first.selectShowBySlug('kurtlar-vadisi-pusu');
    await first.setSeason(2);
    await first.setEpisode(7);
    await first.setServer(4);
    await first.setMobileMode(true);
    first.dispose();

    final restored = TheebController(defaultCatalog: theebDefaultCatalog);
    await restored.initialize();
    expect(restored.currentShow.slug, 'kurtlar-vadisi-pusu');
    expect(restored.season, 2);
    expect(restored.episode, 7);
    expect(restored.server, 4);
    expect(restored.mobileMode, isTrue);
    restored.dispose();
  });

  test('page position is persisted and invalid values are sanitized', () async {
    await TheebStorage.savePageScrollOffset(420.5);
    expect(TheebStorage.getPageScrollOffset(), 420.5);

    await TheebStorage.savePageScrollOffset(-25);
    expect(TheebStorage.getPageScrollOffset(), 0);

    await TheebStorage.savePageScrollOffset(double.nan);
    expect(TheebStorage.getPageScrollOffset(), 0);
  });
}
