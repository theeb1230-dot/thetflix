# تحديثات ذيب العرب

يعمل النظام بطريقتين متكاملتين:

1. تنزيل الحزمة الأولى من رابط HTTPS مجاني، مثل GitHub Releases.
2. مشاركة الحزمة التي تم التحقق منها مع أجهزة ذيب العرب داخل شبكة المنزل عبر Bonjour/NSD وHTTP محلي مؤقت.

## إعداد رابط التحديث

انسخ `update.example.json` إلى مستودع GitHub وعدّل الرابط والحجم وبصمة SHA-256. ثم ابنِ التطبيق هكذا:

```powershell
flutter build apk --release --dart-define=THEEB_UPDATE_MANIFEST_URL=https://raw.githubusercontent.com/USERNAME/REPOSITORY/main/update.json
```

لا يحتاج رابط ملف التحديث إلى أن يكون مخزنًا داخل الكود، ويمكن تغييره في كل بناء.

## إنشاء البصمة على Windows

```powershell
Get-FileHash .\build\app\outputs\flutter-apk\app-release.apk -Algorithm SHA256
```

يجب زيادة رقم البناء في `pubspec.yaml` مع كل إصدار، مثل `1.1.0+2`. يجب كذلك توقيع تحديثات Android بالمفتاح نفسه والحفاظ على `applicationId` الحالي حتى تبقى المكتبة والمفضلة والسجل محفوظة.

## مشاركة Android من iPhone

افتح مركز التحديثات على iPhone، افحص الإنترنت ثم نزّل حزمة Android. سيحتفظ التطبيق بها داخل مساحة التطبيق ويعلن عنها لأجهزة ذيب العرب القريبة. افتح مركز التحديثات على TCL واضغط «بحث داخل الشبكة» ثم استلم الحزمة وثبّتها.
